//! IPC-aligned command/service behaviors mapped from 3.22 MainServices surface.
//!
//! MainServices channels discovered from `electron-hub-3.22/app/.vite/build/MainServices-CqVmMNFy.js`
//! and registered via `IpcMainService` (`ipcMain.handle(channel, ...)`).

use crate::error::Result;
use serde_json::Value;
use std::path::Path;

/// Known/discovered MainServices method names (extracted from bundled 3.22 build).
/// Full extracted list is in `electron-hub-3.22/mainservices-methods.txt` (299 methods).
pub fn discovered_channels() -> Vec<String> {
    let path = std::path::Path::new("electron-hub-3.22").join("mainservices-methods.txt");
    if let Ok(content) = std::fs::read_to_string(&path) {
        return content.lines().map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect();
    }
    // fallback representative set
    vec![
        "getProjectsInfo","getRecentProjects","addProject","removeProject","setProjectFavorite","openProject",
        "getInstalledEditors","getEditorsByVersion","removeEditor","setEditorVersion",
        "getDownloadLocation","downloadManagerUtilities","pause","resume","cancelTask",
    ].into_iter().map(|s| s.to_string()).collect()
}

pub fn list_channels() {
    for ch in discovered_channels() {
        println!("{ch}");
    }
}

/// IPC-aligned: getProjectsInfo / list local projects from projects-v1 registry.
pub fn get_projects_info(data_dir: &Path) -> Result<Value> {
    let reg = crate::hub_registry::load_projects_registry(&data_dir.join("projects-v1.json"))?;
    Ok(serde_json::to_value(&reg.data)?)
}

/// IPC-aligned: getRecentProjects (sorted by lastModified desc).
pub fn get_recent_projects(data_dir: &Path) -> Result<Value> {
    let reg = crate::hub_registry::load_projects_registry(&data_dir.join("projects-v1.json"))?;
    let recents = crate::hub_registry::recent_projects(&reg);
    let arr: Vec<Value> = recents
        .into_iter()
        .map(|(k, r)| {
            let mut v = serde_json::to_value(r).unwrap_or(Value::Null);
            if let Some(obj) = v.as_object_mut() {
                obj.entry("path").or_insert(Value::String(k.clone()));
            }
            v
        })
        .collect();
    Ok(Value::Array(arr))
}

/// IPC-aligned: getInstalledEditors (scan + return).
pub fn get_installed_editors() -> Result<Value> {
    let installs = crate::installs::installed_editors()?;
    Ok(serde_json::to_value(installs)?)
}

/// IPC-aligned: getDownloadLocation / secondary install path (best-effort from prefs).
pub fn get_download_preferences(data_dir: &Path) -> Result<Value> {
    let secondary = crate::hub_storage::read_raw(data_dir, "secondaryInstallPath.json").ok();
    let secondary_val = secondary
        .as_deref()
        .and_then(|s| serde_json::from_str::<Value>(s).ok())
        .unwrap_or(Value::Null);
    let project_dir = crate::hub_storage::read_json(data_dir, "projectDir.json").ok().unwrap_or(Value::Null);
    let paused = crate::hub_storage::read_json(data_dir, "paused-downloads.json").ok().unwrap_or(Value::Null);
    Ok(serde_json::json!({
        "secondaryInstallPath": secondary_val,
        "projectDir": project_dir,
        "pausedDownloads": paused
    }))
}

fn read_bool_pref(data_dir: &Path, file: &str, default: bool) -> bool {
    crate::hub_storage::read_raw(data_dir, file)
        .ok()
        .and_then(|s| {
            let t = s.trim().trim_start_matches('\u{feff}');
            if t.eq_ignore_ascii_case("true") { Some(true) }
            else if t.eq_ignore_ascii_case("false") { Some(false) }
            else { serde_json::from_str::<Value>(t).ok().and_then(|v| v.as_bool()) }
        })
        .unwrap_or(default)
}

fn write_bool_pref(data_dir: &Path, file: &str, value: bool) -> Result<()> {
    crate::hub_storage::write_raw(data_dir, file, if value { "true" } else { "false" })
}

fn read_install_state_table_json(data_dir: &Path, table: &str) -> Result<Value> {
    let path = data_dir.join("install-state").join("install-state.db");
    if !path.exists() {
        return Ok(serde_json::json!({"db": path.to_string_lossy(), "exists": false, "rows": []}));
    }
    let conn = rusqlite::Connection::open_with_flags(&path, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY)
        .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let sql = format!("SELECT * FROM \"{}\"", table.replace('"', "\"\""));
    let mut stmt = conn.prepare(&sql).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let col_count = stmt.column_count();
    let col_names: Vec<String> = stmt.column_names().into_iter().map(|s| s.to_string()).collect();
    let rows_iter = stmt.query_map([], |row| {
        let mut obj = serde_json::Map::new();
        for i in 0..col_count {
            let name = col_names.get(i).cloned().unwrap_or_else(|| i.to_string());
            let v: Value = match row.get_ref(i)? {
                rusqlite::types::ValueRef::Null => Value::Null,
                rusqlite::types::ValueRef::Integer(n) => serde_json::json!(n),
                rusqlite::types::ValueRef::Real(f) => serde_json::json!(f),
                rusqlite::types::ValueRef::Text(t) => Value::String(String::from_utf8_lossy(t).to_string()),
                rusqlite::types::ValueRef::Blob(b) => Value::String(format!("<blob:{}>", b.len())),
            };
            obj.insert(name, v);
        }
        Ok(Value::Object(obj))
    }).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let mut rows = Vec::new();
    for r in rows_iter { rows.push(r.map_err(|e| crate::error::HubError::Other(e.to_string()))?); }
    Ok(serde_json::json!({"db": path.to_string_lossy(), "exists": true, "table": table, "rows": rows}))
}

pub fn dispatch(channel: &str, args: &[String], data_dir: &Path) -> Result<()> {
    // Renderer channels are `ns/method`; namespaced handlers first, then suffix dispatch.
    if let Some(r) = crate::ipc_extra::dispatch(channel, args, data_dir) {
        return r;
    }
    let method = channel.rsplit('/').next().unwrap_or(channel);
    match method {
        "channels" | "listChannels" => {
            list_channels();
            Ok(())
        }
        "getProjectsInfo" | "getLocalProjects" | "listProjects" => {
            println!("{}", serde_json::to_string_pretty(&get_projects_info(data_dir)?)?);
            Ok(())
        }
        "getRecentProjects" => {
            println!("{}", serde_json::to_string_pretty(&get_recent_projects(data_dir)?)?);
            Ok(())
        }
        "addProject" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("addProject requires path".into()))?;
            let (rec, added) = crate::services::local_project::add_project(data_dir, path)?;
            println!("{}", serde_json::json!({"ok": true, "method":"addProject", "added": added, "path": path, "title": rec.title, "version": rec.version, "changeset": rec.changeset}));
            Ok(())
        }
        "removeProject" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("removeProject requires path".into()))?;
            let removed = crate::services::local_project::remove_project(data_dir, path)?;
            println!("{}", serde_json::json!({"ok": removed, "method":"removeProject", "path": path}));
            Ok(())
        }
        "setProjectFavorite" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("setProjectFavorite requires path".into()))?;
            let fav = args.get(1).map(|s| s == "true" || s == "1").unwrap_or(true);
            let ok = crate::services::local_project::set_favorite(data_dir, path, fav)?;
            println!("{}", serde_json::json!({"ok": ok, "method":"setProjectFavorite", "path": path, "isFavorite": fav}));
            Ok(())
        }
        "addToRecentProjects" | "openProject" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("openProject/addToRecentProjects requires path".into()))?;
            let ok = crate::services::local_project::open_project(data_dir, path)?;
            let now = crate::hub_registry::now_millis();
            println!("{}", serde_json::json!({"ok": ok, "method":"openProject", "path": path, "lastModified": now}));
            Ok(())
        }
        "getProjectInfo" | "getProject" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("getProject requires path".into()))?;
            if let Some(v) = crate::services::local_project::get_registry_project(data_dir, path)? {
                println!("{}", serde_json::to_string_pretty(&v)?);
            } else {
                println!("{}", serde_json::json!({"ok":false,"method":"getProject","path":path,"found":false}));
            }
            Ok(())
        }
        "setProjectsInfo" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setProjectsInfo requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            let mut reg = crate::services::local_project::load_registry(data_dir)?;
            if let Some(data) = v.get("data").and_then(|d| d.as_object()) {
                let mut new_data = std::collections::BTreeMap::new();
                for (k, val) in data {
                    if let Ok(rec) = serde_json::from_value::<crate::hub_registry::ProjectRecord>(val.clone()) {
                        new_data.insert(k.clone(), rec);
                    }
                }
                reg.data = new_data;
                if let Some(sv) = v.get("schema_version").and_then(|s| s.as_str()) {
                    reg.schema_version = sv.to_string();
                }
            } else if let Some(obj) = v.as_object() {
                let mut new_data = std::collections::BTreeMap::new();
                for (k, val) in obj {
                    if let Ok(rec) = serde_json::from_value::<crate::hub_registry::ProjectRecord>(val.clone()) {
                        new_data.insert(k.clone(), rec);
                    }
                }
                reg.data = new_data;
            }
            crate::services::local_project::save_registry(data_dir, &reg)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setProjectsInfo","count": reg.data.len()}));
            Ok(())
        }
        "setProjectTags" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("setProjectTags requires path".into()))?;
            let tags_json = args.get(1).ok_or_else(|| crate::error::HubError::Other("setProjectTags requires tags JSON".into()))?;
            let tags: Value = serde_json::from_str(tags_json)?;
            let ok = crate::services::local_project::set_tags(data_dir, path, tags.clone())?;
            println!("{}", serde_json::json!({"ok": ok, "method":"setProjectTags", "path": path, "tags": tags}));
            Ok(())
        }
        "deleteProjectTags" => {
            let tags_json = args.get(0).ok_or_else(|| crate::error::HubError::Other("deleteProjectTags requires tags JSON array".into()))?;
            let tags_val: Value = serde_json::from_str(tags_json)?;
            let tags: Vec<String> = tags_val
                .as_array()
                .map(|a| a.iter().filter_map(|v| v.as_str().map(|s| s.to_string())).collect())
                .unwrap_or_default();
            let changed = crate::services::local_project::delete_tags(data_dir, &tags)?;
            println!("{}", serde_json::json!({"ok": true, "method":"deleteProjectTags", "changedProjects": changed, "tags": tags}));
            Ok(())
        }
        "clearProjectDeeplinkInfo" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("clearProjectDeeplinkInfo requires path".into()))?;
            let ok = crate::services::local_project::clear_deeplink_info(data_dir, path)?;
            println!("{}", serde_json::json!({"ok": ok, "method":"clearProjectDeeplinkInfo", "path": path}));
            Ok(())
        }
        "getInstalledEditors" | "listEditors" => {
            println!("{}", serde_json::to_string_pretty(&get_installed_editors()?)?);
            Ok(())
        }
        "getArchivedEditors" => { println!("[]"); Ok(()) }
        "getEditorsByVersion" | "getSpecificEditorsByVersion" => {
            let version = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let installs = crate::installs::installed_editors()?;
            let filtered: Vec<_> = installs.into_iter().filter(|e| version.is_empty() || e.version == version || e.install_name == version).collect();
            println!("{}", serde_json::to_string_pretty(&filtered)?);
            Ok(())
        }
        "locateEditor" | "addEditor" => {
            let version = args.get(0).ok_or_else(|| crate::error::HubError::Other("locateEditor requires version".into()))?;
            let location = args.get(1).ok_or_else(|| crate::error::HubError::Other("locateEditor requires location".into()))?;
            let manual = args.get(2).map(|s| s == "true" || s == "1").unwrap_or(true);
            let added = crate::services::editor_inventory::locate_editor(data_dir, version, location, manual)?;
            println!("{}", serde_json::json!({"ok":true,"method":"locateEditor","added":added,"version":version,"location":location,"manual":manual}));
            Ok(())
        }
        "setEditorManual" => {
            let matcher = args.get(0).ok_or_else(|| crate::error::HubError::Other("setEditorManual requires matcher".into()))?;
            let manual = args.get(1).map(|s| s=="true"||s=="1").unwrap_or(true);
            let reg_path = data_dir.join("editors-v2.json");
            let mut reg = crate::hub_registry::load_editors_registry(&reg_path)?;
            let updated = crate::hub_registry::set_editor_manual(&mut reg, matcher, manual);
            crate::hub_registry::save_editors_registry(&reg_path, &reg)?;
            println!("{}", serde_json::json!({"ok":updated>0,"method":"setEditorManual","updated":updated,"matcher":matcher,"manual":manual}));
            Ok(())
        }
        "syncInstalledEditors" | "refreshEditors" => {
            let (scanned, added, updated) = crate::services::editor_inventory::sync_from_scan(data_dir)?;
            println!("{}", serde_json::json!({"ok":true,"method":"syncInstalledEditors","scanned":scanned,"added":added,"updated":updated}));
            Ok(())
        }
        "removeEditor" => {
            let matcher = args.get(0).ok_or_else(|| crate::error::HubError::Other("removeEditor requires version/location".into()))?;
            let removed = crate::services::editor_inventory::remove_editor(data_dir, matcher)?;
            println!("{}", serde_json::json!({"ok": removed>0, "removed": removed, "method":"removeEditor", "matcher": matcher}));
            Ok(())
        }
        "getDownloadPreferences" | "getDownloadLocation" | "getSecondaryInstallPath" => {
            println!("{}", serde_json::to_string_pretty(&get_download_preferences(data_dir)?)?);
            Ok(())
        }
        "setSecondaryInstallPath" | "setDownloadLocation" => {
            let path = args.get(0).cloned().unwrap_or_default();
            let value = serde_json::Value::String(path.clone());
            crate::hub_storage::write_json(data_dir, "secondaryInstallPath.json", &value)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setSecondaryInstallPath","secondaryInstallPath":path}));
            Ok(())
        }
        "getDownloadsState" => {
            println!("{}", serde_json::to_string_pretty(&crate::install_state::read_table_json(data_dir, "downloads")?)?);
            Ok(())
        }
        "getInstallState" | "getInstallsState" => {
            println!("{}", serde_json::to_string_pretty(&crate::install_state::read_table_json(data_dir, "installs")?)?);
            Ok(())
        }
        "getDownloadState" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("getDownloadState requires uid".into()))?;
            let t = crate::install_state::read_table_json(data_dir, "downloads")?;
            let rows = t.get("rows").and_then(|v| v.as_array()).cloned().unwrap_or_default();
            let row = rows.into_iter().find(|r| r.get("uid").and_then(|v| v.as_str()) == Some(uid)).unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&row)?);
            Ok(())
        }
        "clearInstallState" | "clearInstall" => {
            let ok = crate::install_state::clear_install(data_dir)?;
            println!("{}", serde_json::json!({"ok":ok,"method":"clearInstall"}));
            Ok(())
        }
        "queueInstall" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("queueInstall requires uid".into()))?;
            let version = args.get(1).ok_or_else(|| crate::error::HubError::Other("queueInstall requires version".into()))?;
            let modules = args.get(2).map(|s| s.as_str()).unwrap_or("[]");
            let now = crate::hub_registry::now_millis();
            crate::install_state::queue_install(data_dir, uid, version, modules, std::process::id() as i64, now)?;
            println!("{}", serde_json::json!({"ok":true,"method":"queueInstall","uid":uid,"version":version,"modules":modules,"state":"queued"}));
            Ok(())
        }
        "getPausedDownloads" => {
            let paused = crate::hub_storage::read_json(data_dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
            println!("{}", serde_json::to_string_pretty(&paused)?);
            Ok(())
        }
        "getFileClaimsState" | "getFileClaims" => {
            println!("{}", serde_json::to_string_pretty(&crate::install_state::read_table_json(data_dir, "file_claims")?)?);
            Ok(())
        }
        "upsertFileClaim" => {
            let pid = args.get(0).and_then(|s| s.parse::<i64>().ok()).ok_or_else(|| crate::error::HubError::Other("upsertFileClaim requires pid".into()))?;
            let source = args.get(1).ok_or_else(|| crate::error::HubError::Other("upsertFileClaim requires source".into()))?;
            let path = args.get(2).ok_or_else(|| crate::error::HubError::Other("upsertFileClaim requires path".into()))?;
            let now = crate::hub_registry::now_millis();
            crate::install_state::upsert_file_claim(data_dir, pid, source, path, now)?;
            println!("{}", serde_json::json!({"ok":true,"method":"upsertFileClaim","pid":pid,"source":source,"path":path}));
            Ok(())
        }
        "removeFileClaim" => {
            let pid = args.get(0).and_then(|s| s.parse::<i64>().ok()).ok_or_else(|| crate::error::HubError::Other("removeFileClaim requires pid".into()))?;
            let source = args.get(1).ok_or_else(|| crate::error::HubError::Other("removeFileClaim requires source".into()))?;
            let path = args.get(2).ok_or_else(|| crate::error::HubError::Other("removeFileClaim requires path".into()))?;
            let ok = crate::install_state::remove_file_claim(data_dir, pid, source, path)?;
            println!("{}", serde_json::json!({"ok":ok,"method":"removeFileClaim","pid":pid,"source":source,"path":path}));
            Ok(())
        }
        "clearFileClaims" => {
            let removed = crate::install_state::clear_file_claims(data_dir)?;
            println!("{}", serde_json::json!({"ok":true,"method":"clearFileClaims","removed":removed}));
            Ok(())
        }
        "getInstallStateSchemaMeta" | "getSchemaMeta" => {
            println!("{}", serde_json::to_string_pretty(&crate::install_state::read_table_json(data_dir, "schema_meta")?)?);
            Ok(())
        }
        "getUnityCLIStatus" => {
            let v = crate::hub_storage::read_json(data_dir, "cli-install.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setInstallPhase" | "setInstallStatePhase" => {
            let phase = args.get(0).ok_or_else(|| crate::error::HubError::Other("setInstallPhase requires phase".into()))?;
            let now = crate::hub_registry::now_millis();
            let ok = crate::install_state::set_install_phase(data_dir, phase, now)?;
            println!("{}", serde_json::json!({"ok":ok,"method":"setInstallPhase","phase":phase}));
            Ok(())
        }
        "queueDownload" | "queueEditorDownload" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("queueDownload requires uid".into()))?;
            let version = args.get(1).ok_or_else(|| crate::error::HubError::Other("queueDownload requires version".into()))?;
            let arch = args.get(2).map(|s| s.as_str());
            let modules = args.get(3).map(|s| s.as_str()).unwrap_or("[]");
            let now = crate::hub_registry::now_millis();
            crate::install_state::queue_download(data_dir, uid, version, arch, modules, now)?;
            println!("{}", serde_json::json!({"ok":true,"method":"queueDownload","uid":uid,"version":version,"arch":arch,"modules":modules,"state":"queued"}));
            Ok(())
        }
        "setDownloadState" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("setDownloadState requires uid".into()))?;
            let state = args.get(1).ok_or_else(|| crate::error::HubError::Other("setDownloadState requires state".into()))?;
            let bytes_done = args.get(2).and_then(|s| s.parse::<i64>().ok());
            let bytes_total = args.get(3).and_then(|s| s.parse::<i64>().ok());
            let now = crate::hub_registry::now_millis();
            let ok = crate::install_state::set_download_state(data_dir, uid, state, bytes_done, bytes_total, None, None, now)?;
            println!("{}", serde_json::json!({"ok":ok,"method":"setDownloadState","uid":uid,"state":state}));
            Ok(())
        }
        "addPausedDownloadEntry" => {
            let entry_json = args.get(0).ok_or_else(|| crate::error::HubError::Other("addPausedDownloadEntry requires JSON entry".into()))?;
            let entry: serde_json::Value = serde_json::from_str(entry_json)?;
            let mut root = crate::hub_storage::read_json(data_dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
            if !root.get("downloads").map(|v| v.is_array()).unwrap_or(false) { root["downloads"] = serde_json::json!([]); }
            if root.get("version").is_none() { root["version"] = serde_json::json!(1); }
            let uid = entry.get("uid").or_else(|| entry.get("id")).and_then(|v| v.as_str()).map(|s| s.to_string());
            if let Some(arr) = root.get_mut("downloads").and_then(|v| v.as_array_mut()) {
                if let Some(uid) = uid.as_deref() {
                    if let Some(existing) = arr.iter_mut().find(|e| e.get("uid").or_else(|| e.get("id")).and_then(|v| v.as_str()) == Some(uid)) {
                        *existing = entry.clone();
                    } else { arr.push(entry.clone()); }
                } else { arr.push(entry.clone()); }
            }
            crate::hub_storage::write_json(data_dir, "paused-downloads.json", &root)?;
            println!("{}", serde_json::json!({"ok":true,"method":"addPausedDownloadEntry","uid":uid}));
            Ok(())
        }
        "removePausedDownloadEntry" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("removePausedDownloadEntry requires uid".into()))?;
            let mut root = crate::hub_storage::read_json(data_dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
            let mut removed = 0usize;
            if let Some(arr) = root.get_mut("downloads").and_then(|v| v.as_array_mut()) {
                let before = arr.len();
                arr.retain(|e| e.get("uid").or_else(|| e.get("id")).and_then(|v| v.as_str()) != Some(uid));
                removed = before.saturating_sub(arr.len());
            }
            if root.get("version").is_none() { root["version"] = serde_json::json!(1); }
            crate::hub_storage::write_json(data_dir, "paused-downloads.json", &root)?;
            println!("{}", serde_json::json!({"ok":removed>0,"removed":removed,"method":"removePausedDownloadEntry","uid":uid}));
            Ok(())
        }
        "cancelDownload" | "cancelTask" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("cancelDownload/cancelTask requires uid".into()))?;
            let now = crate::hub_registry::now_millis();
            let ok = crate::install_state::cancel_download(data_dir, uid, now)?;
            println!("{}", serde_json::json!({"ok":ok,"method":"cancelDownload","uid":uid,"state":"cancelled"}));
            Ok(())
        }
        "pause" | "pauseDownload" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("pause requires uid".into()))?;
            let mut root = crate::hub_storage::read_json(data_dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
            if !root.get("downloads").map(|v| v.is_array()).unwrap_or(false) { root["downloads"] = serde_json::json!([]); }
            if root.get("version").is_none() { root["version"] = serde_json::json!(1); }
            if let Some(arr) = root.get_mut("downloads").and_then(|v| v.as_array_mut()) {
                let entry = serde_json::json!({"uid": uid, "id": uid, "status": "paused"});
                if let Some(existing) = arr.iter_mut().find(|e| e.get("uid").or_else(|| e.get("id")).and_then(|v| v.as_str()) == Some(uid)) { *existing = entry; } else { arr.push(entry); }
            }
            crate::hub_storage::write_json(data_dir, "paused-downloads.json", &root)?;
            let now = crate::hub_registry::now_millis();
            let _ = crate::install_state::cancel_download(data_dir, uid, now);
            println!("{}", serde_json::json!({"ok":true,"method":"pause","uid":uid}));
            Ok(())
        }
        "resume" | "resumeDownload" => {
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("resume requires uid".into()))?;
            let mut root = crate::hub_storage::read_json(data_dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
            let mut removed = 0usize;
            if let Some(arr) = root.get_mut("downloads").and_then(|v| v.as_array_mut()) {
                let before = arr.len();
                arr.retain(|e| e.get("uid").or_else(|| e.get("id")).and_then(|v| v.as_str()) != Some(uid));
                removed = before.saturating_sub(arr.len());
            }
            crate::hub_storage::write_json(data_dir, "paused-downloads.json", &root)?;
            let now = crate::hub_registry::now_millis();
            let _ = crate::install_state::set_download_state(data_dir, uid, "queued", None, None, None, None, now);
            println!("{}", serde_json::json!({"ok":true,"method":"resume","uid":uid,"removedFromPaused":removed}));
            Ok(())
        }
        "getLanguage" => {
            let v = crate::hub_storage::read_json(data_dir, "languageConfig.json").unwrap_or(serde_json::json!({"language":"en"}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setLanguage" => {
            let lang = args.get(0).ok_or_else(|| crate::error::HubError::Other("setLanguage requires language code".into()))?;
            let v = serde_json::json!({"language": lang});
            crate::hub_storage::write_json(data_dir, "languageConfig.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setLanguage","language":lang}));
            Ok(())
        }
        "getHideHubOnEditorOpen" => { println!("{}", read_bool_pref(data_dir, "hideHubOnEditorOpen.json", false)); Ok(()) }
        "setHideHubOnEditorOpen" => { let v = args.get(0).map(|s| s=="true"||s=="1").unwrap_or(true); write_bool_pref(data_dir, "hideHubOnEditorOpen.json", v)?; println!("{}", serde_json::json!({"ok":true,"method":"setHideHubOnEditorOpen","value":v})); Ok(()) }
        "getHideGetSetUp" => { println!("{}", read_bool_pref(data_dir, "hideGetSetUp.json", false)); Ok(()) }
        "setHideGetSetUp" => { let v = args.get(0).map(|s| s=="true"||s=="1").unwrap_or(true); write_bool_pref(data_dir, "hideGetSetUp.json", v)?; println!("{}", serde_json::json!({"ok":true,"method":"setHideGetSetUp","value":v})); Ok(()) }
        "getPreferredModules" => {
            let v = crate::hub_storage::read_json(data_dir, "modulesPreference.json").unwrap_or(serde_json::json!({"selected":[],"deselected":[]}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setPreferredModules" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setPreferredModules requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json).unwrap_or_else(|_| serde_json::json!({"selected":[],"deselected":[]}));
            crate::hub_storage::write_json(data_dir, "modulesPreference.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setPreferredModules"}));
            Ok(())
        }
        "getProjectIncludeAIAssistant" => { println!("{}", read_bool_pref(data_dir, "projectIncludeAIAssistant.json", false)); Ok(()) }
        "setProjectIncludeAIAssistant" => { let v = args.get(0).map(|s| s=="true"||s=="1").unwrap_or(true); write_bool_pref(data_dir, "projectIncludeAIAssistant.json", v)?; println!("{}", serde_json::json!({"ok":true,"method":"setProjectIncludeAIAssistant","value":v})); Ok(()) }
        "getProjectIncludeUnityCLI" => { println!("{}", read_bool_pref(data_dir, "projectIncludeUnityCLI.json", false)); Ok(()) }
        "setProjectIncludeUnityCLI" => { let v = args.get(0).map(|s| s=="true"||s=="1").unwrap_or(true); write_bool_pref(data_dir, "projectIncludeUnityCLI.json", v)?; println!("{}", serde_json::json!({"ok":true,"method":"setProjectIncludeUnityCLI","value":v})); Ok(()) }
        "getSkipRemoveConfirmationFromStorage" => {
            let v = crate::hub_storage::read_json(data_dir, "skipRemoveConfirmation.json").unwrap_or(serde_json::json!({"timestamp":0,"always":false}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setSkipRemoveConfirmationToStorage" => {
            let always = args.get(0).map(|s| s=="true"||s=="1").unwrap_or(false);
            let timestamp = args.get(1).and_then(|s| s.parse::<i64>().ok()).unwrap_or(0);
            let v = serde_json::json!({"timestamp": timestamp, "always": always});
            crate::hub_storage::write_json(data_dir, "skipRemoveConfirmation.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setSkipRemoveConfirmationToStorage","always":always,"timestamp":timestamp}));
            Ok(())
        }
        "getSortPreferencesFromStorage" | "getProjectSortPreferences" => {
            let v = crate::hub_storage::read_json(data_dir, "projectSortPreferences.json").unwrap_or(serde_json::json!({"sortBy":"lastModified","sortDirection":"ascending"}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setSortPreferencesToStorage" => {
            let sort_by = args.get(0).cloned().unwrap_or_else(|| "lastModified".to_string());
            let sort_dir = args.get(1).cloned().unwrap_or_else(|| "ascending".to_string());
            let v = serde_json::json!({"sortBy": sort_by, "sortDirection": sort_dir});
            crate::hub_storage::write_json(data_dir, "projectSortPreferences.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setSortPreferencesToStorage"}));
            Ok(())
        }
        "getProjectsLocation" => {
            let v = crate::hub_storage::read_json(data_dir, "projectDir.json").unwrap_or(serde_json::json!({"directoryPath":""}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setProjectsLocation" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("setProjectsLocation requires directory path".into()))?;
            let v = serde_json::json!({"directoryPath": path});
            crate::hub_storage::write_json(data_dir, "projectDir.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setProjectsLocation","directoryPath":path}));
            Ok(())
        }
        "getTablePreferencesFromStorage" | "getProjectTablePreferences" => {
            let v = crate::hub_storage::read_json(data_dir, "projectTablePreferences.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setTablePreferencesToStorage" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setTablePreferencesToStorage requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "projectTablePreferences.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setTablePreferencesToStorage"}));
            Ok(())
        }
        "getDismissedBanners" => {
            let v = crate::hub_storage::read_json(data_dir, "dismissedBanners.json").unwrap_or(serde_json::json!([]));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setDismissedBanners" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setDismissedBanners requires JSON array".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "dismissedBanners.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setDismissedBanners"}));
            Ok(())
        }
        "getFirstTimeSettings" => {
            let v = crate::hub_storage::read_json(data_dir, "firstTimeSettings.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setFirstTimeSettings" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setFirstTimeSettings requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "firstTimeSettings.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setFirstTimeSettings"}));
            Ok(())
        }
        "getFirstTimeOpen" => { println!("{}", read_bool_pref(data_dir, "firstTimeOpenKey.json", false)); Ok(()) }
        "getProjectOrganizationSetting" | "getProjectOrganization" => {
            let v = crate::hub_storage::read_json(data_dir, "projectOrganizationSetting.json").unwrap_or(serde_json::json!({"organization": null}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setProjectOrganizationSetting" | "setProjectOrganization" => {
            let org = args.get(0).cloned().unwrap_or_default();
            let v = serde_json::json!({"organization": org});
            crate::hub_storage::write_json(data_dir, "projectOrganizationSetting.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setProjectOrganizationSetting","organization":v["organization"]}));
            Ok(())
        }
        "getViewedBanners" => {
            let v = crate::hub_storage::read_json(data_dir, "viewedBanners.json").unwrap_or(serde_json::json!([]));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setViewedBanners" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setViewedBanners requires JSON array".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "viewedBanners.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setViewedBanners"}));
            Ok(())
        }
        "getDismissedEditorWarningLabels" => {
            let v = crate::hub_storage::read_json(data_dir, "dismissedEditorWarningLabels.json").unwrap_or(serde_json::json!([]));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setDismissedEditorWarningLabels" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setDismissedEditorWarningLabels requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "dismissedEditorWarningLabels.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setDismissedEditorWarningLabels"}));
            Ok(())
        }
        "getExcludedEditorFolders" => {
            let v = crate::hub_storage::read_json(data_dir, "excludedEditorFolders.json").unwrap_or(serde_json::json!({"schema_version":"1","data":[]}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setExcludedEditorFolders" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setExcludedEditorFolders requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "excludedEditorFolders.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setExcludedEditorFolders"}));
            Ok(())
        }
        "getLocatedEditors" | "getEditorsRegistry" => {
            println!("{}", serde_json::to_string_pretty(&crate::services::editor_inventory::get_located_editors(data_dir)?)?);
            Ok(())
        }
        "setProjectCustomEditor" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("setProjectCustomEditor requires path".into()))?;
            let is_custom = args.get(1).map(|s| s=="true"||s=="1").unwrap_or(true);
            let reg_path = data_dir.join("projects-v1.json");
            let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
            let ok = if let Some(rec) = reg.data.get_mut(path) { rec.is_custom_editor = Some(is_custom); true } else { false };
            if ok { crate::hub_registry::save_projects_registry(&reg_path, &reg)?; }
            println!("{}", serde_json::json!({"ok":ok,"method":"setProjectCustomEditor","path":path,"isCustomEditor":is_custom}));
            Ok(())
        }
        "getProjectVersion" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("getProjectVersion requires path".into()))?;
            let ver = crate::projects::read_project_editor_version(Path::new(path));
            let reg = crate::hub_registry::load_projects_registry(&data_dir.join("projects-v1.json")).ok();
            let reg_ver = reg.as_ref().and_then(|r| r.data.get(path)).and_then(|r| r.version.clone());
            println!("{}", serde_json::json!({"path":path,"projectVersion":ver,"registryVersion":reg_ver,"isUnityProject":crate::projects::is_unity_project(Path::new(path))}));
            Ok(())
        }
        "getEditorTemplates" => {
            let editor = args.get(0).ok_or_else(|| crate::error::HubError::Other("getEditorTemplates requires editor version/path".into()))?;
            let install_path = if Path::new(editor).exists() { std::path::PathBuf::from(editor) } else if let Some(inst) = crate::installs::find_installed_editor(editor)? { std::path::PathBuf::from(inst.install_path) } else { println!("{}", serde_json::json!({"ok":false,"error":"editor not found","editor":editor})); return Ok(()); };
            let templates = crate::installs::list_editor_templates(&install_path)?;
            println!("{}", serde_json::json!({"ok":true,"editor":editor,"installPath":install_path.to_string_lossy(),"templates":templates}));
            Ok(())
        }
        "checkTemplateExists" => {
            let editor = args.get(0).ok_or_else(|| crate::error::HubError::Other("checkTemplateExists requires editor version/path".into()))?;
            let template = args.get(1).ok_or_else(|| crate::error::HubError::Other("checkTemplateExists requires template".into()))?;
            let install_path = if Path::new(editor).exists() { std::path::PathBuf::from(editor) } else if let Some(inst) = crate::installs::find_installed_editor(editor)? { std::path::PathBuf::from(inst.install_path) } else { println!("{}", serde_json::json!({"ok":false,"exists":false,"error":"editor not found","editor":editor,"template":template})); return Ok(()); };
            let resolved = crate::projects::resolve_template_path(&install_path, template);
            println!("{}", serde_json::json!({"ok":true,"editor":editor,"template":template,"exists":resolved.is_some(),"resolvedTemplatePath":resolved.map(|p| p.to_string_lossy().to_string())}));
            Ok(())
        }
        "getEditorExecutablePath" | "getEditorAppPath" => {
            let editor = args.get(0).ok_or_else(|| crate::error::HubError::Other("getEditorExecutablePath requires editor version/path".into()))?;
            let install_path = if Path::new(editor).exists() { std::path::PathBuf::from(editor) } else if let Some(inst) = crate::installs::find_installed_editor(editor)? { std::path::PathBuf::from(inst.install_path) } else { println!("{}", serde_json::json!({"ok":false,"error":"editor not found","editor":editor})); return Ok(()); };
            let exe = crate::installs::editor_executable_path(&install_path);
            println!("{}", serde_json::json!({"ok":true,"editor":editor,"installPath":install_path.to_string_lossy(),"editorExecutable":exe.to_string_lossy(),"exists":exe.is_file()}));
            Ok(())
        }
        "getEditorModules" | "getModules" | "getInstalledModules" => {
            let editor = args.get(0).ok_or_else(|| crate::error::HubError::Other("getEditorModules requires editor version/path".into()))?;
            match crate::installs::get_editor_modules(editor) {
                Ok((install_path, modules)) => {
                    let (count, installed_count) = match &modules {
                        Some(serde_json::Value::Array(arr)) => {
                            let installed = arr.iter().filter(|m| m.get("isInstalled").and_then(|v| v.as_bool()).unwrap_or(false)).count();
                            (arr.len(), Some(installed))
                        }
                        _ => (0, None),
                    };
                    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
                        "ok": true,
                        "editor": editor,
                        "installPath": install_path.to_string_lossy(),
                        "modulesJsonExists": modules.is_some(),
                        "moduleCount": count,
                        "installedModuleCount": installed_count,
                        "modules": modules.unwrap_or(serde_json::Value::Null)
                    }))?);
                }
                Err(e) => {
                    println!("{}", serde_json::json!({"ok":false,"editor":editor,"error":e.to_string()}));
                }
            }
            Ok(())
        }
        "getDefaultProjectsLocation" | "getProjectPath" => {
            let v = crate::hub_storage::read_json(data_dir, "projectDir.json").unwrap_or(serde_json::json!({"directoryPath":""}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "launchProject" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("launchProject requires path".into()))?;
            let extra = if args.len() > 1 { args[1..].to_vec() } else { vec![] };
            crate::commands::project_open(path, Some(&data_dir.to_string_lossy()), true, &extra)?;
            Ok(())
        }
        "validateProjectPath" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("validateProjectPath requires path".into()))?;
            let p = Path::new(path);
            let exists = p.exists();
            let is_unity = crate::projects::is_unity_project(p);
            let parent_exists = p.parent().map(|x| x.exists()).unwrap_or(false);
            println!("{}", serde_json::json!({"ok":true,"path":path,"exists":exists,"isUnityProject":is_unity,"parentExists":parent_exists}));
            Ok(())
        }
        "getOpenProjectPlan" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("getOpenProjectPlan requires path".into()))?;
            crate::commands::project_open_plan(path, Some(&data_dir.to_string_lossy()), false)?;
            Ok(())
        }
        "getCreateProjectPlan" => {
            let project_path = args.get(0).ok_or_else(|| crate::error::HubError::Other("getCreateProjectPlan requires project path".into()))?;
            let editor_version = args.get(1).ok_or_else(|| crate::error::HubError::Other("getCreateProjectPlan requires editor version".into()))?;
            let template = args.get(2).ok_or_else(|| crate::error::HubError::Other("getCreateProjectPlan requires template".into()))?;
            crate::commands::project_create_plan(project_path, editor_version, template, args.get(3).map(|s| s.as_str()), args.get(4).map(|s| s.as_str()))?;
            Ok(())
        }
        "openProjectWithEditor" | "openProjectLaunch" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("openProjectLaunch requires path".into()))?;
            let extra = if args.len() > 1 { args[1..].to_vec() } else { vec![] };
            crate::commands::project_open(path, Some(&data_dir.to_string_lossy()), true, &extra)?;
            Ok(())
        }
        "createProject" => {
            let project_path = args.get(0).ok_or_else(|| crate::error::HubError::Other("createProject requires project path".into()))?;
            let editor_version = args.get(1).ok_or_else(|| crate::error::HubError::Other("createProject requires editor version".into()))?;
            let template = args.get(2).ok_or_else(|| crate::error::HubError::Other("createProject requires template".into()))?;
            crate::commands::project_create(project_path, editor_version, template, args.get(3).map(|s| s.as_str()), args.get(4).map(|s| s.as_str()), false)?;
            Ok(())
        }
        "isUnityProject" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("isUnityProject requires path".into()))?;
            println!("{}", serde_json::json!({"path":path,"isUnityProject":crate::projects::is_unity_project(Path::new(path))}));
            Ok(())
        }
        "getProjectFromPath" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("getProjectFromPath requires path".into()))?;
            if let Some(v) = crate::services::local_project::get_registry_project(data_dir, path)? {
                println!("{}", serde_json::to_string_pretty(&v)?);
            } else if crate::projects::is_unity_project(Path::new(path)) {
                let (version, revision) = crate::projects::read_project_version_info(Path::new(path)).unwrap_or((None,None));
                println!("{}", serde_json::to_string_pretty(&serde_json::json!({"path":path,"title":Path::new(path).file_name().and_then(|n| n.to_str()).unwrap_or("Project"),"version":version,"changeset":revision,"isUnityProject":true,"inRegistry":false}))?);
            } else {
                println!("{}", serde_json::json!({"ok":false,"path":path,"found":false}));
            }
            Ok(())
        }
        "refreshProject" | "refreshProjectInfo" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("refreshProject requires path".into()))?;
            let (rec, added) = crate::services::local_project::refresh_project(data_dir, path)?;
            println!("{}", serde_json::json!({
                "ok": true,
                "method": "refreshProject",
                "path": path,
                "added": added,
                "title": rec.title,
                "version": rec.version,
                "changeset": rec.changeset,
                "lastModified": rec.last_modified
            }));
            Ok(())
        }
        "getInstalledEditorsDetailed" => {
            let installs = crate::installs::installed_editors()?;
            let detailed: Vec<serde_json::Value> = installs.into_iter().map(|e| {
                let install_path = std::path::PathBuf::from(&e.install_path);
                let modules = crate::installs::read_editor_modules(&install_path).ok().flatten();
                let (module_count, installed_module_count) = match &modules {
                    Some(serde_json::Value::Array(arr)) => {
                        let installed = arr.iter().filter(|m| m.get("isInstalled").and_then(|v| v.as_bool()).unwrap_or(false)).count();
                        (Some(arr.len()), Some(installed))
                    }
                    _ => (None, None),
                };
                serde_json::json!({
                    "version": e.version,
                    "installPath": e.install_path,
                    "executablePath": crate::installs::editor_executable_path(&install_path).to_string_lossy(),
                    "moduleCount": module_count,
                    "installedModuleCount": installed_module_count
                })
            }).collect();
            println!("{}", serde_json::to_string_pretty(&serde_json::Value::Array(detailed))?);
            Ok(())
        }
        "getDownloadableEditorsCache" | "getAvailableReleasesCache" | "getReleasesCacheSummary" => {
            match crate::updates::read_downloadable_editors_cache(data_dir)? {
                Some((path, cache)) => {
                    let summary = crate::updates::summarize_downloadable_editors(&cache);
                    println!("{}", serde_json::to_string_pretty(&serde_json::json!({"ok":true,"cachePath":path.to_string_lossy(),"summary":summary}))?);
                }
                None => {
                    println!("{}", serde_json::json!({"ok":false,"error":"downloadable editors cache not found","dataDir":data_dir.to_string_lossy()}));
                }
            }
            Ok(())
        }
        "getCachedRelease" | "planCachedReleaseInstall" => {
            let version = args.get(0).ok_or_else(|| crate::error::HubError::Other("getCachedRelease requires version".into()))?;
            match crate::updates::read_downloadable_editors_cache(data_dir)? {
                Some((path, cache)) => {
                    let result = crate::updates::plan_cached_release_install(&cache, version, data_dir);
                    println!("{}", serde_json::to_string_pretty(&serde_json::json!({"cachePath":path.to_string_lossy(),"result":result}))?);
                }
                None => {
                    println!("{}", serde_json::json!({"ok":false,"error":"downloadable editors cache not found","version":version}));
                }
            }
            Ok(())
        }
        "queueCachedReleaseInstall" | "installQueueCachedRelease" => {
            let version = args.get(0).ok_or_else(|| crate::error::HubError::Other("queueCachedReleaseInstall requires version".into()))?;
            let uid = args.get(1).map(|s| s.as_str());
            let modules = args.get(2).map(|s| s.as_str()).unwrap_or("[]");
            crate::commands::install_queue_cached_release(Some(&data_dir.to_string_lossy()), version, uid, Some(modules))?;
            Ok(())
        }
        "getEditorInstallStatus" => {
            let version = args.get(0).ok_or_else(|| crate::error::HubError::Other("getEditorInstallStatus requires version".into()))?;
            crate::commands::editor_install_status(Some(&data_dir.to_string_lossy()), version)?;
            Ok(())
        }
        "getCachedReleaseInstallPlan" | "planCachedReleaseInstallExecution" => {
            let version = args.get(0).ok_or_else(|| crate::error::HubError::Other("getCachedReleaseInstallPlan requires version".into()))?;
            crate::commands::install_plan_cached_release(Some(&data_dir.to_string_lossy()), version)?;
            Ok(())
        }
        "installModuleLocal" | "installModule" => {
            // args: uid, version, url, dest_zip, module_type, destination_template, unity_path, integrity, [expected_bytes]
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("installModule requires uid".into()))?;
            let version = args.get(1).ok_or_else(|| crate::error::HubError::Other("installModule requires version".into()))?;
            let url = args.get(2).ok_or_else(|| crate::error::HubError::Other("installModule requires url".into()))?;
            let dest_zip = args.get(3).ok_or_else(|| crate::error::HubError::Other("installModule requires dest".into()))?;
            let module_type = args.get(4).ok_or_else(|| crate::error::HubError::Other("installModule requires type".into()))?;
            let destination = args.get(5).map(|s| s.as_str());
            let unity_path = args.get(6).map(|s| s.as_str());
            let integrity = args.get(7).map(|s| s.as_str());
            let expected = args.get(8).and_then(|s| s.parse::<i64>().ok());
            crate::commands::install_module_local(Some(&data_dir.to_string_lossy()), uid, version, url, dest_zip, module_type, destination, unity_path, None, None, integrity, None, Some("[]"), expected)?;
            Ok(())
        }
        "downloadUrlToFile" | "installDownload" => {
            // args: uid, version, url, dest, [arch], [modules_json], [expected_bytes]
            let uid = args.get(0).ok_or_else(|| crate::error::HubError::Other("installDownload requires uid".into()))?;
            let version = args.get(1).ok_or_else(|| crate::error::HubError::Other("installDownload requires version".into()))?;
            let url = args.get(2).ok_or_else(|| crate::error::HubError::Other("installDownload requires url".into()))?;
            let dest = args.get(3).ok_or_else(|| crate::error::HubError::Other("installDownload requires dest".into()))?;
            let arch = args.get(4).map(|s| s.as_str());
            let modules = args.get(5).map(|s| s.as_str()).unwrap_or("[]");
            let expected = args.get(6).and_then(|s| s.parse::<i64>().ok());
            crate::commands::install_download(Some(&data_dir.to_string_lossy()), uid, version, url, dest, arch, Some(modules), expected, true)?;
            Ok(())
        }
        "getAppVersion" | "getHubVersion" => { println!("{}", serde_json::json!("3.22.6")); Ok(()) }
        "getAppInfo" => {
            println!("{}", serde_json::to_string_pretty(&serde_json::json!({"appName":"unity-hub","appVersion":env!("CARGO_PKG_VERSION"),"electronAppName":"unity-hub","electronAppVersion":"3.22.6"}))?);
            Ok(())
        }
        "getDataDir" | "getHubDataDir" => { println!("{}", serde_json::json!(data_dir.to_string_lossy())); Ok(()) }
        "getOnboardingSurveySettings" | "getSurveySettings" => {
            let v = crate::hub_storage::read_json(data_dir, "surveySettings.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setOnboardingSurveySettings" | "setSurveySettings" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setOnboardingSurveySettings requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "surveySettings.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setOnboardingSurveySettings"}));
            Ok(())
        }
        "getTemplateSettingsFromStorage" | "getTemplateSettings" => {
            let v = crate::hub_storage::read_json(data_dir, "templatesSettings.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setTemplateSettingsToStorage" | "setTemplateSettings" => {
            let json = args.get(0).ok_or_else(|| crate::error::HubError::Other("setTemplateSettingsToStorage requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, "templatesSettings.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setTemplateSettingsToStorage"}));
            Ok(())
        }
        "getOrganizationSettings" => {
            let v = crate::hub_storage::read_json(data_dir, "projectOrganizationSetting.json").unwrap_or(serde_json::json!({"organization": null}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setOrganizationSettings" => {
            let json = args.get(0).cloned().unwrap_or_else(|| "{}".to_string());
            let v: Value = serde_json::from_str(&json).unwrap_or(Value::String(json));
            crate::hub_storage::write_json(data_dir, "projectOrganizationSetting.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setOrganizationSettings"}));
            Ok(())
        }
        "getCloudConfig" => {
            let v = crate::hub_storage::read_json(data_dir, "cloudConfig.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getHubInfo" => {
            let v = crate::hub_storage::read_json(data_dir, "hubInfo.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getCachedFeatureFlags" | "getFeatureFlags" => {
            let v = crate::hub_storage::read_json(data_dir, "cachedFeatureFlags.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getCliPluginRegistry" => {
            let v = crate::hub_storage::read_json(data_dir, "cli-plugin-registry.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getCliUpdateCheck" => {
            let v = crate::hub_storage::read_json(data_dir, "cli-update-check.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getUserSettings" => {
            let v = crate::hub_storage::read_json(data_dir, "user-settings.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "showItemInFolder" | "revealInFinder" | "openFolder" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("showItemInFolder requires path".into()))?;
            #[cfg(target_os = "windows")]
            {
                if Path::new(path).is_file() {
                    let _ = std::process::Command::new("explorer").args(["/select,", path]).spawn();
                } else {
                    let _ = std::process::Command::new("explorer").arg(path).spawn();
                }
            }
            println!("{}", serde_json::json!({"ok":true,"method":"showItemInFolder","path":path}));
            Ok(())
        }
        "getStorageJson" => {
            let file = args.get(0).ok_or_else(|| crate::error::HubError::Other("getStorageJson requires filename".into()))?;
            let v = crate::hub_storage::read_json(data_dir, file).unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setStorageJson" => {
            let file = args.get(0).ok_or_else(|| crate::error::HubError::Other("setStorageJson requires filename".into()))?;
            let json = args.get(1).ok_or_else(|| crate::error::HubError::Other("setStorageJson requires JSON payload".into()))?;
            let v: Value = serde_json::from_str(json)?;
            crate::hub_storage::write_json(data_dir, file, &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setStorageJson","file":file}));
            Ok(())
        }
        "downloadManagerUtilities" => {
            let action = args.get(0).map(|s| s.as_str()).unwrap_or("status");
            match action {
                "getDownloadsState" | "status" => { println!("{}", serde_json::to_string_pretty(&crate::install_state::read_table_json(data_dir, "downloads")?)?); }
                "getInstallState" => { println!("{}", serde_json::to_string_pretty(&crate::install_state::read_table_json(data_dir, "installs")?)?); }
                "getPausedDownloads" => { let v = crate::hub_storage::read_json(data_dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1})); println!("{}", serde_json::to_string_pretty(&v)?); }
                _ => { println!("{}", serde_json::json!({"ok":true,"method":"downloadManagerUtilities","action":action,"result":null,"note":"action not fully implemented"})); }
            }
            Ok(())
        }
        "getFeaturedLearnItems" | "getLearnItems" | "getRecommendedLearnItems" => { println!("[]"); Ok(()) }
        "getTemplates" => { println!("[]"); Ok(()) }
        "getTemplatesForEditor" | "getLocalTemplatesForEditor" => {
            let editor = args.get(0).map(|s| s.as_str()).unwrap_or("");
            if editor.is_empty() { println!("[]"); return Ok(()); }
            let install_path = if Path::new(editor).exists() { std::path::PathBuf::from(editor) } else if let Some(inst) = crate::installs::find_installed_editor(editor)? { std::path::PathBuf::from(inst.install_path) } else { println!("[]"); return Ok(()); };
            let templates = crate::installs::list_editor_templates(&install_path).unwrap_or_default();
            println!("{}", serde_json::to_string_pretty(&templates)?);
            Ok(())
        }
        "getTemplateCategories" => { println!("[]"); Ok(()) }
        "getTemplateFromProjectCount" => { println!("0"); Ok(()) }
        "getFloatingConfigStatus" => { println!("{}", serde_json::json!({"enabled":false})); Ok(()) }
        "getCloudProjectLookup" | "getCloudProjectsByOrganization" => { println!("[]"); Ok(()) }
        "setPrivacySettings" => {
            let json = args.get(0).unwrap_or(&"{}".to_string()).clone();
            let v: Value = serde_json::from_str(&json).unwrap_or(Value::String(json));
            crate::hub_storage::write_json(data_dir, "privacySettings.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setPrivacySettings"}));
            Ok(())
        }
        "getPrivacySettings" => {
            let v = crate::hub_storage::read_json(data_dir, "privacySettings.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getCurrentLocale" => {
            let v = crate::hub_storage::read_json(data_dir, "languageConfig.json").unwrap_or(serde_json::json!({"language":"en"}));
            let lang = v.get("language").and_then(|x| x.as_str()).unwrap_or("en");
            println!("{}", serde_json::json!(lang));
            Ok(())
        }
        "getOperatingSystem" | "getProcessPlatform" => {
            println!("{}", serde_json::json!(std::env::consts::OS));
            Ok(())
        }
        "isAppleSilicon" => { println!("false"); Ok(()) }
        "isWindowsArm64" => { println!("{}", serde_json::json!(cfg!(all(windows, target_arch = "aarch64")))); Ok(()) }
        "isPackaged" => { println!("false"); Ok(()) }
        "getTheme" => {
            let v = crate::hub_storage::read_json(data_dir, "theme.json").unwrap_or(serde_json::json!("system"));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setThemeSource" | "setTheme" => {
            let theme = args.get(0).cloned().unwrap_or_else(|| "system".to_string());
            let v = serde_json::Value::String(theme.clone());
            crate::hub_storage::write_json(data_dir, "theme.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setThemeSource","theme":theme}));
            Ok(())
        }
        "getUserSetting" => {
            let key = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let root = crate::hub_storage::read_json(data_dir, "user-settings.json").unwrap_or(serde_json::json!({}));
            if key.is_empty() { println!("{}", serde_json::to_string_pretty(&root)?); }
            else { println!("{}", serde_json::to_string_pretty(root.get(key).unwrap_or(&Value::Null))?); }
            Ok(())
        }
        "setUserSetting" => {
            let key = args.get(0).ok_or_else(|| crate::error::HubError::Other("setUserSetting requires key".into()))?;
            let value_raw = args.get(1).cloned().unwrap_or_else(|| "null".to_string());
            let value: Value = serde_json::from_str(&value_raw).unwrap_or(Value::String(value_raw));
            let mut root = crate::hub_storage::read_json(data_dir, "user-settings.json").unwrap_or(serde_json::json!({}));
            if !root.is_object() { root = serde_json::json!({}); }
            root.as_object_mut().unwrap().insert(key.to_string(), value);
            crate::hub_storage::write_json(data_dir, "user-settings.json", &root)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setUserSetting","key":key}));
            Ok(())
        }
        "getIsNotificationsEnabled" | "getIsNotificationsPopupsShown" | "getIsNotificationsSilent" => {
            let file = match method { "getIsNotificationsPopupsShown" => "notificationsPopups.json", "getIsNotificationsSilent" => "notificationsSilent.json", _ => "notificationsEnabled.json" };
            let v = crate::hub_storage::read_json(data_dir, file).unwrap_or(Value::Bool(true));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setIsNotificationsEnabled" | "setIsNotificationsPopupsShown" | "setIsNotificationsSilent" => {
            let val = args.get(0).map(|s| s == "true" || s == "1").unwrap_or(true);
            let file = match method { "setIsNotificationsPopupsShown" => "notificationsPopups.json", "setIsNotificationsSilent" => "notificationsSilent.json", _ => "notificationsEnabled.json" };
            crate::hub_storage::write_json(data_dir, file, &Value::Bool(val))?;
            println!("{}", serde_json::json!({"ok":true,"method":method,"value":val}));
            Ok(())
        }
        "getLastUsedOrganizationFromStorage" => {
            let v = crate::hub_storage::read_json(data_dir, "lastUsedOrganization.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setLastUsedOrganizationToStorage" => {
            let raw = args.get(0).cloned().unwrap_or_else(|| "null".to_string());
            let v: Value = serde_json::from_str(&raw).unwrap_or(Value::String(raw));
            crate::hub_storage::write_json(data_dir, "lastUsedOrganization.json", &v)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setLastUsedOrganizationToStorage"}));
            Ok(())
        }
        "getDaysSinceAppWasInstalled" => {
            let v = crate::hub_storage::read_json(data_dir, "install-date.json").unwrap_or(Value::Null);
            if let Some(ms) = v.as_i64().or_else(|| v.get("timestamp").and_then(|x| x.as_i64())) {
                let now = crate::hub_registry::now_millis();
                let days = ((now - ms).max(0) / 86_400_000) as i64;
                println!("{}", serde_json::json!(days));
            } else {
                println!("0");
            }
            Ok(())
        }
        "getLogDirectory" => {
            let p = data_dir.join("logs");
            println!("{}", serde_json::json!(p.to_string_lossy()));
            Ok(())
        }
        "getResourcesPath" => {
            let p = std::env::current_exe().ok().and_then(|e| e.parent().map(|p| p.to_path_buf())).unwrap_or_else(|| std::path::PathBuf::from("."));
            println!("{}", serde_json::json!(p.to_string_lossy()));
            Ok(())
        }
        "getUserTemplatesLocation" => {
            let v = crate::hub_storage::read_json(data_dir, "templatesSettings.json").unwrap_or(serde_json::json!({"defaultPath":"", "sources":{}}));
            let p = v.get("defaultPath").cloned().unwrap_or(Value::String(String::new()));
            println!("{}", serde_json::to_string_pretty(&p)?);
            Ok(())
        }
        "getDownloadableEditorsList" | "getDownloadableEditors" => {
            match crate::updates::read_downloadable_editors_cache(data_dir)? {
                Some((path, cache)) => {
                    let summary = crate::updates::summarize_downloadable_editors(&cache);
                    println!("{}", serde_json::to_string_pretty(&serde_json::json!({"ok":true,"cachePath":path.to_string_lossy(),"summary":summary}))?);
                }
                None => println!("{}", serde_json::json!({"ok":false,"error":"downloadable editors cache not found"})),
            }
            Ok(())
        }
        "isAbsolute" => {
            let p = args.get(0).map(|s| s.as_str()).unwrap_or("");
            println!("{}", serde_json::json!(Path::new(p).is_absolute()));
            Ok(())
        }
        "getMaxPathLength" => { println!("{}", if cfg!(windows) { 260 } else { 4096 }); Ok(()) }
        "getMaxFilenameLength" => { println!("{}", if cfg!(windows) { 255 } else { 255 }); Ok(()) }
        "getUniqueProjectName" => {
            let base = args.get(0).ok_or_else(|| crate::error::HubError::Other("getUniqueProjectName requires base path".into()))?;
            let p = Path::new(base);
            if !p.exists() { println!("{}", serde_json::json!(base)); return Ok(()); }
            let parent = p.parent().unwrap_or(Path::new("."));
            let name = p.file_name().and_then(|n| n.to_str()).unwrap_or("Project");
            let mut i = 1;
            loop {
                let cand = parent.join(format!("{} {}", name, i));
                if !cand.exists() { println!("{}", serde_json::json!(cand.to_string_lossy())); break; }
                i += 1;
                if i > 10000 { println!("{}", serde_json::json!(base)); break; }
            }
            Ok(())
        }
        "getDiskSpaceAvailable" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or(".");
            #[cfg(windows)]
            {
                let drive = Path::new(path).components().next().and_then(|c| c.as_os_str().to_str()).unwrap_or("C:");
                let letter = drive.chars().next().unwrap_or('C');
                let script = format!("(Get-PSDrive -Name {}).Free", letter);
                let out = std::process::Command::new("powershell").args(["-NoProfile","-Command",&script]).output();
                match out {
                    Ok(o) if o.status.success() => {
                        let s = String::from_utf8_lossy(&o.stdout).trim().to_string();
                        if let Ok(n) = s.parse::<i64>() { println!("{}", serde_json::json!({"ok":true,"path":path,"available":n})); }
                        else { println!("{}", serde_json::json!({"ok":true,"path":path,"available":s})); }
                    }
                    _ => { println!("{}", serde_json::json!({"ok":false,"path":path,"available":null})); }
                }
            }
            #[cfg(not(windows))]
            { println!("{}", serde_json::json!({"ok":false,"path":path,"available":null})); }
            Ok(())
        }
        "has" | "hasOwn" | "isPresent" => {
            let key = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let obj_raw = args.get(1).cloned().unwrap_or_else(|| "{}".to_string());
            let obj: Value = serde_json::from_str(&obj_raw).unwrap_or(Value::Null);
            let exists = obj.get(key).map(|v| !v.is_null()).unwrap_or(false);
            println!("{}", serde_json::json!(exists));
            Ok(())
        }
        "isArray" => {
            let raw = args.get(0).cloned().unwrap_or_else(|| "null".to_string());
            let v: Value = serde_json::from_str(&raw).unwrap_or(Value::Null);
            println!("{}", serde_json::json!(v.is_array()));
            Ok(())
        }
        "isValidPath" => {
            let p = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let ok = !p.is_empty() && !p.chars().any(|c| ['<','>','"','|','?','*'].contains(&c));
            println!("{}", serde_json::json!(ok));
            Ok(())
        }
        "isValidFilename" => {
            let p = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let bad = ['<','>','"',':','/','\\','|','?','*'];
            let ok = !p.is_empty() && !p.chars().any(|c| bad.contains(&c));
            println!("{}", serde_json::json!(ok));
            Ok(())
        }
        "getUnityProjects" => {
            println!("{}", serde_json::to_string_pretty(&get_projects_info(data_dir)?)?);
            Ok(())
        }
        "getUnityCLILatestVersion" => {
            let v = crate::hub_storage::read_json(data_dir, "cli-install.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getFlags" | "getCachedFlags" => {
            let v = crate::hub_storage::read_json(data_dir, "cachedFeatureFlags.json").unwrap_or(serde_json::json!({}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getFlagByName" | "getDefaultFlag" => {
            let name = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let flags = crate::hub_storage::read_json(data_dir, "cachedFeatureFlags.json").unwrap_or(serde_json::json!({}));
            let val = flags.get(name)
                .or_else(|| flags.get("flags").and_then(|f| f.get(name)))
                .or_else(|| flags.get("data").and_then(|f| f.get(name)))
                .cloned().unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&val)?);
            Ok(())
        }
        "getEulaText" | "getTermsOfServiceText" => {
            // best-effort: look for known storage files
            for f in ["eula.json", "EULA.txt", "eula.txt", "terms.json", "tos.txt"] {
                let p = data_dir.join(f);
                if p.exists() {
                    if let Ok(s) = std::fs::read_to_string(&p) {
                        if let Ok(v) = serde_json::from_str::<Value>(&s) { println!("{}", serde_json::to_string_pretty(&v)?); }
                        else { println!("{}", serde_json::json!(s)); }
                        return Ok(());
                    }
                }
            }
            println!("null");
            Ok(())
        }
        "getUsersLicense" | "getLicense" => {
            for f in ["license.json", "licenses.json", "Unity_lic.ulf", "license.ulf"] {
                let p = data_dir.join(f);
                if p.exists() {
                    if let Ok(s) = std::fs::read_to_string(&p) {
                        if let Ok(v) = serde_json::from_str::<Value>(&s) { println!("{}", serde_json::to_string_pretty(&v)?); }
                        else { println!("{}", serde_json::json!({"path": p.to_string_lossy(), "raw": s})); }
                        return Ok(());
                    }
                }
            }
            println!("null");
            Ok(())
        }
        "isLicenseValid" => { println!("false"); Ok(()) }
        "isFloatingEnabled" => { println!("false"); Ok(()) }
        "getFloatingLicenseServerUrl" => { println!("null"); Ok(()) }
        "getHasPlastic" | "getIsUnityVersionControl" => { println!("false"); Ok(()) }
        "getIsPerforce" => { println!("false"); Ok(()) }
        "isGitAvailable" => {
            let ok = std::process::Command::new("git").arg("--version").output().map(|o| o.status.success()).unwrap_or(false);
            println!("{}", serde_json::json!(ok)); Ok(())
        }
        "isGitLfsAvailable" => {
            let ok = std::process::Command::new("git").args(["lfs","version"]).output().map(|o| o.status.success()).unwrap_or(false);
            println!("{}", serde_json::json!(ok)); Ok(())
        }
        "isP4Available" => {
            let ok = std::process::Command::new("p4").arg("-V").output().map(|o| o.status.success()).unwrap_or(false);
            println!("{}", serde_json::json!(ok)); Ok(())
        }
        "getAvailableReleaseChannels" | "getAvailableUpdateServers" => {
            match crate::updates::read_downloadable_editors_cache(data_dir)? {
                Some((_p, cache)) => {
                    let mut keys: Vec<String> = Vec::new();
                    if let Some(entries) = cache.get("entries").and_then(|v| v.as_object()) {
                        if let Some(entry) = entries.values().next() {
                            if let Some(data) = entry.get("payload").and_then(|p| p.get("data")).and_then(|d| d.as_object()) {
                                keys = data.keys().cloned().collect();
                                keys.sort();
                            }
                        }
                    }
                    println!("{}", serde_json::to_string_pretty(&keys)?);
                }
                None => println!("[]"),
            }
            Ok(())
        }
        "getChannel" | "getPreselectedChannel" | "getDefaultReleaseChannel" => {
            println!("{}", serde_json::json!("LTS")); Ok(())
        }
        "getReleaseNotes" => { println!("[]"); Ok(()) }
        "getOrganizations" | "getIdentities" | "getConnectedEditor" => { println!("[]"); Ok(()) }
        "getUserInfo" => {
            let v = crate::hub_storage::read_json(data_dir, "userInfo.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getCredential" => { println!("null"); Ok(()) }
        "setCredential" | "removeCredential" => { println!("{}", serde_json::json!({"ok":false,"method":method,"note":"credential storage not implemented"})); Ok(()) }
        "refreshLicenses" | "activateLicense" | "returnLicense" | "returnAllEntitlementBasedLicenses" => {
            println!("{}", serde_json::json!({"ok":false,"method":method,"note":"license service not implemented (requires Unity licensing runtime/auth)"}));
            Ok(())
        }
        "checkForUpdate" | "checkIfEntitledToEditor" | "getEditorEntitlementDecision" => {
            println!("{}", serde_json::json!({"ok":false,"method":method,"note":"update/entitlement service not implemented"}));
            Ok(())
        }
        "logout" | "openSignIn" | "openSignUp" => {
            println!("{}", serde_json::json!({"ok":false,"method":method,"note":"auth/UI flow not implemented"}));
            Ok(())
        }
        "getLogFilePath" => {
            let p = data_dir.join("logs").join("info-log.json");
            println!("{}", serde_json::json!(p.to_string_lossy())); Ok(())
        }
        "getUserAccessToken" | "getUnityTokenValue" | "getUnityEditorAuthSessionValue" | "getUnityHubAuthSessionValue" => {
            println!("null"); Ok(())
        }
        "isHelperAvailable" | "isGitHelperAvailable" => {
            let ok = std::process::Command::new("git").arg("--version").output().map(|o| o.status.success()).unwrap_or(false);
            println!("{}", serde_json::json!(ok)); Ok(())
        }
        "getGitVersion" => {
            let out = std::process::Command::new("git").arg("--version").output().ok().filter(|o| o.status.success()).map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string());
            println!("{}", serde_json::json!(out)); Ok(())
        }
        "getGitLfsVersion" => {
            let out = std::process::Command::new("git").args(["lfs","version"]).output().ok().filter(|o| o.status.success()).map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string());
            println!("{}", serde_json::json!(out)); Ok(())
        }
        "getVcsList" => { println!("[]"); Ok(()) }
        "getServerFingerprint" => { println!("null"); Ok(()) }
        "getWindowState" => { println!("{}", serde_json::json!({"maximized":false,"fullscreen":false})); Ok(()) }
        "isMainWindowMaximized" | "isMainWindowFullScreen" => { println!("false"); Ok(()) }
        "minimizeMainWindow" | "maximizeMainWindow" | "restoreMainWindow" | "closeWindow" => {
            println!("{}", serde_json::json!({"ok":false,"method":method,"note":"window management not implemented (no GUI runtime)"})); Ok(())
        }
        "openPath" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or("");
            if path.is_empty() { println!("{}", serde_json::json!({"ok":false,"error":"path required"})); return Ok(()); }
            #[cfg(windows)]
            let r = std::process::Command::new("explorer.exe").arg(path).spawn();
            #[cfg(not(windows))]
            let r = std::process::Command::new("xdg-open").arg(path).spawn();
            println!("{}", serde_json::json!({"ok": r.is_ok(), "method":"openPath", "path": path}));
            Ok(())
        }
        "pathExists" | "fileExists" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or("");
            println!("{}", serde_json::json!(Path::new(path).exists()));
            Ok(())
        }
        "readText" | "readFileText" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("readText requires path".into()))?;
            let s = std::fs::read_to_string(path).map_err(|e| crate::error::HubError::Other(format!("readText failed: {e}")))?;
            println!("{}", serde_json::json!(s));
            Ok(())
        }
        "statPath" | "getPathInfo" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let p = Path::new(path);
            if let Ok(m) = std::fs::metadata(p) {
                println!("{}", serde_json::json!({"exists":true,"isFile":m.is_file(),"isDir":m.is_dir(),"len":m.len(),"readonly":m.permissions().readonly()}));
            } else {
                println!("{}", serde_json::json!({"exists":false}));
            }
            Ok(())
        }
        "getIsUpdateCheckOnly" | "getIsAIFeatureEnabled" | "getIsChatEnabled" | "getIsLinksEnabled" => { println!("false"); Ok(()) }
        "setIsUpdateCheckOnly" | "setIsAIFeatureEnabled" | "setIsChatEnabled" | "setIsLinksEnabled" => {
            println!("{}", serde_json::json!({"ok":true,"method":method,"note":"setting accepted as no-op/local stub"})); Ok(())
        }
        "getUniqueIdentifier" => {
            let version = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let arch = args.get(1).map(|s| s.as_str()).unwrap_or("x86_64");
            println!("{}", serde_json::json!(format!("{}-{}", version, arch)));
            Ok(())
        }
        "getCustomEditorInfo" => {
            let v = crate::hub_storage::read_json(data_dir, "customEditorInfo.json").unwrap_or(serde_json::json!({}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setCustomEditorInfo" => {
            let key = args.get(0).cloned().unwrap_or_default();
            let raw = args.get(1).cloned().unwrap_or_else(|| "{}".to_string());
            let val: Value = serde_json::from_str(&raw).unwrap_or(Value::String(raw));
            let mut root = crate::hub_storage::read_json(data_dir, "customEditorInfo.json").unwrap_or(serde_json::json!({}));
            if !root.is_object() { root = serde_json::json!({}); }
            if key.is_empty() { root = val; } else { root.as_object_mut().unwrap().insert(key, val); }
            crate::hub_storage::write_json(data_dir, "customEditorInfo.json", &root)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setCustomEditorInfo"}));
            Ok(())
        }
        "clearCustomEditorInfo" => {
            crate::hub_storage::write_json(data_dir, "customEditorInfo.json", &serde_json::json!({}))?;
            println!("{}", serde_json::json!({"ok":true,"method":"clearCustomEditorInfo"}));
            Ok(())
        }
        "getEditorLabels" => {
            let v = crate::hub_storage::read_json(data_dir, "editorLabels.json").unwrap_or(serde_json::json!({}));
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "setEditorLabels" => {
            let raw = args.get(0).cloned().unwrap_or_else(|| "{}".to_string());
            let val: Value = serde_json::from_str(&raw).unwrap_or(Value::String(raw));
            crate::hub_storage::write_json(data_dir, "editorLabels.json", &val)?;
            println!("{}", serde_json::json!({"ok":true,"method":"setEditorLabels"}));
            Ok(())
        }
        "checkNewTemplatePath" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let p = Path::new(path);
            let exists = p.exists();
            let is_dir = p.is_dir();
            let is_empty = if is_dir { std::fs::read_dir(p).map(|mut i| i.next().is_none()).unwrap_or(false) } else { !exists };
            println!("{}", serde_json::json!({"path":path,"exists":exists,"isDir":is_dir,"isEmpty":is_empty,"ok": !exists || is_empty}));
            Ok(())
        }
        "getProjectSize" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or("");
            fn dir_size(p: &Path) -> u64 {
                let mut total = 0u64;
                if let Ok(entries) = std::fs::read_dir(p) {
                    for e in entries.flatten() {
                        let path = e.path();
                        if let Ok(m) = e.metadata() {
                            if m.is_file() { total = total.saturating_add(m.len()); }
                            else if m.is_dir() { total = total.saturating_add(dir_size(&path)); }
                        }
                    }
                }
                total
            }
            let size = dir_size(Path::new(path));
            println!("{}", serde_json::json!({"path":path,"size":size}));
            Ok(())
        }
        "getRepositoryRemoteUrl" | "getRepositoryUrlForProvider" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or(".");
            let out = std::process::Command::new("git").args(["-C", path, "remote", "get-url", "origin"]).output().ok();
            let url = out.filter(|o| o.status.success()).map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).filter(|s| !s.is_empty());
            println!("{}", serde_json::json!(url));
            Ok(())
        }
        "getCurrentBranchHead" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or(".");
            let out = std::process::Command::new("git").args(["-C", path, "rev-parse", "--abbrev-ref", "HEAD"]).output().ok();
            let branch = out.filter(|o| o.status.success()).map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).filter(|s| !s.is_empty());
            println!("{}", serde_json::json!(branch));
            Ok(())
        }
        "getCurrentBranchChangeset" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or(".");
            let out = std::process::Command::new("git").args(["-C", path, "rev-parse", "HEAD"]).output().ok();
            let sha = out.filter(|o| o.status.success()).map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).filter(|s| !s.is_empty());
            println!("{}", serde_json::json!(sha));
            Ok(())
        }
        "getStatus" | "getItemsStatus" => {
            let path = args.get(0).map(|s| s.as_str()).unwrap_or(".");
            let out = std::process::Command::new("git").args(["-C", path, "status", "--porcelain"]).output().ok();
            if let Some(o) = out.filter(|o| o.status.success()) {
                let s = String::from_utf8_lossy(&o.stdout).to_string();
                let lines: Vec<String> = s.lines().map(|l| l.to_string()).collect();
                println!("{}", serde_json::json!({"ok":true,"path":path,"clean":lines.is_empty(),"changes":lines}));
            } else {
                println!("{}", serde_json::json!({"ok":false,"path":path,"changes":[]}));
            }
            Ok(())
        }
        "hasEmptyAutosave" => { println!("false"); Ok(()) }
        "removeEmptyAutosave" => { println!("{}", serde_json::json!({"ok":true,"method":"removeEmptyAutosave","removed":false})); Ok(()) }
        "getAllTasks" => { println!("[]"); Ok(()) }
        "clearTask" | "cancelTask" => { println!("{}", serde_json::json!({"ok":true,"method":method})); Ok(()) }
        "getNamespaceOptions" | "getDepots" | "getStreams" | "getWorkspaces" | "listWorkspaces" => { println!("[]"); Ok(()) }
        "getStickyLicenseErrors" => { println!("[]"); Ok(()) }
        "getUnreadNotificationCount" => { println!("0"); Ok(()) }
        "getNotificationFeed" => { println!("[]"); Ok(()) }
        "getConnectionState" => { println!("{}", serde_json::json!({"connected":false,"state":"offline"})); Ok(()) }
        "getUser" => {
            let v = crate::hub_storage::read_json(data_dir, "userInfo.json").unwrap_or(Value::Null);
            println!("{}", serde_json::to_string_pretty(&v)?);
            Ok(())
        }
        "getUserOptedIn" => { println!("false"); Ok(()) }
        "getPointsBalance" => { println!("0"); Ok(()) }
        "getUnityProjectsFromRepo" => { println!("[]"); Ok(()) }
        "getWorkspaceInfo" | "getUVCSOrganization" => { println!("null"); Ok(()) }
        "hasCredential" => { println!("false"); Ok(()) }
        "isDiskSpaceAvailableForTemplate" => { println!("{}", serde_json::json!({"ok":true,"available":true})); Ok(()) }
        "isCanonicalSemver" => {
            let v = args.get(0).map(|s| s.as_str()).unwrap_or("");
            let ok = v.split('.').count() >= 2;
            println!("{}", serde_json::json!(ok)); Ok(())
        }
        "getEditorEntitlementDecision" => { println!("{}", serde_json::json!({"entitled":true,"decision":"unknown","note":"entitlement service unavailable; default allow for local planning"})); Ok(()) }
        "getEffectiveChipArchitecture" => {
            let arch = if cfg!(target_arch = "aarch64") { "arm64" } else { "x86_64" };
            println!("{}", serde_json::json!(arch)); Ok(())
        }
        "getCloudProjectsByOrganization" => { println!("[]"); Ok(()) }
        "writeText" | "writeFileText" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("writeText requires path".into()))?;
            let content = args.get(1).cloned().unwrap_or_default();
            if let Some(parent) = Path::new(path).parent() { let _ = std::fs::create_dir_all(parent); }
            std::fs::write(path, content)?;
            println!("{}", serde_json::json!({"ok":true,"method":"writeText","path":path}));
            Ok(())
        }
        "ensureDirectory" | "mkdirp" => {
            let path = args.get(0).ok_or_else(|| crate::error::HubError::Other("ensureDirectory requires path".into()))?;
            std::fs::create_dir_all(path)?;
            println!("{}", serde_json::json!({"ok":true,"method":"ensureDirectory","path":path}));
            Ok(())
        }
        _ => Err(crate::error::HubError::Other(format!("unimplemented ipc method: {method} (see `ipc channels`)"))),
    }
}
