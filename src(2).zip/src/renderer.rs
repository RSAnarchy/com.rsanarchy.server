//! Renderer hosting for Unity Hub 3.22 (Electron) windows.
//!
//! Serves the extracted 3.22 renderer bundles (`main_window`, `bug_reporter_window`)
//! over local HTTP on a tokio runtime and injects a bridge that reproduces the
//! Electron preload contract:
//!   * `window.api` (from `mainWindowPreload.cjs`) with `ipcRenderer.invoke/on/off`,
//!     `platform`, `getPathForFiles`, `notifyRendererReady` and `startup*` values.
//!   * `window.bugReporterApi` (from `bugReporterPreload.cjs`).
//! Startup values mirror what the 3.22 main process passes via `--hub-startup-*` argv,
//! read from the same `<key>.json` files in the Hub data directory.
//! `invoke` rejects on backend errors, as `ipcRenderer.invoke` does in Electron.

use crate::error::{HubError, Result};
use serde_json::{json, Value};
use std::fs;
use std::path::{Component, Path, PathBuf};
use std::process::Command;
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::broadcast;

#[derive(Debug, Clone)]
pub struct RendererWindow {
    pub name: String,
    pub dir: PathBuf,
    pub entry_html: String,
}

pub fn default_extracted_app_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("electron-hub-3.22")
        .join("app")
}

pub fn renderer_root(app_root: &Path) -> PathBuf {
    app_root.join(".vite").join("renderer")
}

pub fn list_windows(app_root: &Path) -> Result<Vec<RendererWindow>> {
    let root = renderer_root(app_root);
    if !root.is_dir() {
        return Ok(Vec::new());
    }
    let mut out = Vec::new();
    for entry in fs::read_dir(&root)? {
        let entry = entry?;
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let name = entry.file_name().to_string_lossy().to_string();
        let entry_html = match name.as_str() {
            "main_window" => "index.html".to_string(),
            "bug_reporter_window" => "bug-reporter.html".to_string(),
            _ => {
                let mut html = None;
                if let Ok(rd) = fs::read_dir(&path) {
                    for f in rd.flatten() {
                        let p = f.path();
                        if p.extension().and_then(|e| e.to_str()) == Some("html") {
                            html = Some(f.file_name().to_string_lossy().to_string());
                            break;
                        }
                    }
                }
                match html {
                    Some(h) => h,
                    None => continue,
                }
            }
        };
        if path.join(&entry_html).is_file() {
            out.push(RendererWindow { name, dir: path, entry_html });
        }
    }
    out.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(out)
}

pub fn resolve_window(app_root: &Path, window: &str) -> Result<RendererWindow> {
    list_windows(app_root)?
        .into_iter()
        .find(|w| w.name == window)
        .ok_or_else(|| HubError::Other(format!("renderer window not found: {window}")))
}

pub fn window_info_json(app_root: &Path) -> Result<Value> {
    let items: Vec<Value> = list_windows(app_root)?
        .into_iter()
        .map(|w| json!({"name": w.name, "dir": w.dir.to_string_lossy(), "entryHtml": w.entry_html}))
        .collect();
    Ok(json!({
        "appRoot": app_root.to_string_lossy(),
        "rendererRoot": renderer_root(app_root).to_string_lossy(),
        "windows": items
    }))
}

// ---------------------------------------------------------------------------
// Startup snapshot (mirrors apps/hub/main startupSnapshot readers)
// ---------------------------------------------------------------------------

const SUPPORTED_LANGUAGES: &[&str] = &["de", "en", "es", "fr", "ja_jp", "ko_kr", "pt_br", "ru", "zh_cn", "zh_tw"];

fn platform_name() -> &'static str {
    if cfg!(windows) {
        "win32"
    } else if cfg!(target_os = "macos") {
        "darwin"
    } else {
        "linux"
    }
}

/// Builds the startup values the 3.22 preload exposes on `window.api`.
pub fn startup_snapshot(data_dir: &Path) -> Value {
    let read = |file: &str| crate::hub_storage::read_json(data_dir, file).ok();

    // projects-v1.json: { data: { <id>: project, ... } } -> first 20 projects.
    let projects: Vec<Value> = read("projects-v1.json")
        .and_then(|v| v.get("data").cloned())
        .and_then(|d| match d {
            Value::Object(m) => Some(m.values().take(20).cloned().collect()),
            _ => None,
        })
        .unwrap_or_default();

    // hubConfig.json merged over an empty default (3.22 DefaultLocalConfig is applied by the renderer).
    let config = read("hubConfig.json").filter(|v| v.is_object());

    let sort = read("projectSortPreferences.json");
    let table = read("projectTablePreferences.json");
    let prefs = if sort.is_some() || table.is_some() {
        json!({"sortPreferences": sort, "tablePreferences": table})
    } else {
        Value::Null
    };

    let should_hide = read("hideGetSetUp.json").and_then(|v| v.as_bool()).unwrap_or(false);
    let fts = read("firstTimeSettings.json").unwrap_or(Value::Null);
    let get_set_up = json!({
        "hasSeenGetSetUp": fts.get("hasSeenGetSetUp").and_then(|v| v.as_bool()) == Some(true),
        "shouldHideGetSetUp": should_hide,
        "hubLicenseEulaAcceptedAt": fts.get("hubLicenseEulaAcceptedAt").and_then(|v| v.as_str()),
    });

    let language = read("languageConfig.json")
        .and_then(|v| v.get("language").and_then(|l| l.as_str()).map(|s| s.to_string()))
        .filter(|l| SUPPORTED_LANGUAGES.contains(&l.as_str()))
        .unwrap_or_else(|| "en".to_string());

    json!({
        "platform": platform_name(),
        "projects": projects,
        "config": config,
        "prefs": prefs,
        // Credential/keyring sign-in state is not available to the Rust port yet.
        "signedIn": false,
        "getSetUp": get_set_up,
        "wcoOverlay": cfg!(windows),
        "language": language,
    })
}

// ---------------------------------------------------------------------------
// Bridge scripts
// ---------------------------------------------------------------------------

fn startup_js(data_dir: &Path) -> String {
    format!("window.__HUB_STARTUP__ = {};", startup_snapshot(data_dir))
}

fn main_bridge_js() -> &'static str {
    r##"(function(){
  if (window.api) return;
  var S = window.__HUB_STARTUP__ || {};
  var subs = new Map();
  function dispatch(ch, args){
    var list = subs.get(ch);
    if (!list) return;
    list.slice().forEach(function(entry){
      try { entry.fn.apply(null, [{}].concat(args)); } catch (e) { console.error(e); }
    });
  }
  function invoke(){
    var args = Array.prototype.slice.call(arguments);
    var channel = args[0];
    if (channel === 'ipc-ready') return Promise.resolve(true);
    return fetch('/__ipc', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({channel: channel, args: args.slice(1)})})
      .then(function(r){
        return r.text().then(function(t){
          var v = t; try { v = JSON.parse(t); } catch (e) {}
          if (!r.ok) throw new Error((v && v.error) || t || ('Error invoking remote method ' + channel));
          return v;
        });
      });
  }
  function on(ch, fn){
    if (!subs.has(ch)) subs.set(ch, []);
    var entry = {fn: fn};
    subs.get(ch).push(entry);
    return function(){ off(ch, fn); };
  }
  function off(ch, fn){
    var list = subs.get(ch); if (!list) return;
    var kept = list.filter(function(e){ return e.fn !== fn; });
    if (kept.length) subs.set(ch, kept); else subs.delete(ch);
  }
  var es = null;
  try {
    es = new EventSource('/__events');
    es.onmessage = function(ev){
      try { var m = JSON.parse(ev.data); dispatch(m.channel, m.args || []); } catch (e) {}
    };
  } catch (e) {}
  setTimeout(function(){ dispatch('ipc-ready', [true]); }, 0);
  var undef = function(v){ return v === null ? undefined : v; };
  window.api = {
    ipcRenderer: { invoke: invoke, on: on, off: off },
    platform: S.platform || 'win32',
    performanceReport: false,
    getPathForFiles: function(files){
      return Promise.resolve(Array.prototype.map.call(files || [], function(f){
        return (f && (f.path || f.name)) || '';
      }));
    },
    startupProjects: Array.isArray(S.projects) ? S.projects : [],
    startupConfig: undef(S.config),
    startupPrefs: undef(S.prefs),
    startupSignedIn: !!S.signedIn,
    startupGetSetUp: undef(S.getSetUp),
    startupWcoOverlay: !!S.wcoOverlay,
    startupLanguage: undef(S.language),
    notifyRendererReady: function(){ invoke('renderer-notifiers-ready').catch(function(){}); }
  };
  window.hub = window.api;
  window.__hubBridgeEvents = es;
  console.info('[hub-bridge] Rust bridge installed (api contract = mainWindowPreload)');
})();"##
}

fn bug_reporter_bridge_js() -> &'static str {
    r##"(function(){
  if (window.bugReporterApi) return;
  var subs = new Map();
  var ALLOWED = {'theme-changed': true, 'attachments-manifest-changed': true};
  function dispatch(ch, args){
    var list = subs.get(ch); if (!list) return;
    list.slice().forEach(function(fn){ try { fn.apply(null, [{}].concat(args)); } catch (e) { console.error(e); } });
  }
  function invoke(){
    var args = Array.prototype.slice.call(arguments);
    return fetch('/__ipc', {method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({channel: args[0], args: args.slice(1)})})
      .then(function(r){
        return r.text().then(function(t){
          var v = t; try { v = JSON.parse(t); } catch (e) {}
          if (!r.ok) throw new Error((v && v.error) || t);
          return v;
        });
      });
  }
  function on(ch, fn){
    if (!ALLOWED[ch]) return;
    if (!subs.has(ch)) subs.set(ch, []);
    subs.get(ch).push(fn);
  }
  function off(ch, fn){
    var list = subs.get(ch); if (!list) return;
    subs.set(ch, list.filter(function(f){ return f !== fn; }));
  }
  try {
    var es = new EventSource('/__events');
    es.onmessage = function(ev){
      try { var m = JSON.parse(ev.data); dispatch(m.channel, m.args || []); } catch (e) {}
    };
  } catch (e) {}
  window.bugReporterApi = { platform: 'win32', ipcRenderer: { invoke: invoke, on: on, off: off } };
  console.info('[hub-bridge] Rust bug reporter bridge installed');
})();"##
}

fn inject_bridge(mut html: String, window: &str) -> String {
    let tags = if window == "bug_reporter_window" {
        "<script src=\"/__bug_reporter_bridge.js\"></script>".to_string()
    } else {
        "<script src=\"/__hub_startup.js\"></script><script src=\"/__hub_bridge.js\"></script>".to_string()
    };
    let lower = html.to_ascii_lowercase();
    if let Some(idx) = lower.find("</head>") {
        html.insert_str(idx, &format!("    {tags}\n  "));
    } else if let Some(idx) = lower.find("<body") {
        html.insert_str(idx, &format!("{tags}\n"));
    } else {
        html = format!("{tags}\n{html}");
    }
    html
}

// ---------------------------------------------------------------------------
// Static file serving helpers
// ---------------------------------------------------------------------------

fn content_type(path: &Path) -> &'static str {
    match path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase().as_str() {
        "html" => "text/html; charset=utf-8",
        "js" | "mjs" | "cjs" => "application/javascript; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "json" | "map" => "application/json; charset=utf-8",
        "png" => "image/png",
        "jpg" | "jpeg" => "image/jpeg",
        "gif" => "image/gif",
        "svg" => "image/svg+xml",
        "webp" => "image/webp",
        "woff2" => "font/woff2",
        "woff" => "font/woff",
        "ttf" => "font/ttf",
        "otf" => "font/otf",
        "txt" => "text/plain; charset=utf-8",
        "wasm" => "application/wasm",
        _ => "application/octet-stream",
    }
}

fn sanitize_path(url_path: &str) -> Option<PathBuf> {
    let raw = url_path.split('?').next().unwrap_or("/");
    let decoded = percent_decode(raw);
    let mut out = PathBuf::new();
    for comp in Path::new(&decoded).components() {
        match comp {
            Component::Normal(s) => out.push(s),
            Component::CurDir | Component::RootDir => {}
            Component::Prefix(_) | Component::ParentDir => return None,
        }
    }
    Some(out)
}

fn percent_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    let mut out: Vec<u8> = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            let hex = std::str::from_utf8(&bytes[i + 1..i + 3]).unwrap_or("");
            if let Ok(v) = u8::from_str_radix(hex, 16) {
                out.push(v);
                i += 3;
                continue;
            }
        }
        out.push(bytes[i]);
        i += 1;
    }
    String::from_utf8_lossy(&out).to_string()
}

// ---------------------------------------------------------------------------
// HTTP plumbing (tokio)
// ---------------------------------------------------------------------------

struct Ctx {
    dir: PathBuf,
    entry: String,
    window: String,
    data_dir: PathBuf,
    events: broadcast::Sender<String>,
}

struct Request {
    method: String,
    path: String,
    body: String,
}

fn find_subslice(hay: &[u8], needle: &[u8]) -> Option<usize> {
    hay.windows(needle.len()).position(|w| w == needle)
}

async fn read_request(stream: &mut TcpStream) -> std::io::Result<Option<Request>> {
    let mut buf: Vec<u8> = Vec::new();
    let mut tmp = [0u8; 8192];
    let header_end = loop {
        if let Some(p) = find_subslice(&buf, b"\r\n\r\n") {
            break p + 4;
        }
        if buf.len() > 1024 * 1024 {
            return Ok(None);
        }
        let n = stream.read(&mut tmp).await?;
        if n == 0 {
            return Ok(None);
        }
        buf.extend_from_slice(&tmp[..n]);
    };
    let head = String::from_utf8_lossy(&buf[..header_end]).to_string();
    let mut lines = head.split("\r\n");
    let mut parts = lines.next().unwrap_or("").split_whitespace();
    let method = parts.next().unwrap_or("").to_string();
    let path = parts.next().unwrap_or("/").to_string();
    let content_len = lines
        .filter_map(|l| {
            l.to_ascii_lowercase()
                .strip_prefix("content-length:")
                .map(|v| v.trim().parse::<usize>().unwrap_or(0))
        })
        .next()
        .unwrap_or(0);
    let mut body = buf[header_end..].to_vec();
    while body.len() < content_len {
        let n = stream.read(&mut tmp).await?;
        if n == 0 {
            break;
        }
        body.extend_from_slice(&tmp[..n]);
    }
    body.truncate(content_len);
    Ok(Some(Request {
        method,
        path,
        body: String::from_utf8_lossy(&body).to_string(),
    }))
}

async fn respond(stream: &mut TcpStream, status: &str, ctype: &str, body: &[u8]) -> std::io::Result<()> {
    let head = format!(
        "HTTP/1.1 {status}\r\nContent-Type: {ctype}\r\nContent-Length: {}\r\nCache-Control: no-cache\r\n\
         Access-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: content-type\r\n\
         Access-Control-Allow-Methods: GET,POST,OPTIONS\r\nConnection: close\r\n\r\n",
        body.len()
    );
    stream.write_all(head.as_bytes()).await?;
    stream.write_all(body).await?;
    stream.shutdown().await
}

/// `/__ipc`: runs the MainServices-aligned Rust backend and returns its result.
/// Errors come back as HTTP 500 with `{error}` so the bridge can reject, like Electron invoke.
async fn run_ipc(data_dir: &Path, body: &str) -> (&'static str, Vec<u8>) {
    let v: Value = match serde_json::from_str(body) {
        Ok(v) => v,
        Err(e) => {
            return ("400 Bad Request", json!({"error": format!("invalid json: {e}")}).to_string().into_bytes());
        }
    };
    let channel = v.get("channel").and_then(|x| x.as_str()).unwrap_or("").to_string();
    if channel.is_empty() {
        return ("400 Bad Request", br#"{"error":"missing channel"}"#.to_vec());
    }
    let args: Vec<String> = match v.get("args") {
        Some(Value::Array(a)) => a
            .iter()
            .map(|x| match x {
                Value::String(s) => s.clone(),
                Value::Null => String::new(),
                other => other.to_string(),
            })
            .collect(),
        _ => Vec::new(),
    };
    let exe = std::env::current_exe().unwrap_or_else(|_| PathBuf::from("unity-hub"));
    let dd = data_dir.to_path_buf();
    let ch = channel.clone();
    let out = tokio::task::spawn_blocking(move || {
        Command::new(exe)
            .arg("ipc")
            .arg("--data-dir")
            .arg(&dd)
            .arg(&ch)
            .args(&args)
            .output()
    })
    .await;
    match out {
        Ok(Ok(o)) if o.status.success() => {
            let s = String::from_utf8_lossy(&o.stdout).trim().to_string();
            let value = if s.is_empty() {
                Value::Null
            } else {
                serde_json::from_str::<Value>(&s).unwrap_or(Value::String(s))
            };
            ("200 OK", value.to_string().into_bytes())
        }
        Ok(Ok(o)) => {
            let stderr = String::from_utf8_lossy(&o.stderr).trim().to_string();
            let stdout = String::from_utf8_lossy(&o.stdout).trim().to_string();
            let msg = if !stderr.is_empty() {
                stderr
            } else if !stdout.is_empty() {
                stdout
            } else {
                "ipc command failed".to_string()
            };
            (
                "500 Internal Server Error",
                json!({"error": msg, "channel": channel, "code": o.status.code()}).to_string().into_bytes(),
            )
        }
        _ => (
            "500 Internal Server Error",
            json!({"error": "failed to run ipc backend", "channel": channel}).to_string().into_bytes(),
        ),
    }
}

/// `/__events`: server-sent events channel carrying `{channel, args}` pushes.
async fn serve_events(stream: &mut TcpStream, ctx: &Ctx) -> std::io::Result<()> {
    stream
        .write_all(
            b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\n\
              Access-Control-Allow-Origin: *\r\nConnection: keep-alive\r\n\r\n: connected\n\n",
        )
        .await?;
    let mut rx = ctx.events.subscribe();
    let mut tick = tokio::time::interval(Duration::from_secs(15));
    loop {
        tokio::select! {
            msg = rx.recv() => match msg {
                Ok(m) => stream.write_all(format!("data: {m}\n\n").as_bytes()).await?,
                Err(broadcast::error::RecvError::Lagged(_)) => continue,
                Err(_) => break,
            },
            _ = tick.tick() => stream.write_all(b": ping\n\n").await?,
        }
    }
    Ok(())
}

async fn handle(mut stream: TcpStream, ctx: Arc<Ctx>) -> std::io::Result<()> {
    let Some(req) = read_request(&mut stream).await? else {
        return Ok(());
    };
    if req.method.eq_ignore_ascii_case("OPTIONS") {
        return respond(&mut stream, "204 No Content", "text/plain; charset=utf-8", b"").await;
    }
    let route = req.path.split('?').next().unwrap_or("/").to_string();
    let is_get = req.method.eq_ignore_ascii_case("GET");

    if req.method.eq_ignore_ascii_case("POST") && route == "/__ipc" {
        let (status, body) = run_ipc(&ctx.data_dir, &req.body).await;
        return respond(&mut stream, status, "application/json; charset=utf-8", &body).await;
    }
    if is_get && route == "/__events" {
        return serve_events(&mut stream, &ctx).await;
    }
    if is_get && route == "/__hub_startup.js" {
        return respond(&mut stream, "200 OK", "application/javascript; charset=utf-8", startup_js(&ctx.data_dir).as_bytes()).await;
    }
    if is_get && route == "/__hub_bridge.js" {
        return respond(&mut stream, "200 OK", "application/javascript; charset=utf-8", main_bridge_js().as_bytes()).await;
    }
    if is_get && route == "/__bug_reporter_bridge.js" {
        return respond(&mut stream, "200 OK", "application/javascript; charset=utf-8", bug_reporter_bridge_js().as_bytes()).await;
    }

    let rel = sanitize_path(&route).unwrap_or_default();
    let mut fs_path = if rel.as_os_str().is_empty() {
        ctx.dir.join(&ctx.entry)
    } else {
        ctx.dir.join(&rel)
    };
    if fs_path.is_dir() {
        fs_path = fs_path.join(&ctx.entry);
    }
    if !fs_path.is_file() {
        // Source maps are not shipped in the extracted bundle; answer empty instead of 404 noise.
        if rel.extension().and_then(|e| e.to_str()) == Some("map") {
            return respond(&mut stream, "200 OK", "application/json; charset=utf-8", b"{}").await;
        }
        // SPA fallback for extension-less client routes.
        if rel.extension().is_none() {
            fs_path = ctx.dir.join(&ctx.entry);
        }
    }
    match fs::read(&fs_path) {
        Ok(bytes) => {
            let ctype = content_type(&fs_path);
            let body = if ctype.starts_with("text/html") {
                match String::from_utf8(bytes.clone()) {
                    Ok(html) => inject_bridge(html, &ctx.window).into_bytes(),
                    Err(_) => bytes,
                }
            } else {
                bytes
            };
            respond(&mut stream, "200 OK", ctype, &body).await
        }
        Err(_) => respond(&mut stream, "404 Not Found", "text/plain; charset=utf-8", b"Not Found").await,
    }
}

/// Locate the extracted Hub 3.22 app bundle at runtime (works from a copied exe, not just the build tree).
pub fn resolve_app_root(explicit: Option<&Path>) -> Result<PathBuf> {
    let marker = |root: &Path| renderer_root(root).join("main_window").join("index.html").is_file();
    let mut cands: Vec<PathBuf> = Vec::new();
    if let Some(p) = explicit {
        cands.push(p.to_path_buf());
    }
    if let Ok(exe) = std::env::current_exe() {
        for anc in exe.ancestors().skip(1).take(5) {
            cands.push(anc.join("electron-hub-3.22").join("app"));
        }
    }
    if let Ok(cwd) = std::env::current_dir() {
        cands.push(cwd.join("electron-hub-3.22").join("app"));
    }
    cands.push(default_extracted_app_root());
    cands
        .into_iter()
        .find(|c| marker(c))
        .ok_or_else(|| HubError::Other("could not locate the Hub 3.22 app bundle (electron-hub-3.22/app)".into()))
}

/// Open a URL in the system browser (best effort).
fn open_url(url: &str) {
    #[cfg(windows)]
    let res = Command::new("cmd").args(["/C", "start", "", url]).spawn();
    #[cfg(target_os = "macos")]
    let res = Command::new("open").arg(url).spawn();
    #[cfg(not(any(windows, target_os = "macos")))]
    let res = Command::new("xdg-open").arg(url).spawn();
    if let Err(e) = res {
        eprintln!("could not open browser automatically ({e}); open {url} manually");
    }
}

/// Serve one renderer window on `bind` (e.g. `127.0.0.1:4321`, or `127.0.0.1:0` for any free port).
/// Blocks until the process exits. Optionally opens the page in the system browser.
fn run_server(app_root: &Path, window: &str, bind: &str, open_browser: bool) -> Result<()> {
    let win = resolve_window(app_root, window)?;
    let data_dir = crate::hub_registry::hub_data_dir();
    let rt = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .map_err(|e| HubError::Other(format!("tokio runtime: {e}")))?;
    let bind = bind.to_string();
    rt.block_on(async move {
        let listener = TcpListener::bind(&bind)
            .await
            .map_err(|e| HubError::Other(format!("failed to bind renderer server at {bind}: {e}")))?;
        let port = listener
            .local_addr()
            .map(|a| a.port())
            .map_err(|e| HubError::Other(format!("renderer server address: {e}")))?;
        let url = format!("http://127.0.0.1:{port}/{}", win.entry_html);
        println!(
            "{}",
            json!({
                "ok": true,
                "method": "rendererServe",
                "window": win.name,
                "dir": win.dir.to_string_lossy(),
                "dataDir": data_dir.to_string_lossy(),
                "url": url,
                "note": "Hub 3.22 renderer served locally; press Ctrl+C to stop"
            })
        );
        if open_browser {
            open_url(&url);
        }
        let (events_tx, _) = broadcast::channel::<String>(64);
        let ctx = Arc::new(Ctx {
            dir: win.dir.clone(),
            entry: win.entry_html.clone(),
            window: win.name.clone(),
            data_dir,
            events: events_tx,
        });
        loop {
            let (stream, _) = match listener.accept().await {
                Ok(s) => s,
                Err(_) => break,
            };
            let ctx = ctx.clone();
            tokio::spawn(async move {
                let _ = handle(stream, ctx).await;
            });
        }
        Ok::<(), HubError>(())
    })
}

/// Serve a renderer window on a fixed port. Blocking.
pub fn serve_window(app_root: &Path, window: &str, port: u16) -> Result<()> {
    run_server(app_root, window, &format!("127.0.0.1:{port}"), false)
}

/// Default GUI entry point (no CLI arguments): serve the Hub 3.22 main window on a free
/// localhost port and open it in the system browser. Blocking until Ctrl+C.
pub fn run_gui(app_dir: Option<&Path>) -> Result<()> {
    let root = resolve_app_root(app_dir)?;
    run_server(&root, "main_window", "127.0.0.1:0", true)
}
