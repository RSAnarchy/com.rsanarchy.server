use clap::Parser;

use unity_hub::error::Result;

#[derive(Debug, Parser)]
#[command(name = "unity-hub")]
#[command(version = "3.22.6")]
#[command(about = "Unity Hub 3.22.6 Electron-to-Rust port (1:1 functionality target)")]
struct Cli {
    #[command(subcommand)]
    command: Option<Commands>,
}

#[derive(Debug, clap::Subcommand)]
enum Commands {
    /// List installed Unity editors (scanned).
    Editors,
    /// List discovered Unity projects (scanned).
    Projects,
    /// Verify 4.0 reference artifacts (checksums, unity.exe preserved).
    Verify,
    /// Show Hub 3.22 Electron app inventory and Rust port status.
    PortStatus,
    /// List project templates for an installed editor version or install path.
    EditorTemplates { editor: String },
    /// List modules for an installed editor (from modules.json).
    EditorModules { editor: String },
    /// Show local downloadable editors/releases cache summary or resolve a version plan.

    ReleasesCache {

        #[arg(long)]

        data_dir: Option<String>,

        #[arg(long)]

        version: Option<String>,

        #[arg(long)]

        summary: bool,

    },

    /// Execute a local installer process with install-state DB integration (no network download).
    InstallExecuteLocal {
        #[arg(long)]
        data_dir: Option<String>,
        #[arg(long)]
        uid: Option<String>,
        #[arg(long)]
        version: String,
        #[arg(long, default_value = "[]")]
        modules: String,
        #[arg(long)]
        mark_download_complete: bool,
        /// Program/installer to execute
        program: String,
        /// Arguments passed to the program
        #[arg(trailing_var_arg = true, allow_hyphen_values = true)]
        args: Vec<String>,
    },
    /// Queue cached editor release into install-state DB from local releases cache (dry-run; no download/execution).
    InstallQueueCachedRelease {
        #[arg(long)]
        data_dir: Option<String>,
        #[arg(long)]
        uid: Option<String>,
        #[arg(long, default_value = "[]")]
        modules: String,
        version: String,
    },
    /// Show editor install/download/install-state status for a version.
    EditorInstallStatus {
        version: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Download a URL to file with install-state progress tracking.
    InstallDownload {
        #[arg(long)]
        data_dir: Option<String>,
        #[arg(long)]
        uid: String,
        #[arg(long)]
        version: String,
        #[arg(long)]
        url: String,
        #[arg(long)]
        dest: String,
        #[arg(long)]
        arch: Option<String>,
        #[arg(long, default_value = "[]")]
        modules: String,
        #[arg(long)]
        expected_bytes: Option<i64>,
        #[arg(long)]
        ensure_queued: bool,
    },
    /// Integrated local pipeline: download -> integrity verify -> execute installer -> register editor.
    InstallPipelineLocal {
        #[arg(long)]
        data_dir: Option<String>,
        #[arg(long)]
        uid: String,
        #[arg(long)]
        version: String,
        #[arg(long)]
        url: String,
        #[arg(long)]
        dest: String,
        #[arg(long)]
        integrity: Option<String>,
        #[arg(long)]
        register_install_path: Option<String>,
        #[arg(long)]
        arch: Option<String>,
        #[arg(long, default_value = "[]")]
        modules: String,
        #[arg(long)]
        expected_bytes: Option<i64>,
        /// Installer program to execute
        installer_program: String,
        /// Installer arguments
        #[arg(trailing_var_arg = true, allow_hyphen_values = true)]
        installer_args: Vec<String>,
    },
    /// Build full execution plan for installing a cached editor release (no download/execution).
    InstallPlanCachedRelease {
        version: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Download+install a module (ZIP/PO) from URL with integrity and destination placement.
    InstallModuleLocal {
        #[arg(long)]
        data_dir: Option<String>,
        #[arg(long)]
        uid: String,
        #[arg(long)]
        version: String,
        #[arg(long)]
        url: String,
        #[arg(long)]
        dest_zip: String,
        #[arg(long)]
        module_type: String,
        #[arg(long)]
        destination: Option<String>,
        #[arg(long)]
        unity_path: Option<String>,
        #[arg(long)]
        rename_from: Option<String>,
        #[arg(long)]
        rename_to: Option<String>,
        #[arg(long)]
        integrity: Option<String>,
        #[arg(long)]
        arch: Option<String>,
        #[arg(long, default_value = "[]")]
        modules: String,
        #[arg(long)]
        expected_bytes: Option<i64>,
    },
    /// Build 3.22-aligned open-project editor args.
    ProjectOpenArgs { project_path: String, #[arg(trailing_var_arg = true, allow_hyphen_values = true)] extra: Vec<String> },
    /// Build 3.22-aligned create-project editor args.
    ProjectCreateArgs { project_path: String, template: String, #[arg(long)] cloud_org: Option<String>, #[arg(long)] cloud_project: Option<String> },
    /// Resolve editor + args for opening a project (dry-run, safe). Optionally touch lastModified in registry.
    ProjectOpenPlan { project_path: String, #[arg(long)] data_dir: Option<String>, #[arg(long)] touch: bool },
    /// Resolve editor/template + args for creating a project (dry-run, safe).
    ProjectCreatePlan { project_path: String, editor_version: String, template: String, #[arg(long)] cloud_org: Option<String>, #[arg(long)] cloud_project: Option<String> },
    /// Read Unity project version info (ProjectSettings/ProjectVersion.txt).
    ProjectVersionInfo { project_path: String },
    /// Open project (updates registry recents; optionally launches editor).
    ProjectOpen { project_path: String, #[arg(long)] data_dir: Option<String>, #[arg(long)] launch: bool, #[arg(trailing_var_arg = true, allow_hyphen_values = true)] extra: Vec<String> },
    /// Create project (builds/resolves args; optionally launches editor).
    ProjectCreate { project_path: String, editor_version: String, template: String, #[arg(long)] cloud_org: Option<String>, #[arg(long)] cloud_project: Option<String>, #[arg(long)] launch: bool },
    /// List projects from Hub registry (projects-v1.json).
    RegistryProjects {
        /// Hub data directory (defaults to %APPDATA%/UnityHub or UNITY_HUB_DATA_DIR).
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Add/update a project in Hub registry (projects-v1.json).
    RegistryAddProject {
        /// Path to Unity project folder.
        path: String,
        /// Hub data directory.
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// List editors from Hub registry (editors-v2.json).
    RegistryEditors {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Add an editor entry to Hub registry (editors-v2.json).
    RegistryAddEditor {
        version: String,
        location: String,
        /// Mark editor as manually located.
        #[arg(long, default_value_t = true, action = clap::ArgAction::Set, value_parser = clap::builder::BoolishValueParser::new())]
        manual: bool,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Set manual flag for editor entries matching version or location.
    RegistrySetEditorManual {
        matcher: String,
        #[arg(action = clap::ArgAction::Set, value_parser = clap::builder::BoolishValueParser::new())]
        manual: bool,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Sync scanned installed editors into editors-v2 registry.
    RegistrySyncEditors {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Sync discovered projects into projects-v1 registry.
    RegistrySyncProjects {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Remove a project from projects-v1 registry.
    RegistryRemoveProject {
        path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Set favorite flag for a project in projects-v1 registry.
    RegistrySetFavorite {
        path: String,
        #[arg(action = clap::ArgAction::Set, value_parser = clap::builder::BoolishValueParser::new())]
        favorite: bool,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Update lastModified timestamp for a project in projects-v1 registry.
    RegistryTouchProject {
        path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Remove an editor from editors-v2 registry (by version or location).
    RegistryRemoveEditor {
        matcher: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Show a project record from projects-v1 registry.
    RegistryGetProject {
        path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Set isCustomEditor for a project in projects-v1 registry.
    RegistrySetCustomEditor {
        path: String,
        #[arg(action = clap::ArgAction::Set, value_parser = clap::builder::BoolishValueParser::new())]
        is_custom: bool,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// List projects sorted by lastModified desc (recents view).
    RegistryRecents {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// List files in Hub data storage directory.
    StorageList {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Read a Hub storage file.
    StorageGet {
        file: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Write a Hub storage file.
    StorageSet {
        file: String,
        content: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Read projectDir.json preference.
    PrefsProjectDirGet {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Write projectDir.json preference.
    PrefsProjectDirSet {
        directory_path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Get secondaryInstallPath.json preference.
    PrefsSecondaryInstallPathGet {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Set secondaryInstallPath.json preference.
    PrefsSecondaryInstallPathSet {
        path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// List excluded editor folders.
    PrefsExcludedEditorFoldersList {
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Add excluded editor folder.
    PrefsExcludedEditorFoldersAdd {
        path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Remove excluded editor folder.
    PrefsExcludedEditorFoldersRemove {
        path: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Set an arbitrary field on matching editor entries (value as JSON).
    RegistrySetEditorField {
        matcher: String,
        key: String,
        value_json: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Get hideHubOnEditorOpen.json preference.
    PrefsHideHubOnEditorOpenGet { #[arg(long)] data_dir: Option<String> },
    /// Set hideHubOnEditorOpen.json preference.
    PrefsHideHubOnEditorOpenSet {
        #[arg(action = clap::ArgAction::Set, value_parser = clap::builder::BoolishValueParser::new())]
        value: bool,
        #[arg(long)] data_dir: Option<String>,
    },
    /// Get projectSortPreferences.json.
    PrefsProjectSortGet { #[arg(long)] data_dir: Option<String> },
    /// Set projectSortPreferences.json.
    PrefsProjectSortSet {
        sort_by: String,
        sort_direction: String,
        #[arg(long)] data_dir: Option<String>,
    },
    /// Get skipRemoveConfirmation.json.
    PrefsSkipRemoveConfirmationGet { #[arg(long)] data_dir: Option<String> },
    /// Set skipRemoveConfirmation.json.
    PrefsSkipRemoveConfirmationSet {
        #[arg(action = clap::ArgAction::Set, value_parser = clap::builder::BoolishValueParser::new())]
        always: bool,
        timestamp: i64,
        #[arg(long)] data_dir: Option<String>,
    },
    /// Read paused-downloads.json.
    DownloadsPausedGet { #[arg(long)] data_dir: Option<String> },
    /// Reset paused-downloads.json to empty.
    DownloadsPausedClear { #[arg(long)] data_dir: Option<String> },
    /// Add/update an entry in paused-downloads.json (JSON object).
    DownloadsPausedAddEntry { entry_json: String, #[arg(long)] data_dir: Option<String> },
    /// Remove an entry from paused-downloads.json by uid/id.
    DownloadsPausedRemoveEntry { uid: String, #[arg(long)] data_dir: Option<String> },
    /// Inspect install-state SQLite database.
    InstallStateInfo { #[arg(long)] data_dir: Option<String> },
    /// Read install-state downloads as JSON.
    InstallStateDownloads { #[arg(long)] data_dir: Option<String> },
    /// Read install-state installs as JSON.
    InstallStateInstalls { #[arg(long)] data_dir: Option<String> },
    /// Queue a download in install-state.db.
    InstallStateQueueDownload {
        uid: String,
        version: String,
        #[arg(long)]
        arch: Option<String>,
        #[arg(long, default_value = "[]")]
        modules_json: String,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Set download state in install-state.db.
    InstallStateSetDownloadState {
        uid: String,
        state: String,
        #[arg(long)]
        bytes_done: Option<i64>,
        #[arg(long)]
        bytes_total: Option<i64>,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Cancel a download in install-state.db.
    InstallStateCancelDownload { uid: String, #[arg(long)] data_dir: Option<String> },
    /// Queue active install in install-state.db.
    InstallStateQueueInstall {
        uid: String,
        version: String,
        #[arg(long, default_value = "[]")]
        modules_json: String,
        #[arg(long, default_value_t = 0)]
        pid: i64,
        #[arg(long)]
        data_dir: Option<String>,
    },
    /// Clear active install in install-state.db.
    InstallStateClearInstall { #[arg(long)] data_dir: Option<String> },
    /// Read install-state file_claims table as JSON.
    InstallStateFileClaims { #[arg(long)] data_dir: Option<String> },
    /// Read install-state schema_meta table as JSON.
    InstallStateSchemaMeta { #[arg(long)] data_dir: Option<String> },
    /// Set active install phase (`queued` or `installing`).
    InstallStateSetInstallPhase { phase: String, #[arg(long)] data_dir: Option<String> },
    /// Upsert a file claim in install-state.db.
    InstallStateUpsertFileClaim { pid: i64, source: String, path: String, #[arg(long)] data_dir: Option<String> },
    /// Remove a file claim from install-state.db.
    InstallStateRemoveFileClaim { pid: i64, source: String, path: String, #[arg(long)] data_dir: Option<String> },
    /// Clear all file claims from install-state.db.
    InstallStateClearFileClaims { #[arg(long)] data_dir: Option<String> },
    /// Invoke IPC-aligned MainServices method (mapped subset).
    Ipc {
        #[arg(long, global = false)]
        data_dir: Option<String>,
        /// Method/channel name (e.g. getProjectsInfo, getRecentProjects, getInstalledEditors). Use 'channels' to list.
        method: String,
        /// Positional arguments for the method.
        #[arg(trailing_var_arg = true, allow_hyphen_values = true)]
        args: Vec<String>,
    },
    /// Show extracted 3.22 renderer window info (main_window, bug_reporter_window assets).
    RendererInfo {
        #[arg(long)]
        app_dir: Option<String>,
    },
    /// Serve an extracted 3.22 renderer window over local HTTP for visual parity hosting.
    RendererServe {
        /// Window name (e.g. main_window, bug_reporter_window)
        #[arg(long, default_value = "main_window")]
        window: String,
        #[arg(long, default_value_t = 3220)]
        port: u16,
        #[arg(long)]
        app_dir: Option<String>,
    },
    /// Start renderer server and open it in the system browser (app host fallback).
    RendererOpen {
        #[arg(long, default_value = "main_window")]
        window: String,
        #[arg(long, default_value_t = 3220)]
        port: u16,
        #[arg(long)]
        app_dir: Option<String>,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    let Some(command) = cli.command else {
        return unity_hub::renderer::run_gui(None);
    };
    match command {
        Commands::Editors => unity_hub::commands::editors()?,
        Commands::Projects => unity_hub::commands::projects()?,
        Commands::Verify => unity_hub::commands::verify()?,
        Commands::PortStatus => unity_hub::commands::port_status()?,
        Commands::EditorTemplates { editor } => unity_hub::commands::editor_templates(&editor)?,
        Commands::EditorModules { editor } => unity_hub::commands::editor_modules(&editor)?,
        Commands::ReleasesCache { data_dir, version, summary } => unity_hub::commands::releases_cache(data_dir.as_deref(), version.as_deref(), summary)?,
        Commands::InstallExecuteLocal { data_dir, uid, version, modules, mark_download_complete, program, args } => unity_hub::commands::install_execute_local(data_dir.as_deref(), uid.as_deref(), &version, &modules, &program, &args, mark_download_complete)?,
        Commands::InstallQueueCachedRelease { data_dir, uid, modules, version } => unity_hub::commands::install_queue_cached_release(data_dir.as_deref(), &version, uid.as_deref(), Some(&modules))?,
        Commands::EditorInstallStatus { version, data_dir } => unity_hub::commands::editor_install_status(data_dir.as_deref(), &version)?,
        Commands::InstallDownload { data_dir, uid, version, url, dest, arch, modules, expected_bytes, ensure_queued } => unity_hub::commands::install_download(data_dir.as_deref(), &uid, &version, &url, &dest, arch.as_deref(), Some(&modules), expected_bytes, ensure_queued)?,
        Commands::InstallPipelineLocal { data_dir, uid, version, url, dest, integrity, register_install_path, arch, modules, expected_bytes, installer_program, installer_args } => unity_hub::commands::install_pipeline_local(data_dir.as_deref(), &uid, &version, &url, &dest, integrity.as_deref(), &installer_program, &installer_args, register_install_path.as_deref(), arch.as_deref(), Some(&modules), expected_bytes)?,
        Commands::InstallPlanCachedRelease { version, data_dir } => unity_hub::commands::install_plan_cached_release(data_dir.as_deref(), &version)?,
        Commands::InstallModuleLocal { data_dir, uid, version, url, dest_zip, module_type, destination, unity_path, rename_from, rename_to, integrity, arch, modules, expected_bytes } => unity_hub::commands::install_module_local(data_dir.as_deref(), &uid, &version, &url, &dest_zip, &module_type, destination.as_deref(), unity_path.as_deref(), rename_from.as_deref(), rename_to.as_deref(), integrity.as_deref(), arch.as_deref(), Some(&modules), expected_bytes)?,
        Commands::ProjectOpenArgs { project_path, extra } => unity_hub::commands::project_open_args(&project_path, &extra)?,
        Commands::ProjectCreateArgs { project_path, template, cloud_org, cloud_project } => unity_hub::commands::project_create_args(&project_path, &template, cloud_org.as_deref(), cloud_project.as_deref())?,
        Commands::ProjectOpenPlan { project_path, data_dir, touch } => unity_hub::commands::project_open_plan(&project_path, data_dir.as_deref(), touch)?,
        Commands::ProjectCreatePlan { project_path, editor_version, template, cloud_org, cloud_project } => unity_hub::commands::project_create_plan(&project_path, &editor_version, &template, cloud_org.as_deref(), cloud_project.as_deref())?,
        Commands::ProjectVersionInfo { project_path } => unity_hub::commands::project_version_info(&project_path)?,
        Commands::ProjectOpen { project_path, data_dir, launch, extra } => unity_hub::commands::project_open(&project_path, data_dir.as_deref(), launch, &extra)?,
        Commands::ProjectCreate { project_path, editor_version, template, cloud_org, cloud_project, launch } => unity_hub::commands::project_create(&project_path, &editor_version, &template, cloud_org.as_deref(), cloud_project.as_deref(), launch)?,
        Commands::RegistryProjects { data_dir } => unity_hub::commands::registry_projects(data_dir.as_deref())?,
        Commands::RegistryAddProject { path, data_dir } => unity_hub::commands::registry_add_project(&path, data_dir.as_deref())?,
        Commands::RegistryEditors { data_dir } => unity_hub::commands::registry_editors(data_dir.as_deref())?,
        Commands::RegistryAddEditor { version, location, manual, data_dir } => unity_hub::commands::registry_add_editor(&version, &location, manual, data_dir.as_deref())?,
        Commands::RegistrySetEditorManual { matcher, manual, data_dir } => unity_hub::commands::registry_set_editor_manual(&matcher, manual, data_dir.as_deref())?,
        Commands::RegistrySyncEditors { data_dir } => unity_hub::commands::registry_sync_editors(data_dir.as_deref())?,
        Commands::RegistrySyncProjects { data_dir } => unity_hub::commands::registry_sync_projects(data_dir.as_deref())?,
        Commands::RegistryRemoveProject { path, data_dir } => unity_hub::commands::registry_remove_project(&path, data_dir.as_deref())?,
        Commands::RegistrySetFavorite { path, favorite, data_dir } => unity_hub::commands::registry_set_favorite(&path, favorite, data_dir.as_deref())?,
        Commands::RegistryTouchProject { path, data_dir } => unity_hub::commands::registry_touch_project(&path, data_dir.as_deref())?,
        Commands::RegistryRemoveEditor { matcher, data_dir } => unity_hub::commands::registry_remove_editor(&matcher, data_dir.as_deref())?,
        Commands::RegistryGetProject { path, data_dir } => unity_hub::commands::registry_get_project(&path, data_dir.as_deref())?,
        Commands::RegistrySetCustomEditor { path, is_custom, data_dir } => unity_hub::commands::registry_set_custom_editor(&path, is_custom, data_dir.as_deref())?,
        Commands::RegistryRecents { data_dir } => unity_hub::commands::registry_recents(data_dir.as_deref())?,
        Commands::StorageList { data_dir } => unity_hub::commands::storage_list(data_dir.as_deref())?,
        Commands::StorageGet { file, data_dir } => unity_hub::commands::storage_get(&file, data_dir.as_deref())?,
        Commands::StorageSet { file, content, data_dir } => unity_hub::commands::storage_set(&file, &content, data_dir.as_deref())?,
        Commands::PrefsProjectDirGet { data_dir } => unity_hub::commands::prefs_project_dir_get(data_dir.as_deref())?,
        Commands::PrefsProjectDirSet { directory_path, data_dir } => unity_hub::commands::prefs_project_dir_set(&directory_path, data_dir.as_deref())?,
        Commands::PrefsSecondaryInstallPathGet { data_dir } => unity_hub::commands::prefs_secondary_install_path_get(data_dir.as_deref())?,
        Commands::PrefsSecondaryInstallPathSet { path, data_dir } => unity_hub::commands::prefs_secondary_install_path_set(&path, data_dir.as_deref())?,
        Commands::PrefsExcludedEditorFoldersList { data_dir } => unity_hub::commands::prefs_excluded_editor_folders_list(data_dir.as_deref())?,
        Commands::PrefsExcludedEditorFoldersAdd { path, data_dir } => unity_hub::commands::prefs_excluded_editor_folders_add(&path, data_dir.as_deref())?,
        Commands::PrefsExcludedEditorFoldersRemove { path, data_dir } => unity_hub::commands::prefs_excluded_editor_folders_remove(&path, data_dir.as_deref())?,
        Commands::RegistrySetEditorField { matcher, key, value_json, data_dir } => unity_hub::commands::registry_set_editor_field(&matcher, &key, &value_json, data_dir.as_deref())?,
        Commands::PrefsHideHubOnEditorOpenGet { data_dir } => unity_hub::commands::prefs_hide_hub_on_editor_open_get(data_dir.as_deref())?,
        Commands::PrefsHideHubOnEditorOpenSet { value, data_dir } => unity_hub::commands::prefs_hide_hub_on_editor_open_set(value, data_dir.as_deref())?,
        Commands::PrefsProjectSortGet { data_dir } => unity_hub::commands::prefs_project_sort_get(data_dir.as_deref())?,
        Commands::PrefsProjectSortSet { sort_by, sort_direction, data_dir } => unity_hub::commands::prefs_project_sort_set(&sort_by, &sort_direction, data_dir.as_deref())?,
        Commands::PrefsSkipRemoveConfirmationGet { data_dir } => unity_hub::commands::prefs_skip_remove_confirmation_get(data_dir.as_deref())?,
        Commands::PrefsSkipRemoveConfirmationSet { always, timestamp, data_dir } => unity_hub::commands::prefs_skip_remove_confirmation_set(always, timestamp, data_dir.as_deref())?,
        Commands::DownloadsPausedGet { data_dir } => unity_hub::commands::downloads_paused_get(data_dir.as_deref())?,
        Commands::DownloadsPausedClear { data_dir } => unity_hub::commands::downloads_paused_clear(data_dir.as_deref())?,
        Commands::DownloadsPausedAddEntry { entry_json, data_dir } => unity_hub::commands::downloads_paused_add_entry(&entry_json, data_dir.as_deref())?,
        Commands::DownloadsPausedRemoveEntry { uid, data_dir } => unity_hub::commands::downloads_paused_remove_entry(&uid, data_dir.as_deref())?,
        Commands::InstallStateInfo { data_dir } => unity_hub::commands::install_state_info(data_dir.as_deref())?,
        Commands::InstallStateDownloads { data_dir } => unity_hub::commands::install_state_downloads(data_dir.as_deref())?,
        Commands::InstallStateInstalls { data_dir } => unity_hub::commands::install_state_installs(data_dir.as_deref())?,
        Commands::InstallStateQueueDownload { uid, version, arch, modules_json, data_dir } => unity_hub::commands::install_state_queue_download(&uid, &version, arch.as_deref(), &modules_json, data_dir.as_deref())?,
        Commands::InstallStateSetDownloadState { uid, state, bytes_done, bytes_total, data_dir } => unity_hub::commands::install_state_set_download_state(&uid, &state, bytes_done, bytes_total, data_dir.as_deref())?,
        Commands::InstallStateCancelDownload { uid, data_dir } => unity_hub::commands::install_state_cancel_download(&uid, data_dir.as_deref())?,
        Commands::InstallStateQueueInstall { uid, version, modules_json, pid, data_dir } => unity_hub::commands::install_state_queue_install(&uid, &version, &modules_json, pid, data_dir.as_deref())?,
        Commands::InstallStateClearInstall { data_dir } => unity_hub::commands::install_state_clear_install(data_dir.as_deref())?,
        Commands::InstallStateFileClaims { data_dir } => unity_hub::commands::install_state_file_claims(data_dir.as_deref())?,
        Commands::InstallStateSchemaMeta { data_dir } => unity_hub::commands::install_state_schema_meta(data_dir.as_deref())?,
        Commands::InstallStateSetInstallPhase { phase, data_dir } => unity_hub::commands::install_state_set_install_phase(&phase, data_dir.as_deref())?,
        Commands::InstallStateUpsertFileClaim { pid, source, path, data_dir } => unity_hub::commands::install_state_upsert_file_claim(pid, &source, &path, data_dir.as_deref())?,
        Commands::InstallStateRemoveFileClaim { pid, source, path, data_dir } => unity_hub::commands::install_state_remove_file_claim(pid, &source, &path, data_dir.as_deref())?,
        Commands::InstallStateClearFileClaims { data_dir } => unity_hub::commands::install_state_clear_file_claims(data_dir.as_deref())?,
        Commands::Ipc { method, args, data_dir } => {
            let dir = if let Some(d) = data_dir { std::path::PathBuf::from(d) } else { unity_hub::hub_registry::hub_data_dir() };
            unity_hub::ipc::dispatch(&method, &args, &dir)?;
        }
        Commands::RendererInfo { app_dir } => unity_hub::commands::renderer_info(app_dir.as_deref())?,
        Commands::RendererServe { window, port, app_dir } => unity_hub::commands::renderer_serve(&window, port, app_dir.as_deref())?,
        Commands::RendererOpen { window, port, app_dir } => unity_hub::commands::renderer_open(&window, port, app_dir.as_deref())?,
    }
    Ok(())
}
