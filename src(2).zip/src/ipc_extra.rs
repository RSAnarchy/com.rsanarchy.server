//! Namespaced renderer channels (`ns/method`) from the Unity Hub 3.22 renderer.
//!
//! The 3.22 renderer invokes channels such as `projects/getProjectsInfo` or
//! `installs/locate`. `IpcMainService` registers each one with `ipcMain.handle`.
//! This module handles the namespaced channels that the legacy suffix dispatch in
//! `ipc.rs` does not cover. Anything that needs Unity cloud services, a VCS backend,
//! or a destructive install returns an explicit error, so the renderer rejects it
//! rather than showing invented data.

use crate::error::{HubError, Result};
use serde_json::{json, Value};
use std::path::{Path, PathBuf};
use std::process::Command;

fn emit(v: Value) -> Result<()> {
    println!("{v}");
    Ok(())
}

fn unavailable(channel: &str, why: &str) -> Result<()> {
    Err(HubError::Other(format!("{channel}: {why}")))
}

fn arg(args: &[String], i: usize) -> &str {
    args.get(i).map(|s| s.as_str()).unwrap_or("")
}

fn read_or(data_dir: &Path, file: &str, default: Value) -> Value {
    crate::hub_storage::read_json(data_dir, file).unwrap_or(default)
}

fn save_arg(data_dir: &Path, file: &str, args: &[String]) -> Result<()> {
    let raw = arg(args, 0);
    let v = serde_json::from_str::<Value>(raw).unwrap_or_else(|_| Value::String(raw.to_string()));
    crate::hub_storage::write_json(data_dir, file, &v)?;
    emit(json!({"ok": true, "value": v}))
}

fn language(data_dir: &Path) -> String {
    read_or(data_dir, "languageConfig.json", Value::Null)
        .get("language")
        .and_then(|v| v.as_str())
        .unwrap_or("en")
        .to_string()
}

fn open_in_shell(target: &str) -> Result<()> {
    let spawned = if cfg!(windows) {
        Command::new("explorer").arg(target).spawn()
    } else if cfg!(target_os = "macos") {
        Command::new("open").arg(target).spawn()
    } else {
        Command::new("xdg-open").arg(target).spawn()
    };
    spawned.map_err(|e| HubError::Other(format!("failed to open {target}: {e}")))?;
    emit(json!({"ok": true, "opened": target}))
}

fn list_dir(path: &str) -> Value {
    match std::fs::read_dir(path) {
        Ok(rd) => Value::Array(
            rd.flatten()
                .map(|e| {
                    json!({
                        "name": e.file_name().to_string_lossy().to_string(),
                        "isDirectory": e.path().is_dir()
                    })
                })
                .collect(),
        ),
        Err(_) => json!([]),
    }
}

/// Unity projects are directories containing `ProjectSettings/ProjectVersion.txt`.
fn scan_projects(root: &str) -> Value {
    let mut out = Vec::new();
    if let Ok(rd) = std::fs::read_dir(root) {
        for e in rd.flatten() {
            let p = e.path();
            if p.join("ProjectSettings").join("ProjectVersion.txt").is_file() {
                out.push(json!({
                    "path": p.to_string_lossy().to_string(),
                    "name": e.file_name().to_string_lossy().to_string()
                }));
            }
        }
    }
    Value::Array(out)
}

fn delegate(method: &str, args: &[String], data_dir: &Path) -> Result<()> {
    crate::ipc::dispatch(method, args, data_dir)
}

/// Returns `None` when the channel is not namespaced here, so the caller falls back
/// to the legacy suffix dispatch.
pub fn dispatch(channel: &str, args: &[String], data_dir: &Path) -> Option<Result<()>> {
    let (ns, method) = channel.split_once('/')?;
    let full = channel;
    let r: Result<()> = match (ns, method) {
        // ---- common ----
        ("common", "getThemeSettings") => emit(read_or(data_dir, "themeSettings.json", json!({"themeSource": "system"}))),
        ("common", "setThemeSettings") => save_arg(data_dir, "themeSettings.json", args),
        ("common", "getAppRootPath") => emit(json!(crate::renderer::default_extracted_app_root().to_string_lossy().to_string())),
        ("common", "getI18nLocale") => emit(json!(language(data_dir))),
        ("common", "getInstallPathStorageAvailable") => emit(json!(true)),
        ("common", "checkReadWriteAccess") => emit(json!(Path::new(arg(args, 0)).exists())),
        ("common", "showOpenFileDialog") | ("common", "chooseProjectPath") | ("common", "chooseLicenseFilePath") => {
            emit(json!({"canceled": true, "filePaths": []}))
        }
        ("common", "openLogDir") => {
            let dir = data_dir.join("logs");
            let _ = std::fs::create_dir_all(&dir);
            open_in_shell(&dir.to_string_lossy())
        }
        ("common", "rendererInitialized")
        | ("common", "initLivePlatformClient")
        | ("common", "updateLivePlatformLocale")
        | ("common", "openBugReport")
        | ("common", "setBugReportFlow")
        | ("common", "showTestNotification") => emit(Value::Null),

        // ---- projects ----
        ("projects", "toggleFavoriteProject") => delegate("setProjectFavorite", args, data_dir),
        ("projects", "removeProjectFromList") => delegate("removeProject", args, data_dir),
        ("projects", "getCountFromProject") => emit(json!(0)),
        ("projects", "validateIfProjectIsOpen") => emit(json!(false)),
        ("projects", "validateEditorHasOpenInEditorFeatureSupport") => emit(json!(true)),
        ("projects", "dismissDeeplinkOperation") => emit(Value::Null),
        ("projects", "scanDirectoryForProjects") => emit(scan_projects(arg(args, 0))),
        ("projects", "renameProject")
        | ("projects", "moveProject")
        | ("projects", "createTempProject")
        | ("projects", "linkCloudProject")
        | ("projects", "unlinkCloudProject")
        | ("projects", "projectAuditorPrepare")
        | ("projects", "projectAuditorTakeStatus")
        | ("projects", "projectAuditorWithdrawScript") => {
            unavailable(full, "not yet implemented in the Rust port")
        }

        // ---- templates ----
        ("templates", "getAllTemplates") | ("templates", "getLocalTemplates") | ("templates", "getUserTemplates") => {
            emit(json!([]))
        }
        ("templates", "getUserTplPath") => emit(read_or(data_dir, "userTemplatePath.json", Value::Null)),
        ("templates", "setUserTplPath") => save_arg(data_dir, "userTemplatePath.json", args),
        ("templates", "newTplPathCheck") | ("templates", "checkUserTemplateExists") => {
            emit(json!(Path::new(arg(args, 0)).exists()))
        }
        ("templates", "checkDiskSpaceAvailableForTemplate") => emit(json!({"ok": true, "available": true})),
        ("templates", "getLongestFilePathFromTemplate") => emit(json!(0)),
        ("templates", "getTermsOfServiceContent") => emit(json!("")),
        ("templates", "listProjectRootFiles") => emit(list_dir(arg(args, 0))),
        ("templates", "openPlasticURL") | ("templates", "watchForPlastic") => emit(Value::Null),
        ("templates", "create")
        | ("templates", "delete")
        | ("templates", "edit")
        | ("templates", "downloadTemplate")
        | ("templates", "upgradeTemplate") => unavailable(full, "template authoring is not yet implemented in the Rust port"),

        // ---- downloads ----
        ("downloads", "getDownloadList") => delegate("getDownloadsState", args, data_dir),
        ("downloads", "queue") => delegate("queueDownload", args, data_dir),
        ("downloads", "remove") => delegate("cancelDownload", args, data_dir),
        ("downloads", "getCustomDownloadLocation") => delegate("getDownloadLocation", args, data_dir),
        ("downloads", "getEditors") | ("downloads", "getCachedDownloadableEditors") => emit(json!([])),
        ("downloads", "dismissExternal") | ("downloads", "loadCustomEditorInfo") => emit(Value::Null),
        ("downloads", "getEulaContent") => emit(json!("")),

        // ---- installs ----
        ("installs", "getInstallList") | ("installs", "getInstalls") => delegate("getInstallsState", args, data_dir),
        ("installs", "locate") => delegate("locateEditor", args, data_dir),
        ("installs", "remove") => delegate("removeEditor", args, data_dir),
        ("installs", "retry") => delegate("queueDownload", args, data_dir),
        ("installs", "disconnectEditor") | ("installs", "updateModulesWithVisualStudioInstallationState") => {
            emit(Value::Null)
        }
        ("installs", "uninstall") | ("installs", "removeEditorModule") => {
            unavailable(full, "uninstall needs explicit approval; not run by the port")
        }

        // ---- licenses ----
        ("licenses", "getUserLicense") => emit(Value::Null),
        ("licenses", "agreedToPersonalLicenseEula") => emit(read_or(data_dir, "personalLicenseEula.json", json!(false))),
        ("licenses", "disagreedWithPersonalLicenseEula") => {
            match crate::hub_storage::write_json(data_dir, "personalLicenseEula.json", &json!(false)) {
                Ok(()) => emit(Value::Null),
                Err(e) => Err(e),
            }
        }
        ("licenses", "getEntitlementBasedLicenseActivationError") => emit(Value::Null),
        ("licenses", _) => unavailable(full, "license services require Unity online services; not available in this port"),

        // ---- auth ----
        ("auth", "getIdentity") => emit(Value::Null),
        ("auth", "initialize") => emit(json!(true)),
        ("auth", "login") | ("auth", "retryLogin") | ("auth", "switchAccount") => {
            unavailable(full, "Unity sign-in requires Unity online services; not available in this port")
        }

        // ---- window (browser-hosted renderer: no native window to control) ----
        ("window", "minimize") | ("window", "maximize") | ("window", "restore") | ("window", "close")
        | ("window", "setOverlayTheme") | ("window", "channelBroadcast") => emit(Value::Null),
        ("window", "isFullScreen") | ("window", "isMaximized") => emit(json!(false)),

        // ---- machine ----
        ("machine", "getChipArchitecture") => emit(json!(if cfg!(target_arch = "aarch64") { "arm64" } else { "x64" })),
        ("machine", "getIsAppleSilicon") => emit(json!(cfg!(all(target_os = "macos", target_arch = "aarch64")))),
        ("machine", "getIsWindowsArm64") => emit(json!(cfg!(all(windows, target_arch = "aarch64")))),
        ("machine", "getIsCurrentOperatingSystemDeprecated") => emit(json!(false)),

        // ---- tools (OS folder openers) ----
        ("tools", "openCrashDumps") | ("tools", "openCrashLogs") | ("tools", "openEditorLogs")
        | ("tools", "openPlayerLogs") | ("tools", "openGICache") | ("tools", "openUnityCache")
        | ("tools", "openAssetPackages") | ("tools", "openAutomationSettings") => {
            let dir = data_dir.join(method);
            let _ = std::fs::create_dir_all(&dir);
            open_in_shell(&dir.to_string_lossy())
        }
        ("tools", "unityCliStatus") => emit(json!({"installed": false})),
        ("tools", "unityCliLatestVersion") => emit(Value::Null),
        ("tools", "unityCliInstall") | ("tools", "unityCliUpdate") | ("tools", "unityCliOpen") => {
            unavailable(full, "Unity CLI management is not yet implemented in the Rust port")
        }

        // ---- config / flags / content (local-only) ----
        ("localConfig", "getHubConfig") => emit(read_or(data_dir, "hubConfig.json", json!({}))),
        ("userSettings", "setUserSettings") => save_arg(data_dir, "userSettings.json", args),
        ("featureFlags", "getDefaultFeatureFlag") => emit(json!(false)),
        ("banners", "getBanners") => emit(json!([])),
        ("community", "getResources") => emit(json!([])),
        ("learn", "getFeatured") | ("learn", "getRecommended") | ("learn", "getDownloadedLearnProjects") => {
            emit(json!([]))
        }
        ("notificationService", "getNotificationCount") => emit(json!(0)),
        ("notificationService", "markAllNotificationsAsRead") | ("notificationService", "markNotificationAsRead") => {
            emit(Value::Null)
        }
        ("about", "getInfo") => emit(json!({
            "name": "Unity Hub",
            "version": "3.22.6",
            "platform": std::env::consts::OS
        })),
        ("about", "openThirdPartyNotice") => emit(Value::Null),
        ("autoUpdater", "getUpgradeVersion") => emit(Value::Null),
        ("autoUpdater", "restartAndUpdate") => unavailable(full, "auto-update is not available in the Rust port"),
        ("analytics", "sendEvent") => emit(Value::Null),
        ("analytics", "getAmplitudeSessionId") => emit(json!("")),
        ("externalService", "openExternal") => {
            let url = arg(args, 0);
            if url.starts_with("http://") || url.starts_with("https://") {
                open_in_shell(url)
            } else {
                unavailable(full, "refusing to open non-http URL")
            }
        }
        ("externalService", "getExternalUrl") => emit(json!(arg(args, 0))),
        ("path", "join") => {
            let joined: PathBuf = args.iter().fold(PathBuf::new(), |p, a| p.join(a));
            emit(json!(joined.to_string_lossy().to_string()))
        }
        ("fs", "pathSeparator") => emit(json!(if cfg!(windows) { "\\" } else { "/" })),
        ("startup", "hydrate") | ("surveySettings", "decrementUSCSurveyCountdown")
        | ("onboardingSurvey", "getNUOHeader") | ("manifest", "syncForSourceControl")
        | ("apm", "notifyFirstPageLoad") | ("bg-task", "cancel") | ("bg-task", "clear")
        | ("projectService", "forceUpdateSourceControlStatus") => emit(Value::Null),
        ("age-gate", "verify") => emit(json!(true)),
        ("age-gate", "underage") => emit(json!(false)),
        ("backgroundTasks", "get") => emit(json!([])),
        ("sourceControl", "getCurrentBranches") => emit(json!({})),
        ("deeplink", "cancelPackageInstall") | ("deeplink", "installPackageAndResume")
        | ("deeplink", "resumeWithoutInstall") => unavailable(full, "deeplink package install is not yet implemented"),
        ("appLinking", "createShareLink") => unavailable(full, "share links require Unity online services"),

        _ => return None,
    };
    Some(r)
}
