# Handoff - Unity Hub 3.22.6 (Electron) -> Rust Port

## STATUS SNAPSHOT (read first; supersedes older sections below where they conflict)
- **Launch:** `unity-hub` with no args -> `renderer::run_gui` serves the 3.22 `main_window` renderer on a free 127.0.0.1 port and opens it in the default browser (Ctrl+C to stop). Not an embedded window (no webview crate in the stack).
- **Stack (matches official port):** serde/serde_json, tokio (rt, rt-multi-thread, macros, time, net, io-util, sync), reqwest+rustls, rusqlite (bundled), clap, sha2.
- **Renderer bridge (`src/renderer.rs`):** `window.api` and `window.bugReporterApi` reproduce the real preload contracts (`mainWindowPreload.cjs`, `bugReporterPreload.cjs`). Startup values come from the same `<key>.json` files 3.22 reads. `invoke` rejects on backend error. `/__events` SSE exists, with no producer yet.
- **IPC routing:** renderer channels are namespaced `ns/method` (401 found). `ipc::dispatch` takes the full channel; `src/ipc_extra.rs` handles namespaced channels first, then falls back to suffix arms in `ipc.rs`. Unknown channels return an error (renderer rejects).
- **Intentionally unimplemented (error, not fake data):** Unity sign-in/licensing/entitlements, cloud/UVCS/Git/Perforce/proton/gatewayAPI backends, assistant-desktop/* (104 channels), template authoring, uninstall (needs explicit approval), auto-update, deeplink package install.
- **Verification:** `cargo check` passes. No tests run and no browser run (per user instruction). First real test: launch `unity-hub.exe`, confirm main window renders, then work through console errors.
- **Next priorities:** (1) browser run of main_window, fix response-shape mismatches against renderer expectations; (2) projects/editors list screens end to end; (3) templates enumeration from installed editors; (4) in-process dispatch instead of per-call CLI spawn; (5) real Windows verification of `cmd /C start` open-url path.

---

## Current objective
Port **Unity Hub 3.22.6 (Electron)** to Rust with **1:1 functionality** (user-directed). Source of truth is the installed 3.22 app and extracted `electron-hub-3.22/app` (from `resources/app.asar`). GUI/renderer parity for `main_window` and `bug_reporter_window` is in progress (browser-hosted renderer path).

## Workspace
`C:\Users\liqui\Desktop\Unity Hub 4.0.0 rust rewrite` (Windows, no git repo; build/run with `cargo --offline`; recent work uncommitted).

### Key artifacts
- `electron-hub-3.22/app/` - extracted 3.22.6 asar (**3410 files**)
  - `package.json`: `name: unity-hub`, `version: 3.22.6`, `main: .vite/build/index.js`
  - `.vite/build/`: **541** main-process modules (**77** service families, **21** manager families); `MainServices` channels extracted to `electron-hub-3.22/mainservices-methods.txt` (**299** methods)
  - `.vite/renderer/`: **48** files, including `main_window` (`index.html`, `panel-popout.html`, `popout-host.html`, assets) and `bug_reporter_window` (`bug-reporter.html`, assets)
- `runtime/unity-hub-3.22.exe` - preserved copy of 3.22 `resources/unity.exe` (**28,111,840 bytes**, SHA-256 `E42CA022CCEF31D86DD1748213622E5B27E310EFAA6FC16F19426B739C84AB7D`, must remain byte-for-byte)
- `Old Hub/` - Unity Hub 4.0.0 reference install (kept; `verify` checksums/i18n/`runtime/unity.exe` preserved)
- `handoff.md`, `README.md`, `PORT_README.md`, `electron-hub-3.22/file-manifest.txt`

## Rust crate
- **Name:** `unity-hub`, **version:** `3.22.6-port.0`, **edition:** 2024
- **Deps:** `serde`, `serde_json`, `thiserror`, `clap` (derive), `tokio`, `reqwest` (rustls-tls,json), `rusqlite` (bundled), `sha2` (no webview deps; `cargo --offline`)
- **Key modules:** `main.rs`/`commands.rs` (CLI), `ipc.rs` (MainServices/IPC dispatch + handlers), `renderer.rs` (renderer window discovery + static host + bridge injection), `hub_registry.rs`/`hub_storage.rs`, `install_state.rs`, `downloads.rs`, `installs.rs`, `updates.rs`, `projects.rs`, `services/*` (`local_project`, `editor_inventory`, `installation_manager`, `hub_app`, etc.), `app_inventory.rs`, `checksums.rs`, `ui.rs`, `versions.rs`, `i18n.rs`, `models.rs`, `storage.rs`

## CLI surface (selected, implemented)
- Discovery/status: `editors`, `projects`, `verify`, `port-status`, `editor-templates`, `editor-modules`, `editor-install-status`
- Registry: `registry-projects|editors|recents|get-project`, add/remove/sync projects & editors, favorite/custom-editor/manual/field/tag/touch flows
- Storage/prefs: `storage-list|get|set`, `prefs-*` (project dir, secondary install path, excluded folders, sort/hide/skip, banners/first-time/org/language/theme/settings), `downloads-paused-*`
- Install-state: `install-state-info|downloads|installs|file-claims|schema-meta` + queue/set/cancel/clear/install-phase/file-claim mutations
- Downloads/install/module/cache flows: `install-download` (HTTP + install-state progress), `install-execute-local`, `install-pipeline-local` (download -> integrity -> execute -> register/sync), `install-module-local` (ZIP/PO, integrity, `{UNITY_PATH}` dest/rename, extract), `install-queue-cached-release`, `install-plan-cached-release`, `releases-cache`
- Project flows: `project-version-info`, `project-open-plan|project-create-plan|project-open-args|project-create-args`, `project-open|project-create`
- IPC: `ipc channels`, `ipc [--data-dir PATH] <method> [args...]` (MainServices-aligned, local/schema-compatible best-effort)
- Renderer (browser-hosted): `renderer-info [--app-dir PATH]`, `renderer-serve --window <main_window|bug_reporter_window> --port <port> [--app-dir PATH]`, `renderer-open ...`

## Renderer / GUI parity status (current)
- **Implemented (verified):** `src/renderer.rs` + CLI can discover and host extracted Hub 3.22 renderer windows from `electron-hub-3.22/app/.vite/renderer` (`main_window` -> `index.html`, `bug_reporter_window` -> `bug-reporter.html`) over local HTTP. Serves original 3.22 HTML/CSS/JS/assets, injects bridge shims (`/__hub_bridge.js` exposing `window.api`, `/__bug_reporter_bridge.js` exposing `bugReporterApi`), and provides `POST /__ipc` to dispatch to Rust `ipc` handlers (returns JSON/stdout). `renderer-open` starts server and opens in system browser (browser-only host; no embedded webview required per current direction).
- **Verified evidence:** `renderer-info` lists both windows correctly. Served assets return correct MIME/content (after fix): e.g. `main-CDFt3-LL.js` -> `200 application/javascript` (1,295,711 bytes), modulepreloads/ThemeProvider JS/CSS/woff2 correct, `bug-reporter.html` + bug reporter JS/CSS correct, bridge injected, `/__ipc` live (`getOperatingSystem` -> `"windows"`, `getCurrentLocale` -> `"en"`).
- **Fix applied:** `sanitize_path` now ignores HTTP `RootDir` (`/assets/...`) instead of rejecting it; this resolved `text/html` fallback for module/asset requests (reported as blocked module load MIME).
- **Not yet 1:1 visually/runtime-complete:** no native embedded Electron-equivalent window shell; preload/startup/event parity incomplete (push `ipcRenderer.on` events, full startup payloads/`getPathForFiles`/window controls/theme/attachments behaviors, full MainServices semantics expected by renderer). Browser runtime shows renderer JS executes but hits data/shape and environment mismatches (e.g. `e.filter`/`t.map`/iterator startup errors, `sentry-ipc://` CORS noise from Sentry Electron transport in browser, source map 404s for missing `.map` files) - bridge/IPC response shapes and startup/event flows need further alignment to achieve 1:1 rendered UI.

## IPC / MainServices coverage
- **Discovered:** 299 MainServices method names (`electron-hub-3.22/mainservices-methods.txt`), 541 bundled main-process modules, 77 service families, 21 manager families.
- **Handler presence (static, string-matched in `src/ipc.rs`):** ~120/299 method names have handlers/aliases; this is **not** full behavioral/runtime parity.
- **Implemented/expanded areas (local/schema-compatible best-effort):** project/editor registry & operations (get/add/remove/favorite/tags/recents/open/touch/custom/deeplink/refresh/locate/sync/manual/version/from-path/validation/plans), install-state/paused-download/file-claim reads & mutations, download/install/module/cache planning & execution helpers (including real HTTP download, integrity verify md5/sha256/384/512, ZIP extract, cached-release plan/queue, local/module pipeline), storage-backed prefs/settings/user/org/cloud/template/hub-info/flags/CLI plugin-update/language/theme/notifications, path/file/disk/git-vcs utility queries, window/license/auth/update stubs and environment probes, generic storage JSON get/set, and `__ipc` bridge dispatch path.

## Verified evidence (recent)
- `cargo check --offline` / `cargo build --release --offline`: **pass** (warnings only: unreachable duplicate IPC arms, unused helper).
- **Renderer host:** `renderer-info` resolves both windows; `renderer-serve` injects bridge and serves 3.22 assets with correct MIME/content; `POST /__ipc` returns Rust-backed IPC results (e.g. `getOperatingSystem` `"windows"`, `getCurrentLocale` `"en"`). Module-load MIME blocker fixed and verified for main/bug-reporter assets.
- **Real/safe local flows (previously verified in workspace):** registry/storage/install-state reads/writes and project/editor operations against real `%APPDATA%\UnityHub` data and temp dirs; cached-release planning from real cache (`6000.3.28f1`, URL/integrity/size/dest/suggested args); real Unity CDN small-asset download + integrity + install-state tracking + registration/extraction (`android-sdk-ndk-tools`, sha384 matched, ZIP extracted to resolved `{UNITY_PATH}` dest); md5 integrity handling for installer metadata; end-to-end local/simulated download->integrity->install->registration pipeline with scan sync.

## Known gaps / blockers
- **Not 1:1 functionality:** most MainServices behaviors and 541 bundled modules unimplemented/unverified; no demonstrated full end-to-end real editor/module installer download+execution and post-install reconciliation at runtime parity; incomplete auth/license/cloud/VCS/updates, background/tray/notifications/protocol/diagnostics/analytics runtime behavior; renderer runtime parity incomplete (bridge/startup/events/data-shape alignment, visual state parity).
- **Blocked on explicit user decision/approval (system-modifying, large):** real cached editor install execution (e.g. `6000.3.28f1`, ~4.21 GB, `md5-qk6SSXDsB0/n2iy3EbP9SQ==`, suggested `/S /D=C:\Program Files\Unity\Hub\Editor\6000.3.28f1`) requires scope/editor+modules, `download-only` vs `download+execute`, install target/path and elevation/admin approval, and confirmation to consume disk/network/time and modify system.
- **External/manual dependencies:** Unity auth/licensing/entitlements, cloud/VCS credentials/services, live feeds/CDN behavior beyond local cache/small assets, OS integration (tray/protocol/elevation), and full Electron-equivalent runtime/GUI behavior.

## Suggested next steps
1. **Renderer runtime parity (browser-hosted):** instrument and align `/__ipc` responses/startup channels to 3.22-expected shapes (fix `filter/map/iterator` startup failures), add event emission/startup payload parity (`ipcRenderer.on`), and verify rendered UI state against Hub 3.22 (screenshot/DOM evidence).
2. **IPC/service parity:** continue mapping/implementing MainServices handlers and service flows with runnable evidence (install/module/reconciliation, settings/storage, editor/project flows), deduplicating unreachable arms.
3. **Real install flow (on approval):** execute and verify cached-release download -> integrity -> installer/module execution -> install-state/editors-registry reconciliation end-to-end for approved scope/target.
4. **Runtime/GUI completion:** expand background/tray/protocol/diagnostics/analytics/auth/licensing/cloud/VCS integrations and full window behavior parity as capabilities allow.
5. Keep `handoff.md`/`README.md` aligned with verified evidence only.

## Session update: renderer host rewritten (top priority)
- Stack now matches the official port: serde/serde_json, tokio (rt-multi-thread, net, io-util, sync), reqwest+rustls, rusqlite (bundled), clap, sha2.
- `src/renderer.rs` rewritten on tokio. Bridge now mirrors the real preloads:
  - `window.api` == `mainWindowPreload.cjs` contract: `ipcRenderer.invoke/on/off` (on returns unsubscribe), `platform`, `performanceReport`, `getPathForFiles`, `startupProjects|Config|Prefs|SignedIn|GetSetUp|WcoOverlay|Language`, `notifyRendererReady`.
  - `window.bugReporterApi` == `bugReporterPreload.cjs` contract (on/off only for theme-changed, attachments-manifest-changed).
  - Startup values come from the same files 3.22 reads: `projects-v1.json` (`data` object, first 20), `hubConfig.json`, `projectSortPreferences.json`, `projectTablePreferences.json`, `hideGetSetUp.json`, `firstTimeSettings.json`, `languageConfig.json`.
  - `invoke` rejects on backend error (HTTP 500 `{error}`), matching Electron. Unimplemented channels now reject instead of returning fake 200 data.
  - `/__events` SSE channel added for pushed events (no producer wired yet).
  - Missing `.map` files return `{}` instead of 404.
- Known gaps in renderer: `signedIn` is always false (no keyring/accounts DB); projects are not sorted by sort prefs; `/__ipc` still shells out to the CLI per call (could move in-process); no browser runtime verification performed this session (static analysis of preloads only); `sentry-ipc://` noise not addressed.
- Compile: `cargo check` passes (no tests run, per request).

## Session update: functional routing (namespaced channels)
- Key finding: the 3.22 renderer invokes namespaced channels `ns/method` (401 found in renderer bundles, e.g. `projects/getProjectsInfo`, `installs/locate`). `IpcMainService.prepareIPCConnection` registers them with `ipcMain.handle`. Suffix dispatch alone could not reach them.
- `ipc::dispatch` now takes the full channel: `src/ipc_extra.rs` handles namespaced channels first (common, projects, templates, downloads, installs, licenses, auth, window, machine, tools, localConfig, flags/content, misc). Delegates to existing suffix arms where they exist (getDownloadsState, queueDownload, cancelDownload, getInstallsState, locateEditor, removeEditor, setProjectFavorite, removeProject).
- Services that need Unity online services, VCS backends, or destructive installs return explicit errors (renderer rejects) rather than fake data.
- Renderer channel list extracted to the session workspace (/tmp/renderer_channels.json), not shipped.
- Still open: the `renderer-*` channel enum for assistant-desktop/* (104 channels) and proton/gatewayAPI/vcs/gitService/uvcsService/perforceService have no handlers (intentional). Response shapes for list channels are best-effort and not checked against the 3.22 renderer's TypeScript types. No runtime/browser verification performed (per request); `cargo check` passes.

## Session update: no-argument launch opens the Hub
- `unity-hub` with no arguments now runs `renderer::run_gui`: it locates the extracted 3.22 bundle at runtime (exe ancestors, cwd, then compile-time fallback), serves `main_window` on a free 127.0.0.1 port using the preload-contract bridge, and opens it in the system browser. Ctrl+C stops it. Subcommands are unchanged.
- Limitation: the renderer runs in the browser, not in an embedded Electron-style window (no webview crate in the stack).
- `cargo check` passes; not run in a browser this session.
