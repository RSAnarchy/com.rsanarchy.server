//! Update feed / self-update handling.

use crate::error::Result;
use serde::Deserialize;
use serde_json::Value;
use std::path::Path;

/// A Unity Editor release as returned by the Hub version feed.
#[derive(Debug, Clone, PartialEq, Eq, Deserialize)]
pub struct Release {
    pub version: String,
    #[serde(default)]
    pub release_type: Option<String>,
    #[serde(default)]
    pub download_url: Option<String>,
}

/// Client used to query the Unity version feed. Kept as a trait so tests can run
/// against a fake feed without touching the network.
pub trait ReleaseFeedClient {
    /// Return the newest releases published for the given product.
    fn latest_releases(&self, product: &str, limit: usize) -> Result<Vec<Release>>;
}

pub struct UnityReleaseFeed {
    client: reqwest::Client,
}

impl UnityReleaseFeed {
    pub fn new() -> Result<Self> {
        let client = reqwest::Client::builder()
            .timeout(std::time::Duration::from_secs(30))
            .build()
            .map_err(|e| crate::error::HubError::Io(std::io::Error::new(
                std::io::ErrorKind::Other,
                e.to_string(),
            )))?;
        Ok(Self { client })
    }

    /// Fetch the latest published releases (e.g. `UNITY` product).
    pub async fn fetch_latest(&self, product: &str) -> Result<Vec<Release>> {
        let url = format!("https://releases.unity.com/{product}/releases?limit=25");
        let response = self
            .client
            .get(&url)
            .send()
            .await
            .map_err(|e| {
                crate::error::HubError::Io(std::io::Error::new(
                    std::io::ErrorKind::Other,
                    e.to_string(),
                ))
            })?;
        if !response.status().is_success() {
            return Err(crate::error::HubError::NotFound(format!(
                "release feed status {}",
                response.status()
            )));
        }
        let _body: serde_json::Value = response.json().await.map_err(|e| {
            crate::error::HubError::Io(std::io::Error::new(
                std::io::ErrorKind::Other,
                e.to_string(),
            ))
        })?;
        // TODO(rewrite): map the real feed schema onto `Release` once observed.
        let _ = product;
        Ok(Vec::new())
    }
}

impl Default for UnityReleaseFeed {
    fn default() -> Self {
        Self::new().expect("failed to create reqwest client")
    }
}

/// Check for updates; returns the newest release version when one is available.
pub fn check_for_updates() -> Option<String> {
    None
}

/// Read local downloadable editors cache (Hub GPUI cache observed at hub-gpui/downloadable-editors-cache.json).
pub fn read_downloadable_editors_cache(data_dir: &Path) -> Result<Option<(std::path::PathBuf, Value)>> {
    let candidates = [
        data_dir.join("hub-gpui").join("downloadable-editors-cache.json"),
        data_dir.join("downloadable-editors-cache.json"),
    ];
    for p in candidates {
        if p.is_file() {
            let content = std::fs::read_to_string(&p)?;
            let trimmed = content.trim_start_matches('\u{feff}');
            let v: Value = serde_json::from_str(trimmed)?;
            return Ok(Some((p, v)));
        }
    }
    Ok(None)
}

fn pick_platform_entry(cache: &Value) -> Option<&Value> {
    let entries = cache.get("entries")?.as_object()?;
    // Prefer Windows x86_64 English live-platform key if present, else first.
    let preferred = "WINDOWS|X86_64||en-US|https://live-platform-api.prd.ld.unity3d.com/graphql";
    if let Some(v) = entries.get(preferred) { return Some(v); }
    entries.values().next()
}

/// Summarize available releases from cache payload.
pub fn summarize_downloadable_editors(cache: &Value) -> Value {
    let entry = match pick_platform_entry(cache) {
        Some(e) => e,
        None => return serde_json::json!({"ok":false,"error":"no cache entries"}),
    };
    let cached_at = entry.get("cachedAtMs").cloned().unwrap_or(Value::Null);
    let data = entry.get("payload").and_then(|p| p.get("data")).cloned().unwrap_or(Value::Null);
    let mut streams = serde_json::Map::new();
    let mut total = 0usize;
    if let Some(obj) = data.as_object() {
        for (stream, releases) in obj {
            if let Some(arr) = releases.as_array() {
                total += arr.len();
                let versions: Vec<Value> = arr.iter().take(10).map(|r| {
                    let rel = r.get("latestUnityRelease").unwrap_or(r);
                    serde_json::json!({
                        "version": rel.get("version").cloned().unwrap_or(Value::Null),
                        "productName": rel.get("productName").cloned().unwrap_or(Value::Null),
                        "releaseDate": rel.get("releaseDate").cloned().unwrap_or(Value::Null),
                        "stream": rel.get("stream").cloned().unwrap_or(Value::String(stream.clone())),
                    })
                }).collect();
                streams.insert(stream.clone(), serde_json::json!({"count": arr.len(), "sample": versions}));
            }
        }
    }
    serde_json::json!({
        "ok": true,
        "cacheVersion": cache.get("version").cloned().unwrap_or(Value::Null),
        "cachedAtMs": cached_at,
        "totalReleases": total,
        "streams": streams
    })
}

/// Find a release in cache by version string (returns full release object and stream).
pub fn find_cached_release(cache: &Value, version: &str) -> Option<Value> {
    let entry = pick_platform_entry(cache)?;
    let data = entry.get("payload")?.get("data")?.as_object()?;
    for (stream, releases) in data {
        if let Some(arr) = releases.as_array() {
            for r in arr {
                let rel = r.get("latestUnityRelease").unwrap_or(r);
                let v = rel.get("version").and_then(|x| x.as_str()).unwrap_or("");
                if v == version {
                    return Some(serde_json::json!({
                        "stream": stream,
                        "release": rel.clone(),
                        "wrapper": r.clone()
                    }));
                }
            }
        }
    }
    None
}

/// Build a dry-run install plan for a cached release (no download/execution).
pub fn plan_cached_release_install(cache: &Value, version: &str, data_dir: &Path) -> Value {
    let found = match find_cached_release(cache, version) {
        Some(v) => v,
        None => return serde_json::json!({"ok":false,"version":version,"error":"release not found in cache"}),
    };
    let rel = found.get("release").cloned().unwrap_or(Value::Null);
    let downloads = rel.get("downloads").and_then(|d| d.as_array()).cloned().unwrap_or_default();
    // pick Windows x86_64 download if present
    let download = downloads.iter().find(|d| {
        d.get("platform").and_then(|p| p.as_str()) == Some("WINDOWS")
            && d.get("architecture").and_then(|a| a.as_str()) == Some("X86_64")
    }).cloned().or_else(|| downloads.first().cloned()).unwrap_or(Value::Null);
    let secondary = crate::hub_storage::read_json(data_dir, "secondaryInstallPath.json").ok()
        .and_then(|v| v.as_str().map(|s| s.to_string()))
        .filter(|s| !s.is_empty());
    let default_root = if cfg!(windows) {
        std::path::PathBuf::from(r"C:\Program Files\Unity\Hub\Editor")
    } else {
        std::path::PathBuf::from("/Applications/Unity/Hub/Editor")
    };
    let install_root = secondary.map(std::path::PathBuf::from).unwrap_or(default_root);
    let install_path = install_root.join(version);
    let download_url = download.get("url").and_then(|v| v.as_str()).map(|s| s.to_string());
    let integrity = download.get("integrity").and_then(|v| v.as_str()).map(|s| s.to_string());
    let download_type = download.get("type").and_then(|v| v.as_str()).map(|s| s.to_string());
    let arch = download.get("architecture").and_then(|v| v.as_str()).map(|s| s.to_string());
    let download_size = download.get("downloadSize").and_then(|s| s.get("value")).and_then(|v| v.as_i64());
    serde_json::json!({
        "ok": true,
        "version": version,
        "stream": found.get("stream").cloned().unwrap_or(Value::Null),
        "productName": rel.get("productName").cloned().unwrap_or(Value::Null),
        "releaseDate": rel.get("releaseDate").cloned().unwrap_or(Value::Null),
        "download": download,
        "downloadUrl": download_url,
        "integrity": integrity,
        "downloadType": download_type,
        "architecture": arch,
        "downloadSizeBytes": download_size,
        "plannedInstallPath": install_path.to_string_lossy(),
        "installRoot": install_root.to_string_lossy(),
        "note": "dry-run plan from local cache; no download/installer execution performed"
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    struct FakeFeed;

    impl ReleaseFeedClient for FakeFeed {
        fn latest_releases(&self, _product: &str, _limit: usize) -> Result<Vec<Release>> {
            Ok(vec![Release {
                version: "6000.3.15f1".to_string(),
                release_type: Some("LTS".to_string()),
                download_url: None,
            }])
        }
    }

    #[test]
    fn fake_feed_returns_releases() {
        let feed = FakeFeed;
        let releases = feed.latest_releases("UNITY", 5).unwrap();
        assert_eq!(releases.len(), 1);
        assert_eq!(releases[0].version, "6000.3.15f1");
    }
}
