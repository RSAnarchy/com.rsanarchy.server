//! Data model mirroring the Unity Hub 4.0.0 domain objects.

use serde::{Deserialize, Serialize};
use std::fmt;

/// An installed Unity Editor version detected on disk.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EditorInstall {
    /// e.g. "6000.1.3f1"
    pub version: String,
    /// e.g. "6000.1.3f1"
    pub install_name: String,
    /// Absolute path of the install, e.g. `C:/Program Files/Unity/Hub/Editor/6000.1.3f1`
    pub install_path: String,
    /// Path relative to the install root (the folder holding `Editor/`, `Data/`, ...).
    pub install_root: String,
    pub is_64_bit: bool,
    pub size_on_disk: u64,
}

/// A Unity module (runtime / tool / component / platform) that can be installed.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ModuleInfo {
    pub identifier: String,
    pub label: String,
    pub version: String,
    pub size: u64,
    pub category: String,
}

/// A Unity project registered in (or discoverable by) the Hub.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ProjectEntry {
    pub name: String,
    pub path: String,
    /// Editor version the project is configured to use, when known.
    pub editor_version: Option<String>,
    pub is_favorite: bool,
    pub is_offline: bool,
}

/// License state reported for a given editor version.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum LicenseState {
    /// License is confirmed / valid.
    Active,
    /// No license information available yet.
    None,
}

/// Lifecycle state of a Hub install, keyed by the `STATE_*` i18n keys.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum InstallState {
    Queued,
    Complete,
    Cancelled,
    Failed,
    CouldNotExtract,
    ElevationCancelled,
    ElevationFailed,
    ElevationDisabled,
    InstallerMissing,
    InstallerNoChecksum,
    InstallLocationUnavailable,
    InstallPathTooLong,
    InsufficientPermissions,
    NeedsElevation,
    Timeout,
    VisualStudioBusy,
    VisualStudioDownloadFailed,
    VisualStudioFailed,
    VisualStudioUnsupportedSystem,
    WaitingForAnotherInstaller,
}

impl InstallState {
    pub fn as_key(self) -> &'static str {
        match self {
            Self::Queued => "STATE_QUEUED",
            Self::Complete => "STATE_COMPLETE",
            Self::Cancelled => "STATE_CANCELLED",
            Self::Failed => "STATE_FAILED",
            Self::CouldNotExtract => "STATE_COULD_NOT_EXTRACT",
            Self::ElevationCancelled => "STATE_ELEVATION_CANCELLED",
            Self::ElevationFailed => "STATE_ELEVATION_FAILED",
            Self::ElevationDisabled => "STATE_ELEVATION_ALIAS_DISABLED",
            Self::InstallerMissing => "STATE_INSTALLER_MISSING",
            Self::InstallerNoChecksum => "STATE_INSTALLER_NO_CHECKSUM",
            Self::InstallLocationUnavailable => "STATE_INSTALL_LOCATION_UNAVAILABLE",
            Self::InstallPathTooLong => "STATE_INSTALL_PATH_TOO_LONG",
            Self::InsufficientPermissions => "STATE_INSUFFICIENT_PERMISSIONS",
            Self::NeedsElevation => "STATE_NEEDS_ELEVATION",
            Self::Timeout => "STATE_TIMEOUT",
            Self::VisualStudioBusy => "STATE_VISUAL_STUDIO_BUSY",
            Self::VisualStudioDownloadFailed => "STATE_VISUAL_STUDIO_DOWNLOAD_FAILED",
            Self::VisualStudioFailed => "STATE_VISUAL_STUDIO_FAILED",
            Self::VisualStudioUnsupportedSystem => "STATE_VISUAL_STUDIO_UNSUPPORTED_SYSTEM",
            Self::WaitingForAnotherInstaller => "STATE_WAITING_FOR_ANOTHER_INSTALLER",
        }
    }

    /// Reverse lookup of an install state key, e.g. `STATE_FAILED`.
    pub fn from_key(key: &str) -> Option<Self> {
        let state = match key {
            "STATE_QUEUED" => Self::Queued,
            "STATE_COMPLETE" => Self::Complete,
            "STATE_CANCELLED" => Self::Cancelled,
            "STATE_FAILED" => Self::Failed,
            "STATE_COULD_NOT_EXTRACT" => Self::CouldNotExtract,
            "STATE_ELEVATION_CANCELLED" => Self::ElevationCancelled,
            "STATE_ELEVATION_FAILED" => Self::ElevationFailed,
            "STATE_ELEVATION_ALIAS_DISABLED" => Self::ElevationDisabled,
            "STATE_INSTALLER_MISSING" => Self::InstallerMissing,
            "STATE_INSTALLER_NO_CHECKSUM" => Self::InstallerNoChecksum,
            "STATE_INSTALL_LOCATION_UNAVAILABLE" => Self::InstallLocationUnavailable,
            "STATE_INSTALL_PATH_TOO_LONG" => Self::InstallPathTooLong,
            "STATE_INSUFFICIENT_PERMISSIONS" => Self::InsufficientPermissions,
            "STATE_NEEDS_ELEVATION" => Self::NeedsElevation,
            "STATE_TIMEOUT" => Self::Timeout,
            "STATE_VISUAL_STUDIO_BUSY" => Self::VisualStudioBusy,
            "STATE_VISUAL_STUDIO_DOWNLOAD_FAILED" => Self::VisualStudioDownloadFailed,
            "STATE_VISUAL_STUDIO_FAILED" => Self::VisualStudioFailed,
            "STATE_VISUAL_STUDIO_UNSUPPORTED_SYSTEM" => Self::VisualStudioUnsupportedSystem,
            "STATE_WAITING_FOR_ANOTHER_INSTALLER" => Self::WaitingForAnotherInstaller,
            _ => return None,
        };
        Some(state)
    }
}

/// Installation phase of a Hub install, keyed by the `PLUGINS_PHASE_*` / phase keys.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum InstallPhase {
    Preparing,
    CheckingRuntime,
    Downloading,
    DownloadingUnknown,
    Extracting,
    Finishing,
    InstallingRuntime,
    Removing,
    Verifying,
    BuildingRuntimeEnvironment,
}

impl InstallPhase {
    pub fn as_key(self) -> &'static str {
        match self {
            Self::Preparing => "PLUGINS_PHASE_PREPARING",
            Self::CheckingRuntime => "PLUGINS_PHASE_CHECKING_RUNTIME",
            Self::Downloading => "PLUGINS_PHASE_DOWNLOADING",
            Self::DownloadingUnknown => "PLUGINS_PHASE_DOWNLOADING_UNKNOWN",
            Self::Extracting => "PLUGINS_PHASE_EXTRACTING",
            Self::Finishing => "PLUGINS_PHASE_FINISHING",
            Self::InstallingRuntime => "PLUGINS_PHASE_INSTALLING_RUNTIME",
            Self::Removing => "PLUGINS_PHASE_REMOVING",
            Self::Verifying => "PLUGINS_PHASE_VERIFYING",
            Self::BuildingRuntimeEnvironment => "PLUGINS_PHASE_BUILDING_RUNTIME_ENVIRONMENT",
        }
    }

    pub fn from_key(key: &str) -> Option<Self> {
        let phase = match key {
            "PLUGINS_PHASE_PREPARING" => Self::Preparing,
            "PLUGINS_PHASE_CHECKING_RUNTIME" => Self::CheckingRuntime,
            "PLUGINS_PHASE_DOWNLOADING" => Self::Downloading,
            "PLUGINS_PHASE_DOWNLOADING_UNKNOWN" => Self::DownloadingUnknown,
            "PLUGINS_PHASE_EXTRACTING" => Self::Extracting,
            "PLUGINS_PHASE_FINISHING" => Self::Finishing,
            "PLUGINS_PHASE_INSTALLING_RUNTIME" => Self::InstallingRuntime,
            "PLUGINS_PHASE_REMOVING" => Self::Removing,
            "PLUGINS_PHASE_VERIFYING" => Self::Verifying,
            "PLUGINS_PHASE_BUILDING_RUNTIME_ENVIRONMENT" => Self::BuildingRuntimeEnvironment,
            _ => return None,
        };
        Some(phase)
    }
}

/// A Unity version offered by the version definitions (release channels, builds).
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct EditorVersion {
    pub version: String,
    pub release_type: ReleaseType,
    pub download_url: Option<String>,
    pub size: Option<u64>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, PartialOrd, Ord)]
pub enum ReleaseType {
    /// Long Term Support release.
    Lts,
    /// Latest stable release.
    Stable,
    /// Pre-release (alpha / beta / preview) build.
    PreRelease,
}

impl EditorVersion {
    pub fn is_lts(&self) -> bool {
        self.release_type == ReleaseType::Lts
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn install_state_keys_round_trip() {
        for state in [
            InstallState::Queued,
            InstallState::Complete,
            InstallState::Cancelled,
            InstallState::Failed,
            InstallState::CouldNotExtract,
            InstallState::ElevationCancelled,
            InstallState::ElevationFailed,
            InstallState::ElevationDisabled,
            InstallState::InstallerMissing,
            InstallState::InstallerNoChecksum,
            InstallState::InstallLocationUnavailable,
            InstallState::InstallPathTooLong,
            InstallState::InsufficientPermissions,
            InstallState::NeedsElevation,
            InstallState::Timeout,
            InstallState::VisualStudioBusy,
            InstallState::VisualStudioDownloadFailed,
            InstallState::VisualStudioFailed,
            InstallState::VisualStudioUnsupportedSystem,
            InstallState::WaitingForAnotherInstaller,
        ] {
            assert_eq!(InstallState::from_key(state.as_key()), Some(state));
        }
    }

    #[test]
    fn install_phase_keys_round_trip() {
        for phase in [
            InstallPhase::Preparing,
            InstallPhase::CheckingRuntime,
            InstallPhase::Downloading,
            InstallPhase::DownloadingUnknown,
            InstallPhase::Extracting,
            InstallPhase::Finishing,
            InstallPhase::InstallingRuntime,
            InstallPhase::Removing,
            InstallPhase::Verifying,
            InstallPhase::BuildingRuntimeEnvironment,
        ] {
            assert_eq!(InstallPhase::from_key(phase.as_key()), Some(phase));
        }
    }
}

impl fmt::Display for EditorVersion {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.version)
    }
}
