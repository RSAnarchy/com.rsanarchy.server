//! Read/write helpers for Hub 3.22 `install-state/install-state.db` (schema verified from real Hub data).

use crate::error::Result;
use rusqlite::{params, Connection, OpenFlags};
use serde_json::Value;
use std::path::Path;

pub fn db_path(data_dir: &Path) -> std::path::PathBuf {
    data_dir.join("install-state").join("install-state.db")
}

pub fn open_rw(data_dir: &Path) -> Result<Connection> {
    let path = db_path(data_dir);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let conn = Connection::open(&path).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    init_schema(&conn)?;
    Ok(conn)
}

pub fn open_ro(data_dir: &Path) -> Result<Option<Connection>> {
    let path = db_path(data_dir);
    if !path.exists() {
        return Ok(None);
    }
    let conn = Connection::open_with_flags(&path, OpenFlags::SQLITE_OPEN_READ_ONLY)
        .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(Some(conn))
}

pub fn init_schema(conn: &Connection) -> Result<()> {
    conn.execute_batch(
        r#"
CREATE TABLE IF NOT EXISTS downloads (
  uid          TEXT PRIMARY KEY,
  version      TEXT NOT NULL,
  arch         TEXT,
  modules_json TEXT NOT NULL DEFAULT '[]',
  state        TEXT NOT NULL CHECK(state IN ('queued','downloading','complete','failed','cancelled')),
  bytes_total  INTEGER NOT NULL DEFAULT 0,
  bytes_done   INTEGER NOT NULL DEFAULT 0,
  pid          INTEGER,
  started_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  error_code   TEXT,
  error_msg    TEXT
);
CREATE INDEX IF NOT EXISTS downloads_state_idx ON downloads(state);
CREATE TABLE IF NOT EXISTS installs (
  rowid        INTEGER PRIMARY KEY CHECK(rowid = 1),
  uid          TEXT NOT NULL,
  version      TEXT NOT NULL,
  modules_json TEXT NOT NULL DEFAULT '[]',
  phase        TEXT NOT NULL CHECK(phase IN ('queued','installing')),
  pid          INTEGER NOT NULL,
  started_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS file_claims (
  pid        INTEGER NOT NULL,
  source     TEXT NOT NULL CHECK(source IN ('downloads','installs','reservations')),
  path       TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (pid, source, path)
);
CREATE TABLE IF NOT EXISTS schema_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
"#,
    )
    .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    // ensure schema_meta has at least a marker if empty? not required, but harmless
    let _: i64 = conn
        .query_row("SELECT COUNT(*) FROM schema_meta", [], |r| r.get(0))
        .unwrap_or(0);
    Ok(())
}

pub fn query_table(conn: &Connection, table: &str) -> Result<Vec<Value>> {
    let sql = format!("SELECT * FROM \"{}\"", table.replace('"', "\"\""));
    let mut stmt = conn.prepare(&sql).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let col_count = stmt.column_count();
    let col_names: Vec<String> = stmt.column_names().into_iter().map(|s| s.to_string()).collect();
    let rows_iter = stmt
        .query_map([], |row| {
            let mut obj = serde_json::Map::new();
            for i in 0..col_count {
                let name = col_names.get(i).cloned().unwrap_or_else(|| i.to_string());
                let v: Value = match row.get_ref(i)? {
                    rusqlite::types::ValueRef::Null => Value::Null,
                    rusqlite::types::ValueRef::Integer(n) => serde_json::json!(n),
                    rusqlite::types::ValueRef::Real(f) => serde_json::json!(f),
                    rusqlite::types::ValueRef::Text(t) => Value::String(String::from_utf8_lossy(t).to_string()),
                    rusqlite::types::ValueRef::Blob(b) => Value::String(format!("<blob:{}>", b.len())),
                };
                obj.insert(name, v);
            }
            Ok(Value::Object(obj))
        })
        .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let mut rows = Vec::new();
    for r in rows_iter {
        rows.push(r.map_err(|e| crate::error::HubError::Other(e.to_string()))?);
    }
    Ok(rows)
}

pub fn read_table_json(data_dir: &Path, table: &str) -> Result<Value> {
    let path = db_path(data_dir);
    if let Some(conn) = open_ro(data_dir)? {
        let rows = query_table(&conn, table)?;
        Ok(serde_json::json!({"db": path.to_string_lossy(), "exists": true, "table": table, "rows": rows}))
    } else {
        Ok(serde_json::json!({"db": path.to_string_lossy(), "exists": false, "table": table, "rows": []}))
    }
}

pub fn queue_download(
    data_dir: &Path,
    uid: &str,
    version: &str,
    arch: Option<&str>,
    modules_json: &str,
    now_ms: i64,
) -> Result<()> {
    let conn = open_rw(data_dir)?;
    conn.execute(
        "INSERT INTO downloads (uid, version, arch, modules_json, state, bytes_total, bytes_done, pid, started_at, updated_at, error_code, error_msg)
         VALUES (?1, ?2, ?3, ?4, 'queued', 0, 0, NULL, ?5, ?5, NULL, NULL)
         ON CONFLICT(uid) DO UPDATE SET version=excluded.version, arch=excluded.arch, modules_json=excluded.modules_json, state='queued', updated_at=excluded.updated_at, error_code=NULL, error_msg=NULL",
        params![uid, version, arch, modules_json, now_ms],
    ).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(())
}

pub fn set_download_state(
    data_dir: &Path,
    uid: &str,
    state: &str,
    bytes_done: Option<i64>,
    bytes_total: Option<i64>,
    error_code: Option<&str>,
    error_msg: Option<&str>,
    now_ms: i64,
) -> Result<bool> {
    let conn = open_rw(data_dir)?;
    let changed = conn.execute(
        "UPDATE downloads SET state=?2, bytes_done=COALESCE(?3, bytes_done), bytes_total=COALESCE(?4, bytes_total), error_code=?5, error_msg=?6, updated_at=?7 WHERE uid=?1",
        params![uid, state, bytes_done, bytes_total, error_code, error_msg, now_ms],
    ).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(changed > 0)
}

pub fn cancel_download(data_dir: &Path, uid: &str, now_ms: i64) -> Result<bool> {
    set_download_state(data_dir, uid, "cancelled", None, None, None, None, now_ms)
}

pub fn queue_install(data_dir: &Path, uid: &str, version: &str, modules_json: &str, pid: i64, now_ms: i64) -> Result<()> {
    let conn = open_rw(data_dir)?;
    conn.execute(
        "INSERT INTO installs (rowid, uid, version, modules_json, phase, pid, started_at, updated_at)
         VALUES (1, ?1, ?2, ?3, 'queued', ?4, ?5, ?5)
         ON CONFLICT(rowid) DO UPDATE SET uid=excluded.uid, version=excluded.version, modules_json=excluded.modules_json, phase='queued', pid=excluded.pid, updated_at=excluded.updated_at",
        params![uid, version, modules_json, pid, now_ms],
    ).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(())
}

pub fn clear_install(data_dir: &Path) -> Result<bool> {
    let conn = open_rw(data_dir)?;
    let changed = conn.execute("DELETE FROM installs WHERE rowid=1", []).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(changed > 0)
}

pub fn set_install_phase(data_dir: &Path, phase: &str, now_ms: i64) -> Result<bool> {
    let conn = open_rw(data_dir)?;
    let changed = conn.execute(
        "UPDATE installs SET phase=?1, updated_at=?2 WHERE rowid=1",
        params![phase, now_ms],
    ).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(changed > 0)
}

pub fn upsert_file_claim(data_dir: &Path, pid: i64, source: &str, path: &str, updated_at: i64) -> Result<()> {
    let conn = open_rw(data_dir)?;
    conn.execute(
        "INSERT INTO file_claims (pid, source, path, updated_at)
         VALUES (?1, ?2, ?3, ?4)
         ON CONFLICT(pid, source, path) DO UPDATE SET updated_at=excluded.updated_at",
        params![pid, source, path, updated_at],
    ).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(())
}

pub fn remove_file_claim(data_dir: &Path, pid: i64, source: &str, path: &str) -> Result<bool> {
    let conn = open_rw(data_dir)?;
    let changed = conn.execute(
        "DELETE FROM file_claims WHERE pid=?1 AND source=?2 AND path=?3",
        params![pid, source, path],
    ).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(changed > 0)
}

pub fn clear_file_claims(data_dir: &Path) -> Result<usize> {
    let conn = open_rw(data_dir)?;
    let changed = conn.execute("DELETE FROM file_claims", []).map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    Ok(changed)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn temp_dir(label: &str) -> std::path::PathBuf {
        let dir = std::env::temp_dir().join(format!("uh-is-{}-{}-{}", label, std::process::id(), std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }
    #[test]
    fn queue_and_transition_download() {
        let dir = temp_dir("dl");
        queue_download(&dir, "u1", "6000.0.23f1", Some("x86_64"), "[]", 1000).unwrap();
        set_download_state(&dir, "u1", "downloading", Some(50), Some(100), None, None, 1100).unwrap();
        let v = read_table_json(&dir, "downloads").unwrap();
        let rows = v["rows"].as_array().unwrap();
        assert_eq!(rows.len(), 1);
        assert_eq!(rows[0]["state"], "downloading");
        assert_eq!(rows[0]["bytes_done"], 50);
        cancel_download(&dir, "u1", 1200).unwrap();
        let v2 = read_table_json(&dir, "downloads").unwrap();
        assert_eq!(v2["rows"][0]["state"], "cancelled");
        let _ = std::fs::remove_dir_all(&dir);
    }
    #[test]
    fn queue_and_clear_install() {
        let dir = temp_dir("in");
        queue_install(&dir, "u2", "6000.0.23f1", "[]", 1234, 1000).unwrap();
        let v = read_table_json(&dir, "installs").unwrap();
        assert_eq!(v["rows"].as_array().unwrap().len(), 1);
        assert_eq!(v["rows"][0]["phase"], "queued");
        assert!(set_install_phase(&dir, "installing", 1100).unwrap());
        let v1 = read_table_json(&dir, "installs").unwrap();
        assert_eq!(v1["rows"][0]["phase"], "installing");
        assert!(clear_install(&dir).unwrap());
        let v2 = read_table_json(&dir, "installs").unwrap();
        assert_eq!(v2["rows"].as_array().unwrap().len(), 0);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn file_claims_round_trip() {
        let dir = temp_dir("fc");
        upsert_file_claim(&dir, 123, "downloads", "C:\\temp\\a.zip", 1000).unwrap();
        upsert_file_claim(&dir, 123, "downloads", "C:\\temp\\a.zip", 2000).unwrap();
        upsert_file_claim(&dir, 123, "installs", "C:\\Unity\\6000", 2000).unwrap();
        let v = read_table_json(&dir, "file_claims").unwrap();
        assert_eq!(v["rows"].as_array().unwrap().len(), 2);
        assert!(remove_file_claim(&dir, 123, "downloads", "C:\\temp\\a.zip").unwrap());
        let v2 = read_table_json(&dir, "file_claims").unwrap();
        assert_eq!(v2["rows"].as_array().unwrap().len(), 1);
        assert_eq!(clear_file_claims(&dir).unwrap(), 1);
        let v3 = read_table_json(&dir, "file_claims").unwrap();
        assert_eq!(v3["rows"].as_array().unwrap().len(), 0);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
