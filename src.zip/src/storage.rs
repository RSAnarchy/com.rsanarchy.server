//! Local storage (SQLite) mirroring the Hub's project and install databases.

use crate::error::{HubError, Result};
use rusqlite::Connection;
use std::path::Path;

/// Open (or create) a Hub storage database at `path`.
pub fn open(path: &Path) -> Result<Connection> {
    let conn = Connection::open(path).map_err(|e| {
        HubError::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string()))
    })?;
    conn.execute_batch("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;")
        .map_err(|e| HubError::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))?;
    Ok(conn)
}

/// Initialize the schema for projects/installs (minimal parity stub).
pub fn init_schema(conn: &Connection) -> Result<()> {
    conn.execute_batch(
        "CREATE TABLE IF NOT EXISTS projects(
            path TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            editor_version TEXT,
            is_favorite INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS installs(
            version TEXT PRIMARY KEY,
            install_path TEXT NOT NULL,
            install_root TEXT NOT NULL
        );",
    )
    .map_err(|e| HubError::Io(std::io::Error::new(std::io::ErrorKind::Other, e.to_string())))?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn opens_and_initializes_in_memory_database() {
        let conn = Connection::open_in_memory().unwrap();
        init_schema(&conn).unwrap();
        conn.execute(
            "INSERT INTO projects(path,name,editor_version,is_favorite) VALUES (?1,?2,?3,?4)",
            rusqlite::params!["C:/p", "P", "6000.1.3f1", 0],
        )
        .unwrap();
        let count: i64 = conn
            .query_row("SELECT COUNT(*) FROM projects", [], |r| r.get(0))
            .unwrap();
        assert_eq!(count, 1);
    }
}
