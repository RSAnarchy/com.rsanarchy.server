//! Hub data registries (3.x/4.x-compatible `projects-v1.json`, `editors-v2.json`).

use crate::error::Result;
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectsRegistry {
    pub schema_version: String,
    pub data: BTreeMap<String, ProjectRecord>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct ProjectRecord {
    pub title: Option<String>,
    pub path: String,
    #[serde(rename = "containingFolderPath")]
    pub containing_folder_path: Option<String>,
    pub version: Option<String>,
    pub architecture: Option<String>,
    pub changeset: Option<String>,
    #[serde(rename = "isFavorite")]
    pub is_favorite: Option<bool>,
    #[serde(rename = "isCustomEditor")]
    pub is_custom_editor: Option<bool>,
    #[serde(rename = "localProjectId")]
    pub local_project_id: Option<String>,
    #[serde(rename = "cloudProjectId")]
    pub cloud_project_id: Option<String>,
    #[serde(rename = "lastModified")]
    pub last_modified: Option<Value>,
    #[serde(flatten)]
    pub extra: BTreeMap<String, Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EditorsRegistry {
    pub schema_version: String,
    pub data: Vec<Value>,
}

impl Default for ProjectsRegistry {
    fn default() -> Self {
        Self {
            schema_version: "v1".to_string(),
            data: BTreeMap::new(),
        }
    }
}

impl Default for EditorsRegistry {
    fn default() -> Self {
        Self {
            schema_version: "2".to_string(),
            data: Vec::new(),
        }
    }
}

pub fn hub_data_dir() -> PathBuf {
    if let Ok(dir) = std::env::var("UNITY_HUB_DATA_DIR") {
        if !dir.is_empty() {
            return PathBuf::from(dir);
        }
    }
    #[cfg(target_os = "windows")]
    {
        if let Some(appdata) = std::env::var_os("APPDATA") {
            return PathBuf::from(appdata).join("UnityHub");
        }
    }
    #[cfg(not(target_os = "windows"))]
    {
        if let Some(home) = std::env::var_os("HOME") {
            return PathBuf::from(home).join(".config").join("UnityHub");
        }
    }
    PathBuf::from("UnityHub")
}

fn strip_bom(s: &str) -> &str {
    s.strip_prefix('\u{feff}').unwrap_or(s)
}

pub fn load_projects_registry(path: &Path) -> Result<ProjectsRegistry> {
    if !path.exists() {
        return Ok(ProjectsRegistry::default());
    }
    let content = std::fs::read_to_string(path)?;
    Ok(serde_json::from_str(strip_bom(&content))?)
}

pub fn save_projects_registry(path: &Path, reg: &ProjectsRegistry) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let content = serde_json::to_string(reg)?;
    std::fs::write(path, content)?;
    Ok(())
}

pub fn load_editors_registry(path: &Path) -> Result<EditorsRegistry> {
    if !path.exists() {
        return Ok(EditorsRegistry::default());
    }
    let content = std::fs::read_to_string(path)?;
    Ok(serde_json::from_str(strip_bom(&content))?)
}

pub fn save_editors_registry(path: &Path, reg: &EditorsRegistry) -> Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let content = serde_json::to_string(reg)?;
    std::fs::write(path, content)?;
    Ok(())
}

/// Upsert a minimal project record (porting LocalProjectService add/update behavior).
/// Preserves existing fields (favorites, cloud ids, extra metadata) when updating.
pub fn upsert_project(reg: &mut ProjectsRegistry, path: &str, title: &str, version: Option<String>) {
    let record = reg.data.entry(path.to_string()).or_insert_with(|| ProjectRecord {
        path: path.to_string(),
        title: Some(title.to_string()),
        ..Default::default()
    });
    record.path = path.to_string();
    record.title = Some(title.to_string());
    if record.containing_folder_path.is_none() {
        if let Some(parent) = Path::new(path).parent() {
            record.containing_folder_path = Some(parent.to_string_lossy().to_string());
        }
    }
    if version.is_some() {
        record.version = version;
    }
}

/// Upsert an editor entry in editors-v2 registry (by location, fallback version).
pub fn upsert_editor(reg: &mut EditorsRegistry, version: &str, location: &str, manual: bool) -> bool {
    upsert_editor_with_extra(reg, version, location, manual, None)
}

/// Upsert editor entry with optional extra fields merged into the record.
pub fn upsert_editor_with_extra(
    reg: &mut EditorsRegistry,
    version: &str,
    location: &str,
    manual: bool,
    extra: Option<&serde_json::Map<String, Value>>,
) -> bool {
    let norm_loc = location.trim_end_matches(['\\', '/']).to_string();
    for e in &mut reg.data {
        let existing_loc = e
            .get("location")
            .or_else(|| e.get("path"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .trim_end_matches(['\\', '/']);
        let existing_ver = e.get("version").and_then(|v| v.as_str()).unwrap_or("");
        if (!norm_loc.is_empty() && existing_loc.eq_ignore_ascii_case(&norm_loc))
            || (norm_loc.is_empty() && !existing_ver.is_empty() && existing_ver == version)
        {
            if let Some(obj) = e.as_object_mut() {
                obj.insert("version".to_string(), Value::String(version.to_string()));
                obj.insert("location".to_string(), Value::String(location.to_string()));
                obj.insert("manual".to_string(), Value::Bool(manual));
                if let Some(extra) = extra {
                    for (k, v) in extra {
                        obj.insert(k.clone(), v.clone());
                    }
                }
            }
            return false;
        }
    }
    let mut obj = serde_json::Map::new();
    obj.insert("version".to_string(), Value::String(version.to_string()));
    obj.insert("location".to_string(), Value::String(location.to_string()));
    obj.insert("manual".to_string(), Value::Bool(manual));
    if let Some(extra) = extra {
        for (k, v) in extra {
            obj.insert(k.clone(), v.clone());
        }
    }
    reg.data.push(Value::Object(obj));
    true
}

/// Set manual flag on matching editor entries. Returns number updated.
pub fn set_editor_manual(reg: &mut EditorsRegistry, matcher: &str, manual: bool) -> usize {
    let needle = matcher.trim_end_matches(['\\', '/']).to_ascii_lowercase();
    let mut count = 0usize;
    for e in &mut reg.data {
        let loc = e
            .get("location")
            .or_else(|| e.get("path"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .trim_end_matches(['\\', '/'])
            .to_ascii_lowercase();
        let ver = e.get("version").and_then(|v| v.as_str()).unwrap_or("").to_ascii_lowercase();
        if loc == needle || ver == needle || e.get("version").and_then(|v| v.as_str()).unwrap_or("") == matcher {
            if let Some(obj) = e.as_object_mut() {
                obj.insert("manual".to_string(), Value::Bool(manual));
                count += 1;
            }
        }
    }
    count
}

/// Sync scanned editor installs into editors-v2 registry. Returns (added, updated).
pub fn sync_editors_from_scan(reg: &mut EditorsRegistry, installs: &[crate::models::EditorInstall]) -> (usize, usize) {
    let mut added = 0usize;
    let mut updated = 0usize;
    for inst in installs {
        if upsert_editor(reg, &inst.version, &inst.install_path, false) {
            added += 1;
        } else {
            updated += 1;
        }
    }
    (added, updated)
}

/// Sync discovered projects into projects-v1 registry. Returns number of upserted records.
pub fn sync_projects_from_scan(reg: &mut ProjectsRegistry, projects: &[crate::models::ProjectEntry]) -> usize {
    for p in projects {
        upsert_project(reg, &p.path, &p.name, p.editor_version.clone());
    }
    projects.len()
}

/// Remove a project from the registry by exact key/path. Returns true if removed.
pub fn remove_project(reg: &mut ProjectsRegistry, path: &str) -> bool {
    reg.data.remove(path).is_some()
}

/// Set or update a project's favorite flag. Returns true if project exists.
pub fn set_project_favorite(reg: &mut ProjectsRegistry, path: &str, is_favorite: bool) -> bool {
    if let Some(rec) = reg.data.get_mut(path) {
        rec.is_favorite = Some(is_favorite);
        true
    } else {
        false
    }
}

/// Update a project's lastModified timestamp (milliseconds since epoch). Returns true if project exists.
pub fn touch_project_last_modified(reg: &mut ProjectsRegistry, path: &str, last_modified_ms: i64) -> bool {
    if let Some(rec) = reg.data.get_mut(path) {
        rec.last_modified = Some(Value::Number(serde_json::Number::from(last_modified_ms)));
        true
    } else {
        false
    }
}

/// Set tags for a project (arbitrary JSON value, typically array).
pub fn set_project_tags(reg: &mut ProjectsRegistry, project_path: &str, tags: Value) -> bool {
    if let Some(rec) = reg.data.get_mut(project_path) {
        rec.extra.insert("tags".to_string(), tags);
        true
    } else {
        false
    }
}

/// Delete given tag values from all projects' `tags` arrays. Returns number of projects changed.
pub fn delete_project_tags(reg: &mut ProjectsRegistry, tags_to_remove: &[String]) -> usize {
    if tags_to_remove.is_empty() {
        return 0;
    }
    let remove: std::collections::BTreeSet<String> = tags_to_remove.iter().cloned().collect();
    let mut changed = 0usize;
    for rec in reg.data.values_mut() {
        if let Some(tags_val) = rec.extra.get_mut("tags") {
            if let Some(arr) = tags_val.as_array() {
                let filtered: Vec<Value> = arr
                    .iter()
                    .filter(|v| v.as_str().map(|s| !remove.contains(s)).unwrap_or(true))
                    .cloned()
                    .collect();
                if filtered.len() != arr.len() {
                    *tags_val = Value::Array(filtered);
                    changed += 1;
                }
            }
        }
    }
    changed
}

/// Clear project deeplink/open-in-editor info fields. Returns true if project exists.
pub fn clear_project_deeplink_info(reg: &mut ProjectsRegistry, project_path: &str) -> bool {
    if let Some(rec) = reg.data.get_mut(project_path) {
        rec.extra.remove("openInEditorUrl");
        true
    } else {
        false
    }
}

/// Remove editor entries matching location or version. Returns number removed.
pub fn remove_editor(reg: &mut EditorsRegistry, matcher: &str) -> usize {
    let needle = matcher.trim_end_matches(['\\', '/']).to_ascii_lowercase();
    let before = reg.data.len();
    reg.data.retain(|e| {
        let loc = e
            .get("location")
            .or_else(|| e.get("path"))
            .and_then(|v| v.as_str())
            .unwrap_or("")
            .trim_end_matches(['\\', '/'])
            .to_ascii_lowercase();
        let ver = e.get("version").and_then(|v| v.as_str()).unwrap_or("").to_ascii_lowercase();
        !(loc == needle || ver == needle || e.get("version").and_then(|v| v.as_str()).unwrap_or("") == matcher)
    });
    before - reg.data.len()
}

pub fn now_millis() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis() as i64
}

/// Return projects sorted by lastModified descending (recent projects view).
pub fn recent_projects(reg: &ProjectsRegistry) -> Vec<(&String, &ProjectRecord)> {
    let mut items: Vec<(&String, &ProjectRecord)> = reg.data.iter().collect();
    items.sort_by(|a, b| {
        let am = a.1.last_modified.as_ref().and_then(|v| v.as_i64().or_else(|| v.as_f64().map(|f| f as i64))).unwrap_or(0);
        let bm = b.1.last_modified.as_ref().and_then(|v| v.as_i64().or_else(|| v.as_f64().map(|f| f as i64))).unwrap_or(0);
        bm.cmp(&am).then_with(|| a.0.cmp(b.0))
    });
    items
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trips_projects_registry() {
        let dir = std::env::temp_dir().join(format!("uh-reg-{}-{}", std::process::id(), std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("projects-v1.json");
        let mut reg = ProjectsRegistry::default();
        upsert_project(&mut reg, "C:/Projects/A", "A", Some("6000.1.3f1".to_string()));
        save_projects_registry(&path, &reg).unwrap();
        let loaded = load_projects_registry(&path).unwrap();
        assert_eq!(loaded.schema_version, "v1");
        assert_eq!(loaded.data.get("C:/Projects/A").and_then(|r| r.version.as_deref()), Some("6000.1.3f1"));
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn upsert_preserves_existing_fields() {
        let mut reg = ProjectsRegistry::default();
        upsert_project(&mut reg, "C:/P", "P", Some("1.0.0".to_string()));
        if let Some(r) = reg.data.get_mut("C:/P") {
            r.extra.insert("custom".to_string(), serde_json::json!("keep"));
            r.is_favorite = Some(true);
        }
        upsert_project(&mut reg, "C:/P", "P2", Some("2.0.0".to_string()));
        let r = reg.data.get("C:/P").unwrap();
        assert_eq!(r.title.as_deref(), Some("P2"));
        assert_eq!(r.version.as_deref(), Some("2.0.0"));
        assert_eq!(r.is_favorite, Some(true));
        assert_eq!(r.extra.get("custom"), Some(&serde_json::json!("keep")));
    }

    #[test]
    fn round_trips_editors_registry() {
        let dir = std::env::temp_dir().join(format!("uh-reg-e-{}-{}", std::process::id(), std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("editors-v2.json");
        let mut reg = EditorsRegistry::default();
        reg.data.push(serde_json::json!({"version":"6000.1.3f1","location":"C:/Unity/6000.1.3f1"}));
        save_editors_registry(&path, &reg).unwrap();
        let loaded = load_editors_registry(&path).unwrap();
        assert_eq!(loaded.schema_version, "2");
        assert_eq!(loaded.data.len(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn upsert_editor_dedupes_by_location() {
        let mut reg = EditorsRegistry::default();
        assert!(upsert_editor(&mut reg, "2022.3.15f1", "C:/Unity/2022.3.15f1", true));
        assert!(!upsert_editor(&mut reg, "2022.3.15f1", "C:/Unity/2022.3.15f1/", true));
        assert_eq!(reg.data.len(), 1);
        assert_eq!(reg.data[0].get("version").and_then(|v| v.as_str()), Some("2022.3.15f1"));
    }

    #[test]
    fn sync_helpers_merge_scans() {
        let mut ereg = EditorsRegistry::default();
        let installs = vec![
            crate::models::EditorInstall { version: "6000.0.23f1".to_string(), install_name: "6000.0.23f1".to_string(), install_path: "C:/U/6000.0.23f1".to_string(), install_root: "C:/U".to_string(), is_64_bit: true, size_on_disk: 0 },
            crate::models::EditorInstall { version: "2022.3.15f1".to_string(), install_name: "2022.3.15f1".to_string(), install_path: "C:/U/2022.3.15f1".to_string(), install_root: "C:/U".to_string(), is_64_bit: true, size_on_disk: 0 },
        ];
        let (added, updated) = sync_editors_from_scan(&mut ereg, &installs);
        assert_eq!((added, updated), (2, 0));
        let (added2, updated2) = sync_editors_from_scan(&mut ereg, &installs);
        assert_eq!((added2, updated2), (0, 2));
        assert_eq!(ereg.data.len(), 2);

        let mut preg = ProjectsRegistry::default();
        upsert_project(&mut preg, "C:/P1", "Old", Some("1".into()));
        if let Some(r) = preg.data.get_mut("C:/P1") { r.is_favorite = Some(true); }
        let projects = vec![
            crate::models::ProjectEntry { name: "P1".to_string(), path: "C:/P1".to_string(), editor_version: Some("2".into()), is_favorite: false, is_offline: false },
            crate::models::ProjectEntry { name: "P2".to_string(), path: "C:/P2".to_string(), editor_version: Some("3".into()), is_favorite: false, is_offline: false },
        ];
        let n = sync_projects_from_scan(&mut preg, &projects);
        assert_eq!(n, 2);
        assert_eq!(preg.data.len(), 2);
        assert_eq!(preg.data["C:/P1"].version.as_deref(), Some("2"));
        assert_eq!(preg.data["C:/P1"].is_favorite, Some(true));
    }

    #[test]
    fn project_remove_favorite_touch_and_editor_remove() {
        let mut preg = ProjectsRegistry::default();
        upsert_project(&mut preg, "C:/P1", "P1", Some("6000.0.1f1".into()));
        assert!(set_project_favorite(&mut preg, "C:/P1", true));
        assert_eq!(preg.data["C:/P1"].is_favorite, Some(true));
        assert!(touch_project_last_modified(&mut preg, "C:/P1", 1234567890));
        assert_eq!(preg.data["C:/P1"].last_modified.as_ref().and_then(|v| v.as_i64()), Some(1234567890));
        assert!(remove_project(&mut preg, "C:/P1"));
        assert!(!preg.data.contains_key("C:/P1"));
        assert!(!remove_project(&mut preg, "C:/P1"));

        let mut ereg = EditorsRegistry::default();
        upsert_editor(&mut ereg, "2022.3.15f1", "C:/Unity/2022.3.15f1", true);
        upsert_editor(&mut ereg, "6000.0.23f1", "C:/Unity/6000.0.23f1", false);
        assert_eq!(remove_editor(&mut ereg, "2022.3.15f1"), 1);
        assert_eq!(ereg.data.len(), 1);
        assert_eq!(remove_editor(&mut ereg, "C:/Unity/6000.0.23f1"), 1);
        assert!(ereg.data.is_empty());
    }

    #[test]
    fn recent_projects_sorted_by_last_modified_desc() {
        let mut preg = ProjectsRegistry::default();
        upsert_project(&mut preg, "C:/A", "A", None);
        upsert_project(&mut preg, "C:/B", "B", None);
        upsert_project(&mut preg, "C:/C", "C", None);
        touch_project_last_modified(&mut preg, "C:/A", 100);
        touch_project_last_modified(&mut preg, "C:/B", 300);
        touch_project_last_modified(&mut preg, "C:/C", 200);
        let recents = recent_projects(&preg);
        let keys: Vec<String> = recents.into_iter().map(|(k, _)| k.clone()).collect();
        assert_eq!(keys, vec!["C:/B".to_string(), "C:/C".to_string(), "C:/A".to_string()]);
    }

    #[test]
    fn set_editor_manual_updates_matching_entries() {
        let mut ereg = EditorsRegistry::default();
        upsert_editor(&mut ereg, "6000.0.23f1", "C:/Unity/6000.0.23f1", false);
        assert_eq!(set_editor_manual(&mut ereg, "6000.0.23f1", true), 1);
        assert_eq!(ereg.data[0].get("manual").and_then(|v| v.as_bool()), Some(true));
        assert_eq!(set_editor_manual(&mut ereg, "C:/Unity/6000.0.23f1", false), 1);
        assert_eq!(ereg.data[0].get("manual").and_then(|v| v.as_bool()), Some(false));
    }
}
