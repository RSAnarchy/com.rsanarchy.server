//! Generic read/write access to Unity Hub data directory storage files (3.22-compatible JSON/text files).

use crate::error::{HubError, Result};
use serde_json::Value;
use std::path::{Path, PathBuf};

pub fn file_path(data_dir: &Path, file_name: &str) -> PathBuf {
    data_dir.join(file_name)
}

pub fn list_files(data_dir: &Path) -> Result<Vec<String>> {
    if !data_dir.exists() {
        return Ok(Vec::new());
    }
    let mut names = Vec::new();
    for entry in std::fs::read_dir(data_dir)? {
        let entry = entry?;
        let path = entry.path();
        if path.is_file() {
            if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
                names.push(name.to_string());
            }
        }
    }
    names.sort();
    Ok(names)
}

pub fn read_raw(data_dir: &Path, file_name: &str) -> Result<String> {
    let path = file_path(data_dir, file_name);
    Ok(std::fs::read_to_string(path)?)
}

pub fn write_raw(data_dir: &Path, file_name: &str, content: &str) -> Result<()> {
    if file_name.contains("..") || file_name.contains('/') || file_name.contains('\\') {
        return Err(HubError::Other(format!("invalid storage file name: {file_name}")));
    }
    let path = file_path(data_dir, file_name);
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::write(path, content)?;
    Ok(())
}

pub fn read_json(data_dir: &Path, file_name: &str) -> Result<Value> {
    let content = read_raw(data_dir, file_name)?;
    let content = content.strip_prefix('\u{feff}').unwrap_or(&content);
    Ok(serde_json::from_str(content)?)
}

pub fn write_json(data_dir: &Path, file_name: &str, value: &Value) -> Result<()> {
    let content = serde_json::to_string(value)?;
    write_raw(data_dir, file_name, &content)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_dir(label: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "uh-storage-{}-{}-{}",
            label,
            std::process::id(),
            std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn round_trips_json_and_lists_files() {
        let dir = temp_dir("rt");
        let v = serde_json::json!({"schema_version":"1","data":[]});
        write_json(&dir, "excludedEditorFolders.json", &v).unwrap();
        write_raw(&dir, "hideHubOnEditorOpen.json", "false").unwrap();
        let read_back = read_json(&dir, "excludedEditorFolders.json").unwrap();
        assert_eq!(read_back, v);
        let files = list_files(&dir).unwrap();
        assert!(files.contains(&"excludedEditorFolders.json".to_string()));
        assert!(files.contains(&"hideHubOnEditorOpen.json".to_string()));
        let _ = std::fs::remove_dir_all(&dir);
    }
}
