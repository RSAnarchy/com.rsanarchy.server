//! Analysis of the extracted Unity Hub 3.22.6 Electron app bundle (asar).

use std::collections::BTreeSet;
use std::path::Path;

#[derive(Debug, Clone, Default)]
pub struct AppInventory {
    pub total_files: usize,
    pub build_modules: Vec<String>,
    pub services: Vec<String>,
    pub managers: Vec<String>,
    pub renderer_files: Vec<String>,
    pub entrypoints: Vec<String>,
}

/// Load inventory from the extracted app directory.
pub fn load(extracted_root: &Path) -> std::io::Result<AppInventory> {
    let mut build_modules = Vec::new();
    let mut services_set = BTreeSet::new();
    let mut managers_set = BTreeSet::new();
    let mut renderer_files = Vec::new();
    let mut entrypoints = Vec::new();

    fn walk(dir: &Path, base: &Path, out: &mut Vec<String>) -> std::io::Result<()> {
        for entry in std::fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();
            if path.is_dir() {
                walk(&path, base, out)?;
            } else {
                let rel = path
                    .strip_prefix(base)
                    .unwrap_or(&path)
                    .to_string_lossy()
                    .replace('\\', "/");
                out.push(rel);
            }
        }
        Ok(())
    }

    let mut all = Vec::new();
    if extracted_root.exists() {
        walk(extracted_root, extracted_root, &mut all)?;
    }
    all.sort();
    let total_files = all.len();

    for rel in &all {
        if rel.starts_with(".vite/build/") {
            let name = rel.trim_start_matches(".vite/build/");
            build_modules.push(name.to_string());
            let lower = name.to_ascii_lowercase();
            if lower.contains("service") {
                // normalize to a readable service domain name
                if let Some(base) = name.split('-').next() {
                    services_set.insert(base.to_string());
                }
            }
            if lower.contains("manager") {
                if let Some(base) = name.split('-').next() {
                    managers_set.insert(base.to_string());
                }
            }
            if name == "index.js" || name.starts_with("main") || name.contains("bootstrap") || name.contains("Preload") {
                entrypoints.push(name.to_string());
            }
        } else if rel.starts_with(".vite/renderer/") {
            renderer_files.push(rel.clone());
        }
    }

    let services = services_set.into_iter().collect();
    let managers = managers_set.into_iter().collect();

    Ok(AppInventory {
        total_files,
        build_modules,
        services,
        managers,
        renderer_files,
        entrypoints,
    })
}

/// Known Hub 3.22 functionality domains inferred from the Electron bundle.
pub fn known_domains() -> Vec<&'static str> {
    vec![
        "Editor inventory/management (install, locate, modules, releases)",
        "Project management (local projects, create/open, templates)",
        "Download & installation management",
        "License & EULA management",
        "Authentication & token management (Unity ID, broker/keyring)",
        "Cloud services & Unity Cloud API",
        "Unity Version Control (UVCS/Plastic) & Git/Perforce integration",
        "Settings/preferences & feature flags",
        "Updates & release feeds (CDN)",
        "Background tasks & notifications",
        "Bug reporter, tray, window management, IPC/protocol handling",
        "Analytics, diagnostics, CLI",
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn loads_extracted_inventory() {
        let root = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("electron-hub-3.22").join("app");
        if !root.exists() {
            return; // skip if not extracted in this environment
        }
        let inv = load(&root).unwrap();
        assert!(inv.total_files > 3000, "expected full extracted app");
        assert!(!inv.build_modules.is_empty());
        assert!(inv.entrypoints.iter().any(|e| e == "index.js"));
        assert!(inv.renderer_files.iter().any(|f| f.contains("main_window")));
        assert!(!inv.services.is_empty());
    }

    #[test]
    fn known_domains_listed() {
        assert!(known_domains().len() >= 10);
    }
}
