﻿//! Command implementations of the rewrite (CLI entry points).

use crate::error::Result;
use crate::installs;
use crate::projects;
use std::path::PathBuf;

/// Handle the `editors` subcommand.
pub fn editors() -> Result<()> {
    let installs = installs::installed_editors()?;
    for install in installs {
        println!("Unity {}", install.version);
    }
    Ok(())
}

/// Handle the `projects` subcommand.
pub fn projects() -> Result<()> {
    let found = projects::discover_projects()?;
    for project in found {
        println!("{}", project.path);
    }
    Ok(())
}

/// Handle the `verify` subcommand: validate parity artifacts against `Old Hub`.
pub fn verify() -> Result<()> {
    let base = std::env::current_dir().unwrap_or_else(|_| std::path::PathBuf::from("."));
    let old_hub = base.join("Old Hub");
    let runtime = base.join("runtime");

    // Checksums manifest
    let checksums = crate::checksums::Checksums::load(&old_hub.join("checksums.json"))?;
    println!("checksums: {} entries", checksums.len());

    // Unity CLI preserved as-is
    let hash = crate::checksums::verify_unity_cli_preserved(&old_hub, &runtime)?;
    println!("unity.exe: preserved (sha512 {hash})");

    // i18n assets
    let i18n = crate::i18n::I18n::load_from_dir(&old_hub.join("assets").join("i18n"))?;
    println!("i18n: {} locales loaded", i18n.locale_count());
    if let Some(en) = i18n.load_locale("en") {
        println!("i18n/en: {} keys", en.len());
    }

    println!("verify: ok");
    Ok(())
}

fn resolve_data_dir(data_dir: Option<&str>) -> std::path::PathBuf {
    if let Some(d) = data_dir {
        return std::path::PathBuf::from(d);
    }
    crate::hub_registry::hub_data_dir()
}

/// List projects from Hub registry (projects-v1.json).
pub fn registry_projects(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let path = dir.join("projects-v1.json");
    let reg = crate::hub_registry::load_projects_registry(&path)?;
    println!("registry: {}", path.display());
    println!("schema_version: {}", reg.schema_version);
    println!("projects: {}", reg.data.len());
    for (key, rec) in &reg.data {
        let title = rec.title.as_deref().unwrap_or("-");
        let version = rec.version.as_deref().unwrap_or("-");
        println!("{key}\t{title}\t{version}");
    }
    Ok(())
}

/// Add/update a project in Hub registry.
pub fn registry_add_project(project_path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;

    let p = std::path::Path::new(project_path);
    let title = p.file_name().and_then(|n| n.to_str()).unwrap_or("Project").to_string();
    let version_file = p.join("ProjectSettings").join("ProjectVersion.txt");
    let version = std::fs::read_to_string(&version_file).ok().and_then(|s| crate::projects::parse_project_version(&s));

    crate::hub_registry::upsert_project(&mut reg, project_path, &title, version.clone());
    crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
    println!("added: {}\t{}\t{}", project_path, title, version.as_deref().unwrap_or("-"));
    println!("registry: {}", reg_path.display());
    Ok(())
}

/// List editors from Hub registry (editors-v2.json).
pub fn registry_editors(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let path = dir.join("editors-v2.json");
    let reg = crate::hub_registry::load_editors_registry(&path)?;
    println!("registry: {}", path.display());
    println!("schema_version: {}", reg.schema_version);
    println!("editors: {}", reg.data.len());
    for e in &reg.data {
        let version = e.get("version").and_then(|v| v.as_str()).unwrap_or("-");
        let location = e.get("location").and_then(|v| v.as_str()).or_else(|| e.get("path").and_then(|v| v.as_str())).unwrap_or("-");
        println!("{version}\t{location}");
    }
    Ok(())
}

/// Add an editor entry to Hub registry (editors-v2.json).
pub fn registry_add_editor(version: &str, location: &str, manual: bool, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("editors-v2.json");
    let mut reg = crate::hub_registry::load_editors_registry(&reg_path)?;
    let added = crate::hub_registry::upsert_editor(&mut reg, version, location, manual);
    crate::hub_registry::save_editors_registry(&reg_path, &reg)?;
    println!("{}: {}\t{}\tmanual={}", if added { "added" } else { "updated" }, version, location, manual);
    println!("registry: {}", reg_path.display());
    Ok(())
}

/// Set manual flag for editor entries matching version or location.
pub fn registry_set_editor_manual(matcher: &str, manual: bool, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("editors-v2.json");
    let mut reg = crate::hub_registry::load_editors_registry(&reg_path)?;
    let updated = crate::hub_registry::set_editor_manual(&mut reg, matcher, manual);
    crate::hub_registry::save_editors_registry(&reg_path, &reg)?;
    println!("updated: {} (matched {}, manual={})", updated, matcher, manual);
    println!("registry: {}", reg_path.display());
    Ok(())
}

/// Get/set Hub project directory preference (`projectDir.json`).
pub fn prefs_project_dir_get(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = crate::hub_storage::read_json(&dir, "projectDir.json")?;
    println!("{}", serde_json::to_string_pretty(&value)?);
    Ok(())
}

pub fn prefs_project_dir_set(directory_path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = serde_json::json!({"directoryPath": directory_path});
    crate::hub_storage::write_json(&dir, "projectDir.json", &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, "projectDir.json").display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

/// Get secondary editor install path preference (`secondaryInstallPath.json`).
pub fn prefs_secondary_install_path_get(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let content = crate::hub_storage::read_raw(&dir, "secondaryInstallPath.json")?;
    println!("{content}");
    Ok(())
}

/// Set secondary editor install path preference (`secondaryInstallPath.json`).
pub fn prefs_secondary_install_path_set(path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    // Hub commonly stores this as a JSON string value (e.g. "" or "D:\\Unity")
    let value = serde_json::Value::String(path.to_string());
    crate::hub_storage::write_json(&dir, "secondaryInstallPath.json", &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, "secondaryInstallPath.json").display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

/// List excluded editor folders (`excludedEditorFolders.json`).
pub fn prefs_excluded_editor_folders_list(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = crate::hub_storage::read_json(&dir, "excludedEditorFolders.json")?;
    println!("{}", serde_json::to_string_pretty(&value)?);
    Ok(())
}

/// Add a path to excluded editor folders.
pub fn prefs_excluded_editor_folders_add(path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let file = "excludedEditorFolders.json";
    let mut value = crate::hub_storage::read_json(&dir, file).unwrap_or_else(|_| serde_json::json!({"schema_version":"1","data":[]}));
    if value.get("schema_version").is_none() { value["schema_version"] = serde_json::json!("1"); }
    if !value.get("data").map(|d| d.is_array()).unwrap_or(false) { value["data"] = serde_json::json!([]); }
    if let Some(arr) = value.get_mut("data").and_then(|d| d.as_array_mut()) {
        if !arr.iter().any(|v| v.as_str() == Some(path)) {
            arr.push(serde_json::Value::String(path.to_string()));
        }
    }
    crate::hub_storage::write_json(&dir, file, &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, file).display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

/// Remove a path from excluded editor folders.
pub fn prefs_excluded_editor_folders_remove(path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let file = "excludedEditorFolders.json";
    let mut value = crate::hub_storage::read_json(&dir, file).unwrap_or_else(|_| serde_json::json!({"schema_version":"1","data":[]}));
    if let Some(arr) = value.get_mut("data").and_then(|d| d.as_array_mut()) {
        arr.retain(|v| v.as_str() != Some(path));
    }
    crate::hub_storage::write_json(&dir, file, &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, file).display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

/// Set an arbitrary field on matching editor entries in editors-v2 (value as JSON, or plain string).
pub fn registry_set_editor_field(matcher: &str, key: &str, value_json: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("editors-v2.json");
    let mut reg = crate::hub_registry::load_editors_registry(&reg_path)?;
    let needle = matcher.trim_end_matches(['\\', '/']).to_ascii_lowercase();
    let val: serde_json::Value = serde_json::from_str(value_json).unwrap_or_else(|_| serde_json::Value::String(value_json.to_string()));
    let mut count = 0usize;
    for e in &mut reg.data {
        let loc = e.get("location").or_else(|| e.get("path")).and_then(|v| v.as_str()).unwrap_or("").trim_end_matches(['\\', '/']).to_ascii_lowercase();
        let ver = e.get("version").and_then(|v| v.as_str()).unwrap_or("").to_ascii_lowercase();
        if loc == needle || ver == needle || e.get("version").and_then(|v| v.as_str()).unwrap_or("") == matcher {
            if let Some(obj) = e.as_object_mut() {
                obj.insert(key.to_string(), val.clone());
                count += 1;
            }
        }
    }
    crate::hub_registry::save_editors_registry(&reg_path, &reg)?;
    println!("updated: {} (matched {}, {}={})", count, matcher, key, serde_json::to_string(&val)?);
    println!("registry: {}", reg_path.display());
    Ok(())
}

pub fn prefs_hide_hub_on_editor_open_get(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let content = crate::hub_storage::read_raw(&dir, "hideHubOnEditorOpen.json")?;
    println!("{content}");
    Ok(())
}

pub fn prefs_hide_hub_on_editor_open_set(value: bool, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let content = if value { "true" } else { "false" };
    crate::hub_storage::write_raw(&dir, "hideHubOnEditorOpen.json", content)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, "hideHubOnEditorOpen.json").display());
    println!("{content}");
    Ok(())
}

pub fn prefs_project_sort_get(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = crate::hub_storage::read_json(&dir, "projectSortPreferences.json")?;
    println!("{}", serde_json::to_string_pretty(&value)?);
    Ok(())
}

pub fn prefs_project_sort_set(sort_by: &str, sort_direction: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = serde_json::json!({"sortBy": sort_by, "sortDirection": sort_direction});
    crate::hub_storage::write_json(&dir, "projectSortPreferences.json", &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, "projectSortPreferences.json").display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

pub fn prefs_skip_remove_confirmation_get(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = crate::hub_storage::read_json(&dir, "skipRemoveConfirmation.json")?;
    println!("{}", serde_json::to_string_pretty(&value)?);
    Ok(())
}

pub fn prefs_skip_remove_confirmation_set(always: bool, timestamp: i64, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = serde_json::json!({"timestamp": timestamp, "always": always});
    crate::hub_storage::write_json(&dir, "skipRemoveConfirmation.json", &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, "skipRemoveConfirmation.json").display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

/// Read paused-downloads.json (Hub 3.22 install/download state file).
pub fn downloads_paused_get(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = crate::hub_storage::read_json(&dir, "paused-downloads.json")?;
    println!("{}", serde_json::to_string_pretty(&value)?);
    Ok(())
}

/// Reset paused-downloads.json to empty default.
pub fn downloads_paused_clear(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let value = serde_json::json!({"downloads": [], "version": 1});
    crate::hub_storage::write_json(&dir, "paused-downloads.json", &value)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, "paused-downloads.json").display());
    println!("{}", serde_json::to_string(&value)?);
    Ok(())
}

/// Add/update an entry in paused-downloads.json by uid/id field.
pub fn downloads_paused_add_entry(entry_json: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let entry: serde_json::Value = serde_json::from_str(entry_json)?;
    let mut root = crate::hub_storage::read_json(&dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
    if !root.get("downloads").map(|v| v.is_array()).unwrap_or(false) { root["downloads"] = serde_json::json!([]); }
    if root.get("version").is_none() { root["version"] = serde_json::json!(1); }
    let uid = entry.get("uid").or_else(|| entry.get("id")).and_then(|v| v.as_str()).map(|s| s.to_string());
    if let Some(arr) = root.get_mut("downloads").and_then(|v| v.as_array_mut()) {
        if let Some(uid) = uid.as_deref() {
            if let Some(existing) = arr.iter_mut().find(|e| e.get("uid").or_else(|| e.get("id")).and_then(|v| v.as_str()) == Some(uid)) {
                *existing = entry.clone();
            } else {
                arr.push(entry.clone());
            }
        } else {
            arr.push(entry.clone());
        }
    }
    crate::hub_storage::write_json(&dir, "paused-downloads.json", &root)?;
    println!("{}", serde_json::json!({"ok":true,"method":"addPausedDownloadEntry","uid":uid}));
    Ok(())
}

/// Remove an entry from paused-downloads.json by uid/id.
pub fn downloads_paused_remove_entry(uid: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let mut root = crate::hub_storage::read_json(&dir, "paused-downloads.json").unwrap_or(serde_json::json!({"downloads":[],"version":1}));
    let mut removed = 0usize;
    if let Some(arr) = root.get_mut("downloads").and_then(|v| v.as_array_mut()) {
        let before = arr.len();
        arr.retain(|e| e.get("uid").or_else(|| e.get("id")).and_then(|v| v.as_str()) != Some(uid));
        removed = before.saturating_sub(arr.len());
    }
    if root.get("version").is_none() { root["version"] = serde_json::json!(1); }
    crate::hub_storage::write_json(&dir, "paused-downloads.json", &root)?;
    println!("{}", serde_json::json!({"ok":removed>0,"removed":removed,"method":"removePausedDownloadEntry","uid":uid}));
    Ok(())
}

fn query_install_state_table(data_dir: &std::path::Path, table: &str) -> Result<serde_json::Value> {
    crate::install_state::read_table_json(data_dir, table)
}

/// Inspect install-state SQLite database (Hub 3.22 install/download state).
pub fn install_state_info(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let path = dir.join("install-state").join("install-state.db");
    println!("db: {}", path.display());
    if !path.exists() {
        println!("not_found");
        return Ok(());
    }
    let conn = rusqlite::Connection::open_with_flags(&path, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY)
        .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let mut stmt = conn
        .prepare("SELECT name, type, sql FROM sqlite_master WHERE type IN ('table','index') ORDER BY type, name")
        .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    let rows = stmt
        .query_map([], |row| {
            Ok((
                row.get::<_, String>(0)?,
                row.get::<_, String>(1)?,
                row.get::<_, Option<String>>(2)?,
            ))
        })
        .map_err(|e| crate::error::HubError::Other(e.to_string()))?;
    for row in rows {
        let (name, kind, sql) = row.map_err(|e| crate::error::HubError::Other(e.to_string()))?;
        if kind == "table" {
            let count: i64 = conn
                .query_row(&format!("SELECT COUNT(*) FROM \"{}\"", name.replace('"', "\"\"")), [], |r| r.get(0))
                .unwrap_or(0);
            println!("table: {} (rows={})", name, count);
        } else {
            println!("{}: {}", kind, name);
        }
        if let Some(sql) = sql {
            println!("  sql: {}", sql);
        }
    }
    Ok(())
}

/// Read install-state downloads table as JSON.
pub fn install_state_downloads(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let v = query_install_state_table(&dir, "downloads")?;
    println!("{}", serde_json::to_string_pretty(&v)?);
    Ok(())
}

/// Read install-state installs table as JSON.
pub fn install_state_installs(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let v = query_install_state_table(&dir, "installs")?;
    println!("{}", serde_json::to_string_pretty(&v)?);
    Ok(())
}

/// Queue a download in install-state.db (schema-compatible).
pub fn install_state_queue_download(uid: &str, version: &str, arch: Option<&str>, modules_json: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    crate::install_state::queue_download(&dir, uid, version, arch, modules_json, now)?;
    println!("{}", serde_json::json!({"ok":true,"method":"queueDownload","uid":uid,"version":version,"state":"queued"}));
    Ok(())
}

/// Update download state in install-state.db.
pub fn install_state_set_download_state(uid: &str, state: &str, bytes_done: Option<i64>, bytes_total: Option<i64>, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    let ok = crate::install_state::set_download_state(&dir, uid, state, bytes_done, bytes_total, None, None, now)?;
    println!("{}", serde_json::json!({"ok":ok,"method":"setDownloadState","uid":uid,"state":state}));
    Ok(())
}

/// Cancel a download in install-state.db.
pub fn install_state_cancel_download(uid: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    let ok = crate::install_state::cancel_download(&dir, uid, now)?;
    println!("{}", serde_json::json!({"ok":ok,"method":"cancelDownload","uid":uid,"state":"cancelled"}));
    Ok(())
}

/// Queue/replace active install entry in install-state.db.
pub fn install_state_queue_install(uid: &str, version: &str, modules_json: &str, pid: i64, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    crate::install_state::queue_install(&dir, uid, version, modules_json, pid, now)?;
    println!("{}", serde_json::json!({"ok":true,"method":"queueInstall","uid":uid,"version":version,"phase":"queued"}));
    Ok(())
}

/// Clear active install entry.
pub fn install_state_clear_install(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let ok = crate::install_state::clear_install(&dir)?;
    println!("{}", serde_json::json!({"ok":ok,"method":"clearInstall"}));
    Ok(())
}

/// Read install-state file_claims table as JSON.
pub fn install_state_file_claims(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let v = query_install_state_table(&dir, "file_claims")?;
    println!("{}", serde_json::to_string_pretty(&v)?);
    Ok(())
}

/// Read install-state schema_meta table as JSON.
pub fn install_state_schema_meta(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let v = query_install_state_table(&dir, "schema_meta")?;
    println!("{}", serde_json::to_string_pretty(&v)?);
    Ok(())
}

/// Set active install phase in install-state.db (`queued` or `installing`).
pub fn install_state_set_install_phase(phase: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    let ok = crate::install_state::set_install_phase(&dir, phase, now)?;
    println!("{}", serde_json::json!({"ok":ok,"method":"setInstallPhase","phase":phase}));
    Ok(())
}

/// Upsert a file claim row in install-state.db.
pub fn install_state_upsert_file_claim(
    pid: i64,
    source: &str,
    path: &str,
    data_dir: Option<&str>,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    crate::install_state::upsert_file_claim(&dir, pid, source, path, now)?;
    println!("{}", serde_json::json!({"ok":true,"method":"upsertFileClaim","pid":pid,"source":source,"path":path}));
    Ok(())
}

/// Remove a file claim row from install-state.db.
pub fn install_state_remove_file_claim(
    pid: i64,
    source: &str,
    path: &str,
    data_dir: Option<&str>,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let ok = crate::install_state::remove_file_claim(&dir, pid, source, path)?;
    println!("{}", serde_json::json!({"ok":ok,"method":"removeFileClaim","pid":pid,"source":source,"path":path}));
    Ok(())
}

/// Clear all file claim rows from install-state.db.
pub fn install_state_clear_file_claims(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let removed = crate::install_state::clear_file_claims(&dir)?;
    println!("{}", serde_json::json!({"ok":true,"method":"clearFileClaims","removed":removed}));
    Ok(())
}

/// Sync scanned editor installs into editors-v2 registry.
pub fn registry_sync_editors(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("editors-v2.json");
    let mut reg = crate::hub_registry::load_editors_registry(&reg_path)?;
    let installs = crate::installs::installed_editors()?;
    let (added, updated) = crate::hub_registry::sync_editors_from_scan(&mut reg, &installs);
    crate::hub_registry::save_editors_registry(&reg_path, &reg)?;
    println!("registry: {}", reg_path.display());
    println!("scanned: {}", installs.len());
    println!("added: {}", added);
    println!("updated: {}", updated);
    println!("total: {}", reg.data.len());
    Ok(())
}

/// Sync discovered projects into projects-v1 registry.
pub fn registry_sync_projects(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    let found = crate::projects::discover_projects()?;
    let upserted = crate::hub_registry::sync_projects_from_scan(&mut reg, &found);
    crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
    println!("registry: {}", reg_path.display());
    println!("scanned: {}", found.len());
    println!("upserted: {}", upserted);
    println!("total: {}", reg.data.len());
    Ok(())
}

/// Remove a project from projects-v1 registry.
pub fn registry_remove_project(project_path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    let removed = crate::hub_registry::remove_project(&mut reg, project_path);
    crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
    println!("{}: {}", if removed { "removed" } else { "not_found" }, project_path);
    println!("registry: {}", reg_path.display());
    println!("total: {}", reg.data.len());
    Ok(())
}

/// Set favorite flag for a project in projects-v1 registry.
pub fn registry_set_favorite(project_path: &str, favorite: bool, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    let ok = crate::hub_registry::set_project_favorite(&mut reg, project_path, favorite);
    if ok {
        crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
    }
    println!("{}: {}\tisFavorite={}", if ok { "updated" } else { "not_found" }, project_path, favorite);
    println!("registry: {}", reg_path.display());
    Ok(())
}

/// Touch lastModified for a project in projects-v1 registry.
pub fn registry_touch_project(project_path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    let ts = crate::hub_registry::now_millis();
    let ok = crate::hub_registry::touch_project_last_modified(&mut reg, project_path, ts);
    if ok {
        crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
    }
    println!("{}: {}\tlastModified={}", if ok { "updated" } else { "not_found" }, project_path, ts);
    println!("registry: {}", reg_path.display());
    Ok(())
}

/// Remove an editor entry from editors-v2 registry (by version or location).
pub fn registry_remove_editor(matcher: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("editors-v2.json");
    let mut reg = crate::hub_registry::load_editors_registry(&reg_path)?;
    let removed = crate::hub_registry::remove_editor(&mut reg, matcher);
    crate::hub_registry::save_editors_registry(&reg_path, &reg)?;
    println!("removed: {} (matched {})", removed, matcher);
    println!("registry: {}", reg_path.display());
    println!("total: {}", reg.data.len());
    Ok(())
}

/// Show a project record from projects-v1 registry as JSON.
pub fn registry_get_project(project_path: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    if let Some(rec) = reg.data.get(project_path) {
        println!("{}", serde_json::to_string_pretty(rec)?);
    } else {
        println!("not_found: {}", project_path);
    }
    Ok(())
}

/// Set isCustomEditor flag for a project.
pub fn registry_set_custom_editor(project_path: &str, is_custom: bool, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    if let Some(rec) = reg.data.get_mut(project_path) {
        rec.is_custom_editor = Some(is_custom);
        crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
        println!("updated: {}\tisCustomEditor={}", project_path, is_custom);
    } else {
        println!("not_found: {}", project_path);
    }
    println!("registry: {}", reg_path.display());
    Ok(())
}

/// List projects sorted by lastModified desc (recent projects view).
pub fn registry_recents(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let reg_path = dir.join("projects-v1.json");
    let reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    println!("registry: {}", reg_path.display());
    for (key, rec) in crate::hub_registry::recent_projects(&reg) {
        let title = rec.title.as_deref().unwrap_or("-");
        let version = rec.version.as_deref().unwrap_or("-");
        let lm = rec.last_modified.as_ref().and_then(|v| v.as_i64().or_else(|| v.as_f64().map(|f| f as i64))).unwrap_or(0);
        println!("{lm}\t{title}\t{version}\t{key}");
    }
    Ok(())
}

/// List files in Hub data storage directory.
pub fn storage_list(data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    println!("data_dir: {}", dir.display());
    for name in crate::hub_storage::list_files(&dir)? {
        println!("{name}");
    }
    Ok(())
}

/// Read a Hub storage file (raw content).
pub fn storage_get(file_name: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let content = crate::hub_storage::read_raw(&dir, file_name)?;
    println!("{content}");
    Ok(())
}

/// Write a Hub storage file with provided JSON/text content.
pub fn storage_set(file_name: &str, content: &str, data_dir: Option<&str>) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    crate::hub_storage::write_raw(&dir, file_name, content)?;
    println!("written: {}", crate::hub_storage::file_path(&dir, file_name).display());
    Ok(())
}

/// Handle the `port-status` subcommand: report 3.22 Electron app inventory and Rust port status.
pub fn port_status() -> Result<()> {
    let base = std::env::current_dir().unwrap_or_else(|_| std::path::PathBuf::from("."));
    let extracted = base.join("electron-hub-3.22").join("app");

    println!("Unity Hub 3.22.6 (Electron) -> Rust port status");
    println!("source: {}", extracted.display());

    if extracted.exists() {
        if let Ok(info) = crate::services::hub_app::read_app_info(&extracted) {
            println!("app: {} v{} (main: {})", info.name, info.version, info.main.as_deref().unwrap_or("?"));
        }
        let inv = crate::app_inventory::load(&extracted).map_err(crate::error::HubError::Io)?;
        println!("extracted_files: {}", inv.total_files);
        println!("build_modules: {}", inv.build_modules.len());
        println!("service_families: {}", inv.services.len());
        println!("manager_families: {}", inv.managers.len());
        println!("renderer_files: {}", inv.renderer_files.len());
        println!("entrypoints: {}", inv.entrypoints.join(", "));
        println!("domains:");
        for d in crate::app_inventory::known_domains() {
            println!("  - {d}");
        }
    } else {
        println!("extracted app not found (run from workspace root with electron-hub-3.22/app present)");
    }

    // 3.22 CLI preserved
    let cli_path = base.join("runtime").join("unity-hub-3.22.exe");
    if cli_path.exists() {
        if let Ok(meta) = std::fs::metadata(&cli_path) {
            println!("unity_cli_3_22: preserved ({} bytes)", meta.len());
        }
    }

    println!("rust_port: crate={} v{}", env!("CARGO_PKG_NAME"), env!("CARGO_PKG_VERSION"));
    println!("ported_services: editor_inventory, local_project, installation_manager, license_service, auth_service, settings_service, hub_app");
    println!("port_status: ok");
    Ok(())
}

/// List project templates for an installed editor version or install path.
pub fn editor_templates(editor: &str) -> Result<()> {
    let install_path = if std::path::Path::new(editor).exists() {
        std::path::PathBuf::from(editor)
    } else if let Some(inst) = crate::installs::find_installed_editor(editor)? {
        std::path::PathBuf::from(inst.install_path)
    } else {
        return Err(crate::error::HubError::Other(format!("editor not found: {}", editor)));
    };
    let templates = crate::installs::list_editor_templates(&install_path)?;
    let out = serde_json::json!({
        "editor": editor,
        "installPath": install_path.to_string_lossy(),
        "templates": templates,
    });
    println!("{}", serde_json::to_string_pretty(&out)?);
    Ok(())
}

/// Build 3.22-aligned open-project editor args.
pub fn project_open_args(project_path: &str, extra: &[String]) -> Result<()> {
    let args = crate::installs::build_open_project_args(project_path, extra);
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({"projectPath": project_path, "args": args}))?);
    Ok(())
}

/// Build 3.22-aligned create-project editor args.
pub fn project_create_args(project_path: &str, template: &str, cloud_org: Option<&str>, cloud_project: Option<&str>) -> Result<()> {
    let args = crate::installs::build_create_project_args(project_path, template, cloud_org, cloud_project);
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "projectPath": project_path,
        "template": template,
        "cloudOrganization": cloud_org,
        "cloudProject": cloud_project,
        "args": args
    }))?);
    Ok(())
}

/// Build a safe open-project launch plan (resolve editor + args) without spawning editor.
/// If `touch` is true, updates project's lastModified in registry like open/recents flow.
pub fn project_open_plan(project_path: &str, data_dir: Option<&str>, touch: bool) -> Result<()> {
    let p = std::path::Path::new(project_path);
    let data_dir_path = resolve_data_dir(data_dir);
    let reg_path = data_dir_path.join("projects-v1.json");
    let mut reg = crate::hub_registry::load_projects_registry(&reg_path)?;
    let reg_version = reg.data.get(project_path).and_then(|r| r.version.clone());
    let file_version = crate::projects::read_project_editor_version(p);
    let version = reg_version.clone().or(file_version.clone())
        .ok_or_else(|| crate::error::HubError::Other(format!("unable to determine editor version for project: {}", project_path)))?;
    let editor = crate::installs::find_installed_editor(&version)?
        .ok_or_else(|| crate::error::HubError::Other(format!("installed editor not found for version: {}", version)))?;
    let exe = crate::installs::editor_executable_path(std::path::Path::new(&editor.install_path));
    let args = crate::installs::build_open_project_args(project_path, &[]);
    let mut touched = false;
    if touch {
        let now = crate::hub_registry::now_millis();
        if !reg.data.contains_key(project_path) {
            let title = p.file_name().and_then(|s| s.to_str()).unwrap_or(project_path).to_string();
            crate::hub_registry::upsert_project(&mut reg, project_path, &title, Some(version.clone()));
        }
        touched = crate::hub_registry::touch_project_last_modified(&mut reg, project_path, now);
        crate::hub_registry::save_projects_registry(&reg_path, &reg)?;
    }
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": true,
        "projectPath": project_path,
        "editorVersion": version,
        "editorVersionFromRegistry": reg_version,
        "editorVersionFromProject": file_version,
        "editorInstallPath": editor.install_path,
        "editorExecutable": exe.to_string_lossy(),
        "editorExecutableExists": exe.is_file(),
        "args": args,
        "touchedLastModified": touched
    }))?);
    Ok(())
}

/// Build a safe create-project launch plan (resolve editor/template + args) without spawning editor.
pub fn project_create_plan(
    project_path: &str,
    editor_version: &str,
    template: &str,
    cloud_org: Option<&str>,
    cloud_project: Option<&str>,
) -> Result<()> {
    let editor = crate::installs::find_installed_editor(editor_version)?
        .ok_or_else(|| crate::error::HubError::Other(format!("installed editor not found for version: {}", editor_version)))?;
    let install_path = std::path::Path::new(&editor.install_path);
    let exe = crate::installs::editor_executable_path(install_path);
    let template_path = crate::projects::resolve_template_path(install_path, template);
    let template_arg = template_path
        .as_ref()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|| template.to_string());
    let args = crate::installs::build_create_project_args(project_path, &template_arg, cloud_org, cloud_project);
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": true,
        "projectPath": project_path,
        "editorVersion": editor_version,
        "editorInstallPath": editor.install_path,
        "editorExecutable": exe.to_string_lossy(),
        "editorExecutableExists": exe.is_file(),
        "template": template,
        "resolvedTemplatePath": template_path.as_ref().map(|p| p.to_string_lossy().to_string()),
        "templateResolved": template_path.is_some(),
        "args": args
    }))?);
    Ok(())
}

/// Read Unity project version info from ProjectSettings/ProjectVersion.txt.
pub fn project_version_info(project_path: &str) -> Result<()> {
    let p = std::path::Path::new(project_path);
    let is_unity = crate::projects::is_unity_project(p);
    let (version, revision) = crate::projects::read_project_version_info(p).unwrap_or((None, None));
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "projectPath": project_path,
        "isUnityProject": is_unity,
        "editorVersion": version,
        "editorRevision": revision
    }))?);
    Ok(())
}

/// Open project flow: resolve editor, update registry recents/lastModified, and optionally launch Unity.
pub fn project_open(project_path: &str, data_dir: Option<&str>, launch: bool, extra: &[String]) -> Result<()> {
    let p = std::path::Path::new(project_path);
    let data_dir_path = resolve_data_dir(data_dir);
    // ensure in registry and touch
    let _ = crate::services::local_project::open_project(&data_dir_path, project_path)?;
    let reg = crate::services::local_project::load_registry(&data_dir_path)?;
    let reg_version = reg.data.get(project_path).and_then(|r| r.version.clone());
    let file_version = crate::projects::read_project_editor_version(p);
    let version = reg_version.clone().or(file_version.clone())
        .ok_or_else(|| crate::error::HubError::Other(format!("unable to determine editor version for project: {}", project_path)))?;
    let editor = crate::installs::find_installed_editor(&version)?
        .ok_or_else(|| crate::error::HubError::Other(format!("installed editor not found for version: {}", version)))?;
    let exe = crate::installs::editor_executable_path(std::path::Path::new(&editor.install_path));
    let args = crate::installs::build_open_project_args(project_path, extra);
    let mut launched = false;
    let mut launch_error: Option<String> = None;
    if launch {
        match std::process::Command::new(&exe).args(&args).spawn() {
            Ok(_child) => { launched = true; }
            Err(e) => { launch_error = Some(e.to_string()); }
        }
    }
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": launch_error.is_none(),
        "projectPath": project_path,
        "editorVersion": version,
        "editorExecutable": exe.to_string_lossy(),
        "editorExecutableExists": exe.is_file(),
        "args": args,
        "registryUpdated": true,
        "launched": launched,
        "launchError": launch_error
    }))?);
    Ok(())
}

/// Create project flow: resolve editor/template and args, optionally launch Unity to create.
pub fn project_create(
    project_path: &str,
    editor_version: &str,
    template: &str,
    cloud_org: Option<&str>,
    cloud_project: Option<&str>,
    launch: bool,
) -> Result<()> {
    let editor = crate::installs::find_installed_editor(editor_version)?
        .ok_or_else(|| crate::error::HubError::Other(format!("installed editor not found for version: {}", editor_version)))?;
    let install_path = std::path::Path::new(&editor.install_path);
    let exe = crate::installs::editor_executable_path(install_path);
    let template_path = crate::projects::resolve_template_path(install_path, template);
    let template_arg = template_path
        .as_ref()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_else(|| template.to_string());
    let args = crate::installs::build_create_project_args(project_path, &template_arg, cloud_org, cloud_project);
    let mut launched = false;
    let mut launch_error: Option<String> = None;
    if launch {
        if let Some(parent) = std::path::Path::new(project_path).parent() {
            let _ = std::fs::create_dir_all(parent);
        }
        match std::process::Command::new(&exe).args(&args).spawn() {
            Ok(_child) => { launched = true; }
            Err(e) => { launch_error = Some(e.to_string()); }
        }
    }
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": launch_error.is_none(),
        "projectPath": project_path,
        "editorVersion": editor_version,
        "editorExecutable": exe.to_string_lossy(),
        "editorExecutableExists": exe.is_file(),
        "template": template,
        "resolvedTemplatePath": template_path.as_ref().map(|p| p.to_string_lossy().to_string()),
        "templateResolved": template_path.is_some(),
        "args": args,
        "launched": launched,
        "launchError": launch_error
    }))?);
    Ok(())
}

/// List modules for an installed editor (from modules.json if present).
pub fn editor_modules(editor: &str) -> Result<()> {
    let (install_path, modules) = crate::installs::get_editor_modules(editor)?;
    let (count, installed_count) = match &modules {
        Some(serde_json::Value::Array(arr)) => {
            let installed = arr.iter().filter(|m| m.get("isInstalled").and_then(|v| v.as_bool()).unwrap_or(false)).count();
            (arr.len(), Some(installed))
        }
        _ => (0, None),
    };
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": true,
        "editor": editor,
        "installPath": install_path.to_string_lossy(),
        "modulesJsonExists": modules.is_some(),
        "moduleCount": count,
        "installedModuleCount": installed_count,
        "modules": modules.unwrap_or(serde_json::Value::Null)
    }))?);
    Ok(())
}

/// Show downloadable editors cache summary/info (from local hub-gpui cache if present).
pub fn releases_cache(data_dir: Option<&str>, version: Option<&str>, summary_only: bool) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let found = crate::updates::read_downloadable_editors_cache(&dir)?;
    let (path, cache) = match found {
        Some(v) => v,
        None => {
            println!("{}", serde_json::json!({"ok":false,"error":"downloadable editors cache not found","dataDir":dir.to_string_lossy()}));
            return Ok(());
        }
    };
    if let Some(ver) = version {
        let plan = crate::updates::plan_cached_release_install(&cache, ver, &dir);
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({
            "ok": plan.get("ok").and_then(|v| v.as_bool()).unwrap_or(false),
            "cachePath": path.to_string_lossy(),
            "result": plan
        }))?);
    } else if summary_only {
        let summary = crate::updates::summarize_downloadable_editors(&cache);
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({
            "cachePath": path.to_string_lossy(),
            "summary": summary
        }))?);
    } else {
        let summary = crate::updates::summarize_downloadable_editors(&cache);
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({
            "cachePath": path.to_string_lossy(),
            "summary": summary
        }))?);
    }
    Ok(())
}

/// Execute a local installer/module process with install-state DB integration (pipeline step).
/// Marks download complete (if uid provided), queues/sets install phase to `installing`, runs process,
/// then clears install record on completion and reports exit status. No network download performed.
pub fn install_execute_local(
    data_dir: Option<&str>,
    uid: Option<&str>,
    version: &str,
    modules_json: &str,
    program: &str,
    args: &[String],
    mark_download_complete: bool,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    let install_uid = uid.unwrap_or(version);
    if mark_download_complete {
        if let Some(download_uid) = uid {
            let _ = crate::install_state::set_download_state(&dir, download_uid, "complete", None, None, None, None, now);
        }
    }
    crate::install_state::queue_install(&dir, install_uid, version, modules_json, std::process::id() as i64, now)?;
    let _ = crate::install_state::set_install_phase(&dir, "installing", crate::hub_registry::now_millis());
    let started = std::time::Instant::now();
    let status = std::process::Command::new(program).args(args).status();
    let elapsed_ms = started.elapsed().as_millis() as u64;
    let (ok, exit_code, error): (bool, Option<i32>, Option<String>) = match status {
        Ok(s) => (s.success(), s.code(), if s.success() { None } else { Some(format!("installer exited with status {s}")) }),
        Err(e) => (false, None, Some(e.to_string())),
    };
    // schema only supports queued/installing; clear record after execution to reflect completion/failure outcome
    let _ = crate::install_state::clear_install(&dir);
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": ok,
        "method": "installExecuteLocal",
        "uid": install_uid,
        "version": version,
        "modules": modules_json,
        "program": program,
        "args": args,
        "exitCode": exit_code,
        "elapsedMs": elapsed_ms,
        "downloadMarkedComplete": mark_download_complete && uid.is_some(),
        "installStateCleared": true,
        "error": error
    }))?);
    Ok(())
}

/// Queue a cached editor release into install-state (download+install records) using local downloadable-editors cache.
/// Dry-run planning only (no network download / no installer execution).
pub fn install_queue_cached_release(
    data_dir: Option<&str>,
    version: &str,
    uid: Option<&str>,
    modules_json: Option<&str>,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let found = crate::updates::read_downloadable_editors_cache(&dir)?;
    let (cache_path, cache) = match found {
        Some(v) => v,
        None => {
            println!("{}", serde_json::json!({"ok":false,"error":"downloadable editors cache not found","dataDir":dir.to_string_lossy(),"version":version}));
            return Ok(());
        }
    };
    let plan = crate::updates::plan_cached_release_install(&cache, version, &dir);
    if !plan.get("ok").and_then(|v| v.as_bool()).unwrap_or(false) {
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({"ok":false,"cachePath":cache_path.to_string_lossy(),"result":plan}))?);
        return Ok(());
    }
    let now = crate::hub_registry::now_millis();
    let download_uid = uid.unwrap_or(version).to_string();
    let arch = plan.get("architecture").and_then(|v| v.as_str());
    let modules = modules_json.unwrap_or("[]");
    crate::install_state::queue_download(&dir, &download_uid, version, arch, modules, now)?;
    if let Some(total) = plan.get("downloadSizeBytes").and_then(|v| v.as_i64()) {
        let _ = crate::install_state::set_download_state(&dir, &download_uid, "queued", Some(0), Some(total), None, None, now);
    }
    crate::install_state::queue_install(&dir, &download_uid, version, modules, std::process::id() as i64, now)?;
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": true,
        "method": "installQueueCachedRelease",
        "cachePath": cache_path.to_string_lossy(),
        "uid": download_uid,
        "version": version,
        "modules": modules,
        "plan": plan,
        "queued": {
            "downloadState": "queued",
            "installPhase": "queued"
        },
        "note": "queued in install-state DB from local cache; no network download or installer execution performed"
    }))?);
    Ok(())
}

/// Report editor install status (installed on disk, in editors registry, and/or in install-state).
pub fn editor_install_status(data_dir: Option<&str>, version: &str) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let installed = crate::installs::find_installed_editor(version)?;
    let reg_path = dir.join("editors-v2.json");
    let reg = crate::hub_registry::load_editors_registry(&reg_path).ok();
    let in_registry = reg.as_ref().map(|r| {
        r.data.iter().any(|e| e.get("version").and_then(|v| v.as_str()) == Some(version)
            || e.get("location").and_then(|v| v.as_str()).map(|loc| loc.contains(version)).unwrap_or(false))
    }).unwrap_or(false);
    let downloads = crate::install_state::read_table_json(&dir, "downloads").unwrap_or(serde_json::json!({"rows":[]}));
    let installs = crate::install_state::read_table_json(&dir, "installs").unwrap_or(serde_json::json!({"rows":[]}));
    let dl_row = downloads.get("rows").and_then(|v| v.as_array()).and_then(|rows| {
        rows.iter().rev().find(|r| r.get("version").and_then(|v| v.as_str()) == Some(version) || r.get("uid").and_then(|v| v.as_str()) == Some(version)).cloned()
    });
    let inst_row = installs.get("rows").and_then(|v| v.as_array()).and_then(|rows| {
        rows.iter().find(|r| r.get("version").and_then(|v| v.as_str()) == Some(version) || r.get("uid").and_then(|v| v.as_str()) == Some(version)).cloned()
    });
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "version": version,
        "installedOnDisk": installed.is_some(),
        "installedEditor": installed,
        "inEditorsRegistry": in_registry,
        "downloadState": dl_row,
        "installState": inst_row
    }))?);
    Ok(())
}

/// Download a URL to a destination file and track progress in install-state DB.
pub fn install_download(
    data_dir: Option<&str>,
    uid: &str,
    version: &str,
    url: &str,
    dest: &str,
    arch: Option<&str>,
    modules_json: Option<&str>,
    expected_bytes: Option<i64>,
    ensure_queued: bool,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let now = crate::hub_registry::now_millis();
    if ensure_queued {
        let _ = crate::install_state::queue_download(&dir, uid, version, arch, modules_json.unwrap_or("[]"), now);
    }
    let result = crate::downloads::download_to_file_with_state(&dir, uid, url, std::path::Path::new(dest), expected_bytes)?;
    println!("{}", serde_json::to_string_pretty(&result)?);
    Ok(())
}

/// Integrated local pipeline: download asset -> verify integrity (optional) -> execute installer -> register editor.
/// Designed for runnable end-to-end verification with local/simulated assets (no Unity CDN/auth required).
pub fn install_pipeline_local(
    data_dir: Option<&str>,
    uid: &str,
    version: &str,
    url: &str,
    dest: &str,
    integrity: Option<&str>,
    installer_program: &str,
    installer_args: &[String],
    register_install_path: Option<&str>,
    arch: Option<&str>,
    modules_json: Option<&str>,
    expected_bytes: Option<i64>,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let modules = modules_json.unwrap_or("[]");
    let now = crate::hub_registry::now_millis();
    let _ = crate::install_state::queue_download(&dir, uid, version, arch, modules, now);
    // 1) download
    let dl = crate::downloads::download_to_file_with_state(&dir, uid, url, std::path::Path::new(dest), expected_bytes)?;
    let dl_ok = dl.get("ok").and_then(|v| v.as_bool()).unwrap_or(false);
    let mut integrity_result = serde_json::Value::Null;
    if dl_ok {
        if let Some(int) = integrity {
            integrity_result = crate::downloads::verify_integrity(std::path::Path::new(dest), int)?;
            let matched = integrity_result.get("matched").and_then(|v| v.as_bool()).unwrap_or(false);
            let supported = integrity_result.get("supported").and_then(|v| v.as_bool()).unwrap_or(false);
            if supported && !matched {
                let now = crate::hub_registry::now_millis();
                let _ = crate::install_state::set_download_state(&dir, uid, "failed", None, expected_bytes, Some("INTEGRITY_MISMATCH"), Some("downloaded file integrity mismatch"), now);
                println!("{}", serde_json::to_string_pretty(&serde_json::json!({
                    "ok": false,
                    "stage": "integrity",
                    "uid": uid,
                    "version": version,
                    "download": dl,
                    "integrity": integrity_result,
                    "error": "integrity mismatch"
                }))?);
                return Ok(());
            }
        }
    } else {
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({
            "ok": false,
            "stage": "download",
            "uid": uid,
            "version": version,
            "download": dl,
            "integrity": integrity_result
        }))?);
        return Ok(());
    }
    // 2) install execution (local process)
    let now = crate::hub_registry::now_millis();
    let _ = crate::install_state::set_download_state(&dir, uid, "complete", None, None, None, None, now);
    crate::install_state::queue_install(&dir, uid, version, modules, std::process::id() as i64, now)?;
    let _ = crate::install_state::set_install_phase(&dir, "installing", crate::hub_registry::now_millis());
    let started = std::time::Instant::now();
    let status = std::process::Command::new(installer_program).args(installer_args).status();
    let elapsed_ms = started.elapsed().as_millis() as u64;
    let (inst_ok, exit_code, inst_error): (bool, Option<i32>, Option<String>) = match status {
        Ok(s) => (s.success(), s.code(), if s.success() { None } else { Some(format!("installer exited with status {s}")) }),
        Err(e) => (false, None, Some(e.to_string())),
    };
    let mut registered = false;
    let mut register_path_out: Option<String> = None;
    let mut sync_result = serde_json::Value::Null;
    if inst_ok {
        if let Some(path) = register_install_path {
            if !path.is_empty() {
                let _ = crate::services::editor_inventory::locate_editor(&dir, version, path, false);
                registered = true;
                register_path_out = Some(path.to_string());
            }
        }
        // best-effort post-install reconciliation (scan known locations and merge into editors registry)
        if let Ok((scanned, added, updated)) = crate::services::editor_inventory::sync_from_scan(&dir) {
            sync_result = serde_json::json!({"scanned": scanned, "added": added, "updated": updated});
        }
    }
    let _ = crate::install_state::clear_install(&dir);
    let editor_status = crate::installs::find_installed_editor(version).ok().flatten();
    let reg_path = dir.join("editors-v2.json");
    let reg = crate::hub_registry::load_editors_registry(&reg_path).ok();
    let in_registry = reg.as_ref().map(|r| {
        r.data.iter().any(|e| e.get("version").and_then(|v| v.as_str()) == Some(version)
            || e.get("location").and_then(|v| v.as_str()).map(|loc| loc.contains(version)).unwrap_or(false))
    }).unwrap_or(false);
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": dl_ok && inst_ok,
        "method": "installPipelineLocal",
        "uid": uid,
        "version": version,
        "download": dl,
        "integrity": integrity_result,
        "install": {
            "program": installer_program,
            "args": installer_args,
            "ok": inst_ok,
            "exitCode": exit_code,
            "elapsedMs": elapsed_ms,
            "error": inst_error,
            "installStateCleared": true
        },
        "registration": {
            "registeredInEditorsRegistry": registered || in_registry,
            "registeredPath": register_path_out,
            "inEditorsRegistry": in_registry,
            "scanSync": sync_result
        },
        "installedOnDiskScan": editor_status.is_some(),
        "note": "local/simulated pipeline: no Unity CDN/auth/entitlement; registration is editors-v2 locate when path provided + scan sync"
    }))?);
    Ok(())
}

/// Execute module installation from a URL/file (download -> integrity -> extract/copy for ZIP) into target destination.
/// `unity_path` is substituted for `{UNITY_PATH}` placeholders in destination.
pub fn install_module_local(
    data_dir: Option<&str>,
    uid: &str,
    version: &str,
    url: &str,
    dest_zip: &str,
    module_type: &str,
    destination_template: Option<&str>,
    unity_path: Option<&str>,
    extracted_path_rename_from: Option<&str>,
    extracted_path_rename_to: Option<&str>,
    integrity: Option<&str>,
    arch: Option<&str>,
    modules_json: Option<&str>,
    expected_bytes: Option<i64>,
) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let modules = modules_json.unwrap_or("[]");
    let now = crate::hub_registry::now_millis();
    let _ = crate::install_state::queue_download(&dir, uid, version, arch, modules, now);
    let dl = crate::downloads::download_to_file_with_state(&dir, uid, url, std::path::Path::new(dest_zip), expected_bytes)?;
    let dl_ok = dl.get("ok").and_then(|v| v.as_bool()).unwrap_or(false);
    let mut integrity_result = serde_json::Value::Null;
    let install_result: serde_json::Value;
    if !dl_ok {
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({"ok":false,"stage":"download","uid":uid,"version":version,"moduleType":module_type,"download":dl}))?);
        return Ok(());
    }
    if let Some(int) = integrity {
        integrity_result = crate::downloads::verify_integrity(std::path::Path::new(dest_zip), int)?;
        let matched = integrity_result.get("matched").and_then(|v| v.as_bool()).unwrap_or(false);
        let supported = integrity_result.get("supported").and_then(|v| v.as_bool()).unwrap_or(false);
        if supported && !matched {
            let now = crate::hub_registry::now_millis();
            let _ = crate::install_state::set_download_state(&dir, uid, "failed", None, expected_bytes, Some("INTEGRITY_MISMATCH"), Some("integrity mismatch"), now);
            println!("{}", serde_json::to_string_pretty(&serde_json::json!({"ok":false,"stage":"integrity","uid":uid,"version":version,"moduleType":module_type,"download":dl,"integrity":integrity_result}))?);
            return Ok(());
        }
    }
    let mut final_dest: Option<String> = None;
    let module_ok = if module_type.eq_ignore_ascii_case("ZIP") {
        let dest_tpl = destination_template.unwrap_or("");
        if dest_tpl.is_empty() {
            install_result = serde_json::json!({"ok":false,"error":"ZIP module requires destination"});
            false
        } else {
            let unity = unity_path.unwrap_or("");
            let resolved = dest_tpl.replace("{UNITY_PATH}", unity).replace("{MODULE_DESTINATION}", unity);
            let dest_path = std::path::Path::new(&resolved);
            let extracted = crate::downloads::extract_zip(std::path::Path::new(dest_zip), dest_path)?;
            let mut rename_result = serde_json::Value::Null;
            let mut rename_ok = true;
            if let (Some(from_t), Some(to_t)) = (extracted_path_rename_from, extracted_path_rename_to) {
                let from = from_t.replace("{UNITY_PATH}", unity).replace("{MODULE_DESTINATION}", &resolved);
                let to = to_t.replace("{UNITY_PATH}", unity).replace("{MODULE_DESTINATION}", &resolved);
                let from_p = std::path::Path::new(&from);
                let to_p = std::path::Path::new(&to);
                if let Some(parent) = to_p.parent() { let _ = std::fs::create_dir_all(parent); }
                let r = if from_p.exists() {
                    std::fs::rename(from_p, to_p).or_else(|_| {
                        // fallback copy+remove for cross-device or dir cases
                        if from_p.is_dir() {
                            fn copy_dir(src: &std::path::Path, dst: &std::path::Path) -> std::io::Result<()> {
                                std::fs::create_dir_all(dst)?;
                                for e in std::fs::read_dir(src)? {
                                    let e = e?;
                                    let p = e.path();
                                    let d = dst.join(e.file_name());
                                    if p.is_dir() { copy_dir(&p, &d)?; } else { std::fs::copy(&p, &d)?; }
                                }
                                Ok(())
                            }
                            copy_dir(from_p, to_p).and_then(|_| std::fs::remove_dir_all(from_p))
                        } else {
                            std::fs::copy(from_p, to_p).map(|_| ()).and_then(|_| std::fs::remove_file(from_p))
                        }
                    })
                } else {
                    Err(std::io::Error::new(std::io::ErrorKind::NotFound, "rename source not found"))
                };
                rename_ok = r.is_ok();
                rename_result = serde_json::json!({"from": from, "to": to, "ok": rename_ok, "error": r.err().map(|e| e.to_string())});
            }
            let ex_ok = extracted.get("ok").and_then(|v| v.as_bool()).unwrap_or(false);
            install_result = serde_json::json!({"type":"ZIP","destination":resolved,"extract":extracted,"rename":rename_result,"ok": ex_ok && rename_ok});
            final_dest = Some(resolved);
            ex_ok && rename_ok
        }
    } else if module_type.eq_ignore_ascii_case("PO") {
        let dest_tpl = destination_template.unwrap_or("");
        let unity = unity_path.unwrap_or("");
        let resolved = dest_tpl.replace("{UNITY_PATH}", unity);
        let dest_path = std::path::Path::new(&resolved);
        if let Some(parent) = dest_path.parent() { let _ = std::fs::create_dir_all(parent); }
        let r = std::fs::copy(dest_zip, dest_path);
        let ok = r.is_ok();
        install_result = serde_json::json!({"type":"PO","destination":resolved,"ok":ok,"error": r.err().map(|e| e.to_string())});
        final_dest = Some(resolved);
        ok
    } else {
        install_result = serde_json::json!({"type":module_type,"ok":false,"error":"unsupported module type for local install (implemented: ZIP, PO)"});
        false
    };
    if module_ok {
        let now = crate::hub_registry::now_millis();
        let _ = crate::install_state::set_download_state(&dir, uid, "complete", None, expected_bytes, None, None, now);
    }
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": dl_ok && module_ok,
        "method": "installModuleLocal",
        "uid": uid,
        "version": version,
        "moduleType": module_type,
        "download": dl,
        "integrity": integrity_result,
        "install": install_result,
        "destination": final_dest
    }))?);
    Ok(())
}

/// Build an execution plan for installing a cached editor release (real download URL/integrity + suggested installer args).
/// No download or execution performed.
pub fn install_plan_cached_release(data_dir: Option<&str>, version: &str) -> Result<()> {
    let dir = resolve_data_dir(data_dir);
    let found = crate::updates::read_downloadable_editors_cache(&dir)?;
    let (cache_path, cache) = match found {
        Some(v) => v,
        None => {
            println!("{}", serde_json::json!({"ok":false,"error":"downloadable editors cache not found","dataDir":dir.to_string_lossy(),"version":version}));
            return Ok(());
        }
    };
    let plan = crate::updates::plan_cached_release_install(&cache, version, &dir);
    if !plan.get("ok").and_then(|v| v.as_bool()).unwrap_or(false) {
        println!("{}", serde_json::to_string_pretty(&serde_json::json!({"ok":false,"cachePath":cache_path.to_string_lossy(),"result":plan}))?);
        return Ok(());
    }
    let download_url = plan.get("downloadUrl").and_then(|v| v.as_str()).unwrap_or("");
    let integrity = plan.get("integrity").and_then(|v| v.as_str());
    let download_type = plan.get("downloadType").and_then(|v| v.as_str()).unwrap_or("");
    let install_path = plan.get("plannedInstallPath").and_then(|v| v.as_str()).unwrap_or("");
    let size = plan.get("downloadSizeBytes").and_then(|v| v.as_i64());
    let file_name = download_url.rsplit('/').next().filter(|s| !s.is_empty()).unwrap_or("installer");
    let dest = dir.join("downloads").join(version).join(file_name);
    // Suggested Windows Unity installer args (common Hub behavior for UnitySetup*.exe); may require elevation for Program Files targets.
    let suggested_args: Vec<String> = if cfg!(windows) && download_type.eq_ignore_ascii_case("EXE") {
        vec!["/S".to_string(), format!("/D={}", install_path)]
    } else {
        vec![]
    };
    println!("{}", serde_json::to_string_pretty(&serde_json::json!({
        "ok": true,
        "cachePath": cache_path.to_string_lossy(),
        "version": version,
        "plan": plan,
        "execution": {
            "download": {
                "uid": version,
                "url": download_url,
                "dest": dest.to_string_lossy(),
                "expectedBytes": size,
                "integrity": integrity,
                "integritySupportedByPort": integrity.map(|i| i.starts_with("md5-") || i.starts_with("sha256-") || i.starts_with("sha384-") || i.starts_with("sha512-")).unwrap_or(false)
            },
            "installer": {
                "program": dest.to_string_lossy(),
                "suggestedArgs": suggested_args,
                "targetInstallPath": install_path,
                "note": "Suggested args based on common Unity Windows installer behavior (/S /D=...); verify against Hub 3.22 semantics for this release/platform. May require elevation/admin for Program Files."
            },
            "postInstall": [
                "update install-state (complete/clear install record)",
                "locate/register editor in editors-v2.json",
                "sync editors from scan and reconcile installed state"
            ]
        },
        "blocked": "Executing a real editor install requires user confirmation: multi-GB download, disk space/time, and likely elevated/system-modifying installer execution."
    }))?);
    Ok(())
}

pub fn renderer_info(app_dir: Option<&str>) -> Result<()> {
    let root = app_dir.map(PathBuf::from).unwrap_or_else(crate::renderer::default_extracted_app_root);
    let info = crate::renderer::window_info_json(&root)?;
    println!("{}", serde_json::to_string_pretty(&info)?);
    Ok(())
}

pub fn renderer_serve(window: &str, port: u16, app_dir: Option<&str>) -> Result<()> {
    let root = app_dir.map(PathBuf::from).unwrap_or_else(crate::renderer::default_extracted_app_root);
    crate::renderer::serve_window(&root, window, port)
}

pub fn renderer_open(window: &str, port: u16, app_dir: Option<&str>) -> Result<()> {
    let root = app_dir.map(PathBuf::from).unwrap_or_else(crate::renderer::default_extracted_app_root);
    // validate window exists
    let _ = crate::renderer::resolve_window(&root, window)?;
    let exe = std::env::current_exe()?;
    let mut cmd = std::process::Command::new(exe);
    cmd.arg("renderer-serve").arg("--window").arg(window).arg("--port").arg(port.to_string());
    if let Some(dir) = app_dir { cmd.arg("--app-dir").arg(dir); }
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x08000000;
        cmd.creation_flags(CREATE_NO_WINDOW);
    }
    let child = cmd.spawn()?;
    let url = format!("http://127.0.0.1:{port}/");
    #[cfg(windows)]
    let _ = std::process::Command::new("cmd").args(["/C", "start", "", &url]).spawn();
    #[cfg(not(windows))]
    let _ = std::process::Command::new("xdg-open").arg(&url).spawn();
    println!("{}", serde_json::json!({"ok":true,"method":"rendererOpen","window":window,"port":port,"url":url,"serverPid":child.id(),"note":"started renderer server and opened URL in default browser/app; native embedded webview host not yet implemented"}));
    Ok(())
}
