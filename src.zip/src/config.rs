//! Hub preferences persistence (mirrors the `preferences.json` file).

use crate::error::{HubError, Result};
use serde_json::Value;
use std::path::PathBuf;

/// Default location of the Hub preferences file.
pub fn preferences_path() -> PathBuf {
    #[cfg(target_os = "windows")]
    {
        if let Some(appdata) = std::env::var_os("APPDATA") {
            return PathBuf::from(appdata).join("Unity Hub").join("preferences.json");
        }
        return PathBuf::from(r"C:\Users\liqui\AppData\Roaming\Unity Hub\preferences.json");
    }
    #[cfg(not(target_os = "windows"))]
    {
        if let Some(home) = std::env::var_os("HOME") {
            return PathBuf::from(home).join(".config").join("unity-hub").join("preferences.json");
        }
        return PathBuf::from(".config/unity-hub/preferences.json");
    }
}

/// Load the Hub preferences, returning defaults when the file is missing.
pub fn load() -> Result<Value> {
    let path = preferences_path();
    if !path.is_file() {
        return Ok(Value::Object(serde_json::Map::new()));
    }
    let content = std::fs::read_to_string(&path)
        .map_err(|e| HubError::Io(e))?;
    let value: Value = serde_json::from_str(&content)?;
    Ok(value)
}

/// Persist the Hub preferences.
pub fn save(value: &Value) -> Result<()> {
    let path = preferences_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let content = serde_json::to_string_pretty(value)?;
    std::fs::write(&path, content)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn save_and_load_round_trip() {
        let dir = std::env::temp_dir().join("unity-hub-config-test");
        std::fs::create_dir_all(&dir).unwrap();
        let path = dir.join("preferences.json");
        let value = serde_json::json!({ "ADVANCED": "Advanced", "UPDATE_CHECK_SKIPPED_DISABLED": false });
        std::fs::write(&path, serde_json::to_string(&value).unwrap()).unwrap();
        let loaded: Value = serde_json::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
        assert_eq!(loaded, value);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
