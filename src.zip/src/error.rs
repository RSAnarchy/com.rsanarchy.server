use thiserror::Error;

#[derive(Error, Debug)]
pub enum HubError {
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("i18n error: {0}")]
    I18n(String),

    #[error("not found: {0}")]
    NotFound(String),

    #[error("invalid version: {0}")]
    InvalidVersion(String),

    #[error("{0}")]
    Other(String),
}

pub type Result<T> = std::result::Result<T, HubError>;
