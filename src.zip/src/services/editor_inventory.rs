//! Editor inventory/management service (port of EditorInventoryService / editor-manager).

use crate::error::Result;
use crate::hub_registry::{self, EditorsRegistry};
use crate::installs;
use crate::models::EditorInstall;
use serde_json::Value;
use std::path::{Path, PathBuf};

/// List all installed/located editors known to the Hub (scanned).
pub fn list_installed() -> Result<Vec<EditorInstall>> {
    installs::installed_editors()
}

/// Locate an editor by version string (exact match).
pub fn find_by_version(version: &str) -> Result<Option<EditorInstall>> {
    let editors = list_installed()?;
    Ok(editors.into_iter().find(|e| e.version == version))
}

pub fn editors_registry_path(data_dir: &Path) -> PathBuf {
    data_dir.join("editors-v2.json")
}

pub fn load_registry(data_dir: &Path) -> Result<EditorsRegistry> {
    hub_registry::load_editors_registry(&editors_registry_path(data_dir))
}

pub fn save_registry(data_dir: &Path, reg: &EditorsRegistry) -> Result<()> {
    hub_registry::save_editors_registry(&editors_registry_path(data_dir), reg)
}

pub fn get_located_editors(data_dir: &Path) -> Result<Value> {
    let reg = load_registry(data_dir)?;
    Ok(serde_json::json!({"schema_version": reg.schema_version, "data": reg.data}))
}

pub fn locate_editor(data_dir: &Path, version: &str, location: &str, manual: bool) -> Result<bool> {
    let mut reg = load_registry(data_dir)?;
    let added = hub_registry::upsert_editor(&mut reg, version, location, manual);
    save_registry(data_dir, &reg)?;
    Ok(added)
}

pub fn remove_editor(data_dir: &Path, matcher: &str) -> Result<usize> {
    let mut reg = load_registry(data_dir)?;
    let removed = hub_registry::remove_editor(&mut reg, matcher);
    if removed > 0 {
        save_registry(data_dir, &reg)?;
    }
    Ok(removed)
}

pub fn sync_from_scan(data_dir: &Path) -> Result<(usize, usize, usize)> {
    let mut reg = load_registry(data_dir)?;
    let installs = list_installed()?;
    let (added, updated) = hub_registry::sync_editors_from_scan(&mut reg, &installs);
    save_registry(data_dir, &reg)?;
    Ok((installs.len(), added, updated))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn list_installed_does_not_panic() {
        let _ = list_installed();
    }
}
