//! Installation/download management (port of InstallationManager / DownloadManager).

use crate::error::Result;
use crate::models::{InstallPhase, InstallState};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::path::Path;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InstallationTask {
    pub id: String,
    pub editor_version: String,
    pub state: String,
    pub phase: Option<String>,
}

impl InstallationTask {
    pub fn new(id: impl Into<String>, editor_version: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            editor_version: editor_version.into(),
            state: InstallState::Queued.as_key().to_string(),
            phase: Some(InstallPhase::Preparing.as_key().to_string()),
        }
    }

    pub fn set_state(&mut self, state: InstallState) {
        self.state = state.as_key().to_string();
    }

    pub fn set_phase(&mut self, phase: InstallPhase) {
        self.phase = Some(phase.as_key().to_string());
    }
}

pub fn get_downloads_state(data_dir: &Path) -> Result<Value> {
    crate::install_state::read_table_json(data_dir, "downloads")
}

pub fn get_installs_state(data_dir: &Path) -> Result<Value> {
    crate::install_state::read_table_json(data_dir, "installs")
}

pub fn queue_download(data_dir: &Path, uid: &str, version: &str, arch: Option<&str>, modules_json: &str) -> Result<()> {
    let now = crate::hub_registry::now_millis();
    crate::install_state::queue_download(data_dir, uid, version, arch, modules_json, now)
}

pub fn set_download_state(data_dir: &Path, uid: &str, state: &str, bytes_done: Option<i64>, bytes_total: Option<i64>) -> Result<bool> {
    let now = crate::hub_registry::now_millis();
    crate::install_state::set_download_state(data_dir, uid, state, bytes_done, bytes_total, None, None, now)
}

pub fn cancel_download(data_dir: &Path, uid: &str) -> Result<bool> {
    let now = crate::hub_registry::now_millis();
    crate::install_state::cancel_download(data_dir, uid, now)
}

pub fn queue_install(data_dir: &Path, uid: &str, version: &str, modules_json: &str) -> Result<()> {
    let now = crate::hub_registry::now_millis();
    let pid = std::process::id() as i64;
    crate::install_state::queue_install(data_dir, uid, version, modules_json, pid, now)
}

pub fn set_install_phase(data_dir: &Path, phase: &str) -> Result<bool> {
    let now = crate::hub_registry::now_millis();
    crate::install_state::set_install_phase(data_dir, phase, now)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn task_defaults_to_queued_preparing() {
        let t = InstallationTask::new("t1", "6000.1.3f1");
        assert_eq!(t.state, "STATE_QUEUED");
        assert_eq!(t.phase.as_deref(), Some("PLUGINS_PHASE_PREPARING"));
    }
}
