//! Hub 3.22 app metadata (from extracted `package.json`).

use crate::error::Result;
use serde::Deserialize;
use std::path::Path;

#[derive(Debug, Clone, Deserialize)]
pub struct HubAppInfo {
    pub name: String,
    pub version: String,
    #[serde(default)]
    pub description: Option<String>,
    #[serde(default)]
    pub main: Option<String>,
}

/// Read Hub app info from an extracted app root containing `package.json`.
pub fn read_app_info(extracted_root: &Path) -> Result<HubAppInfo> {
    let path = extracted_root.join("package.json");
    let content = std::fs::read_to_string(&path)?;
    let info: HubAppInfo = serde_json::from_str(&content)?;
    Ok(info)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_extracted_hub_322_info() {
        let root = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("electron-hub-3.22")
            .join("app");
        if !root.exists() {
            return;
        }
        let info = read_app_info(&root).unwrap();
        assert_eq!(info.name, "unity-hub");
        assert_eq!(info.version, "3.22.6");
        assert_eq!(info.main.as_deref(), Some(".vite/build/index.js"));
    }
}
