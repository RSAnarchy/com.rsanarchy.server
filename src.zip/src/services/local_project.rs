//! Local project service (port of LocalProjectService / project-service).

use crate::error::Result;
use crate::hub_registry::{self, ProjectRecord, ProjectsRegistry};
use crate::models::ProjectEntry;
use crate::projects;
use serde_json::Value;
use std::path::{Path, PathBuf};

fn projects_path(data_dir: &Path) -> PathBuf {
    data_dir.join("projects-v1.json")
}

/// Discover/list local Unity projects by scanning filesystem roots.
pub fn list_projects() -> Result<Vec<ProjectEntry>> {
    projects::discover_projects()
}

/// Get a scanned project by its path.
pub fn get_project(path: &str) -> Result<Option<ProjectEntry>> {
    let all = list_projects()?;
    Ok(all.into_iter().find(|p| p.path == path))
}

/// Load projects registry from Hub data dir.
pub fn load_registry(data_dir: &Path) -> Result<ProjectsRegistry> {
    hub_registry::load_projects_registry(&projects_path(data_dir))
}

/// Save projects registry.
pub fn save_registry(data_dir: &Path, reg: &ProjectsRegistry) -> Result<()> {
    hub_registry::save_projects_registry(&projects_path(data_dir), reg)
}

/// Add or update a project in registry, detecting version from ProjectVersion.txt when possible.
pub fn add_project(data_dir: &Path, project_path: &str) -> Result<(ProjectRecord, bool)> {
    let p = Path::new(project_path);
    let title = p
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or("Project")
        .to_string();
    let detected = projects::read_project_version_info(p).unwrap_or((None, None));
    let mut reg = load_registry(data_dir)?;
    let existed = reg.data.contains_key(project_path);
    hub_registry::upsert_project(&mut reg, project_path, &title, detected.0.clone());
    if let Some(rec) = reg.data.get_mut(project_path) {
        if let Some(rev) = detected.1 {
            rec.changeset = Some(rev);
        }
        if rec.is_favorite.is_none() {
            rec.is_favorite = Some(false);
        }
        if rec.is_custom_editor.is_none() {
            rec.is_custom_editor = Some(false);
        }
    }
    save_registry(data_dir, &reg)?;
    let rec = reg.data.get(project_path).cloned().unwrap_or_default();
    Ok((rec, !existed))
}

/// Refresh project info from filesystem (ProjectVersion.txt) and upsert into registry.
pub fn refresh_project(data_dir: &Path, project_path: &str) -> Result<(ProjectRecord, bool)> {
    let (mut rec, added) = add_project(data_dir, project_path)?;
    // ensure lastModified touched if exists on disk? keep existing; caller can touch separately
    let p = Path::new(project_path);
    if let Ok(meta) = std::fs::metadata(p) {
        if let Ok(modified) = meta.modified() {
            if let Ok(dur) = modified.duration_since(std::time::UNIX_EPOCH) {
                let ms = dur.as_millis() as i64;
                let mut reg = load_registry(data_dir)?;
                if let Some(r) = reg.data.get_mut(project_path) {
                    r.last_modified = Some(serde_json::json!(ms));
                    rec.last_modified = r.last_modified.clone();
                    save_registry(data_dir, &reg)?;
                }
            }
        }
    }
    Ok((rec, added))
}

/// Remove project from registry.
pub fn remove_project(data_dir: &Path, project_path: &str) -> Result<bool> {
    let mut reg = load_registry(data_dir)?;
    let removed = hub_registry::remove_project(&mut reg, project_path);
    if removed {
        save_registry(data_dir, &reg)?;
    }
    Ok(removed)
}

/// Touch/open project: ensure exists in registry and update lastModified.
pub fn open_project(data_dir: &Path, project_path: &str) -> Result<bool> {
    let mut reg = load_registry(data_dir)?;
    if !reg.data.contains_key(project_path) {
        let _ = add_project(data_dir, project_path)?;
        reg = load_registry(data_dir)?;
    }
    let now = hub_registry::now_millis();
    let ok = hub_registry::touch_project_last_modified(&mut reg, project_path, now);
    if ok {
        save_registry(data_dir, &reg)?;
    }
    Ok(ok)
}

/// Set favorite flag.
pub fn set_favorite(data_dir: &Path, project_path: &str, favorite: bool) -> Result<bool> {
    let mut reg = load_registry(data_dir)?;
    let ok = hub_registry::set_project_favorite(&mut reg, project_path, favorite);
    if ok {
        save_registry(data_dir, &reg)?;
    }
    Ok(ok)
}

/// Set project tags.
pub fn set_tags(data_dir: &Path, project_path: &str, tags: Value) -> Result<bool> {
    let mut reg = load_registry(data_dir)?;
    let ok = hub_registry::set_project_tags(&mut reg, project_path, tags);
    if ok {
        save_registry(data_dir, &reg)?;
    }
    Ok(ok)
}

/// Delete tags from all projects.
pub fn delete_tags(data_dir: &Path, tags: &[String]) -> Result<usize> {
    let mut reg = load_registry(data_dir)?;
    let changed = hub_registry::delete_project_tags(&mut reg, tags);
    if changed > 0 {
        save_registry(data_dir, &reg)?;
    }
    Ok(changed)
}

/// Clear deeplink info for project.
pub fn clear_deeplink_info(data_dir: &Path, project_path: &str) -> Result<bool> {
    let mut reg = load_registry(data_dir)?;
    let ok = hub_registry::clear_project_deeplink_info(&mut reg, project_path);
    if ok {
        save_registry(data_dir, &reg)?;
    }
    Ok(ok)
}

/// Get single project record from registry.
pub fn get_registry_project(data_dir: &Path, project_path: &str) -> Result<Option<Value>> {
    let reg = load_registry(data_dir)?;
    if let Some(rec) = reg.data.get(project_path) {
        let mut v = serde_json::to_value(rec)?;
        if let Some(obj) = v.as_object_mut() {
            obj.entry("path").or_insert(Value::String(project_path.to_string()));
        }
        Ok(Some(v))
    } else {
        Ok(None)
    }
}

/// Get recent projects sorted by lastModified desc.
pub fn get_recent_projects(data_dir: &Path) -> Result<Vec<Value>> {
    let reg = load_registry(data_dir)?;
    let mut items: Vec<(i64, Value)> = reg
        .data
        .iter()
        .map(|(path, rec)| {
            let ts = rec
                .last_modified
                .as_ref()
                .and_then(|v| v.as_i64().or_else(|| v.as_f64().map(|f| f as i64)))
                .unwrap_or(0);
            let mut v = serde_json::to_value(rec).unwrap_or(Value::Null);
            if let Some(obj) = v.as_object_mut() {
                obj.entry("path").or_insert(Value::String(path.clone()));
            }
            (ts, v)
        })
        .collect();
    items.sort_by(|a, b| b.0.cmp(&a.0));
    Ok(items.into_iter().map(|(_, v)| v).collect())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn list_projects_does_not_panic() {
        let _ = list_projects();
    }
}
