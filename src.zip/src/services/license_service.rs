//! License service (port of license-service / licenseEulaManager).

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct LicenseInfo {
    pub license_type: Option<String>,
    pub activated: bool,
    pub serial_masked: Option<String>,
}

/// Placeholder license service state.
pub fn current_license() -> LicenseInfo {
    LicenseInfo::default()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_license_is_inactive() {
        assert!(!current_license().activated);
    }
}
