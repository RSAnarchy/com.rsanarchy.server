//! Settings/preferences service (port of localSettings / projects-preferences / privacy-preferences).

use crate::config;
use crate::error::Result;
use serde_json::Value;

/// Load persisted user settings/preferences.
pub fn load() -> Result<Value> {
    config::load()
}

/// Save user settings/preferences.
pub fn save(value: &Value) -> Result<()> {
    config::save(value)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn load_returns_value() {
        let _ = load();
    }
}
