//! Authentication & token management service (port of AuthService / token managers).

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct AuthState {
    pub signed_in: bool,
    pub user_id: Option<String>,
    pub display_name: Option<String>,
}

pub fn current_state() -> AuthState {
    AuthState::default()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_auth_is_signed_out() {
        assert!(!current_state().signed_in);
    }
}
