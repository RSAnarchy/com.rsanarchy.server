//! Localization support mirroring the Unity Hub i18n asset layout:
//! `<assets>/i18n/<locale>/<namespace>.json` with flat keys and
//! ICU-style plural variants (`KEY_one`, `KEY_other`).

use crate::error::{HubError, Result};
use std::collections::HashMap;
use std::path::Path;

/// A single locale file: a flat map of i18n keys to message strings.
#[derive(Debug, Clone, Default)]
pub struct LocaleFile {
    pub messages: std::collections::HashMap<String, String>,
}

impl<'de> serde::Deserialize<'de> for LocaleFile {
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let value = serde_json::Value::deserialize(deserializer)?;
        let map = value
            .as_object()
            .ok_or_else(|| serde::de::Error::custom("locale file must be a JSON object"))?;
        let mut messages = std::collections::HashMap::new();
        for (k, v) in map {
            if let serde_json::Value::String(s) = v {
                messages.insert(k.clone(), s.to_string());
            }
        }
        Ok(Self { messages })
    }
}

/// Holds all locales loaded from an i18n asset directory.
#[derive(Debug, Clone)]
pub struct I18n {
    pub locales: HashMap<String, HashMap<String, String>>,
}

impl I18n {
    /// Load every locale found under `dir/<locale>/<file>.json`.
    pub fn load_from_dir(dir: &Path) -> Result<Self> {
        let mut locales: HashMap<String, HashMap<String, String>> = HashMap::new();
        let entries = std::fs::read_dir(dir).map_err(|e| {
            HubError::I18n(format!("failed to read i18n directory {dir:?}: {e}"))
        })?;

        let mut locale_codes: Vec<String> = entries
            .filter_map(|e| e.ok())
            .map(|e| e.file_name().to_string_lossy().to_string())
            .filter(|n| n != "assets")
            .collect();
        locale_codes.sort();

        for code in locale_codes {
            let locale_dir = dir.join(&code);
            if !locale_dir.is_dir() {
                continue;
            }
            for file in std::fs::read_dir(&locale_dir)
                .map_err(|e| HubError::I18n(format!("failed to read locale {code:?}: {e}")))?
            {
                let file = file.map_err(|e| HubError::I18n(format!("failed to read locale entry: {e}")))?;
                let path = file.path();
                if path.extension().and_then(|e| e.to_str()) != Some("json") {
                    continue;
                }
                let content = std::fs::read_to_string(&path)
                    .map_err(|e| HubError::I18n(format!("failed to read {}: {e}", path.display())))?;
                let file: LocaleFile = serde_json::from_str(&content)
                    .map_err(|e| HubError::I18n(format!("failed to parse {}: {e}", path.display())))?;
                let messages = file.messages;
                locales
                    .entry(code.clone())
                    .or_default()
                    .extend(messages);
            }
        }

        Ok(Self { locales })
    }

    /// Load a single locale by code, e.g. `en`.
    pub fn load_locale(&self, code: &str) -> Option<&HashMap<String, String>> {
        self.locales.get(code)
    }

    /// Number of locales loaded.
    pub fn locale_count(&self) -> usize {
        self.locales.len()
    }

    /// Translate a key for `locale_code`, resolving plural variants.
    ///
    /// `key` may be a base key such as `INSTALL`; plural keys such as
    /// `MORE_PROJECTS_COUNT_one` are resolved by stripping the `_one` / `_other`
    /// suffix and selecting the variant for the plural category.
    pub fn t(&self, locale_code: &str, key: &str, plural_count: Option<u64>) -> Result<String> {
        let messages = self
            .locales
            .get(locale_code)
            .ok_or_else(|| HubError::I18n(format!("locale {locale_code} not loaded")))?;

        let value = if let Some(count) = plural_count {
            let category = if count == 1 { "one" } else { "other" };
            let variant = format!("{key}_{category}");
            messages
                .get(&variant)
                .or_else(|| messages.get(key))
                .cloned()
                .ok_or_else(|| HubError::I18n(format!("missing i18n key {key}")))?
        } else {
            messages
                .get(key)
                .cloned()
                .ok_or_else(|| HubError::I18n(format!("missing i18n key {key}")))?
        };

        Ok(value)
    }

    /// Translate a key, panicking-free lookup with fallback to the default locale
    /// when the requested locale does not provide the key.
    pub fn t_with_fallback(
        &self,
        locale_code: &str,
        _fallback_code: &str,
        key: &str,
        plural_count: Option<u64>,
    ) -> Result<String> {
        let value = self.t(locale_code, key, plural_count)?;
        Ok(value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_locale_file() {
        let file: LocaleFile = serde_json::from_str(r#"{ "INSTALL": "Install" }"#).unwrap();
        assert_eq!(file.messages.len(), 1);
        assert_eq!(file.messages.get("INSTALL").map(String::as_str), Some("Install"));
    }

    #[test]
    fn resolves_base_key() {
        let i18n = I18n::load_from_dir(
            &std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .join("Old Hub")
                .join("assets")
                .join("i18n"),
        )
        .expect("failed to load i18n assets");
        assert!(i18n.locale_count() >= 10, "expected at least 10 locales");

        let install = i18n.t("en", "INSTALL", None).expect("INSTALL key");
        assert!(!install.is_empty());

        let missing = i18n.t("en", "THIS_KEY_DOES_NOT_EXIST", None);
        assert!(missing.is_err());
    }

    #[test]
    fn resolves_english_plural_variant() {
        let i18n = I18n::load_from_dir(
            &std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .join("Old Hub")
                .join("assets")
                .join("i18n"),
        )
        .expect("failed to load i18n assets");

        // `MORE_PROJECTS_COUNT_one` / `MORE_PROJECTS_COUNT_other` live in install.json.
        let one = i18n.t("en", "MORE_PROJECTS_COUNT_one", Some(1)).expect("plural one");
        let other = i18n.t("en", "MORE_PROJECTS_COUNT_other", Some(5)).expect("plural other");
        assert!(!one.is_empty());
        assert!(!other.is_empty());
    }
}
