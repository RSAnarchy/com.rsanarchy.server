//! Unity version parsing and comparison, mirroring the Hub's version handling.

use crate::error::{HubError, Result};
use std::cmp::Ordering;
use std::fmt;

/// A parsed Unity version such as `6000.1.3f1` or `2022.3.15f1`.
#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord)]
pub struct UnityVersion {
    /// Numerically compared release numbers, e.g. `[6000, 1, 3]`.
    pub numbers: Vec<u64>,
    /// Pre-release suffix: `None`, or `Some("f1")`, `Some("b1")`, `Some("a1")`, ...
    pub pre_release: Option<String>,
}

impl UnityVersion {
    /// Parse a Unity version string into its numeric + pre-release parts.
    pub fn parse(input: &str) -> Result<Self> {
        let input = input.trim();
        if input.is_empty() {
            return Err(HubError::InvalidVersion(input.to_string()));
        }

        let alpha_idx = input
            .as_bytes()
            .iter()
            .position(|b| b.is_ascii_alphabetic())
            .unwrap_or(input.len());
        let (nums_part, pre_part) = if alpha_idx == input.len() {
            (input.to_string(), None)
        } else {
            (input[..alpha_idx].to_string(), Some(input[alpha_idx..].to_string()))
        };

        let numbers: Vec<u64> = nums_part
            .split('.')
            .map(|n| {
                n.parse::<u64>()
                    .map_err(|_| HubError::InvalidVersion(input.to_string()))
            })
            .collect::<std::result::Result<Vec<u64>, HubError>>()?
            .into_iter()
            .filter(|n| !n.to_string().is_empty())
            .collect();

        if numbers.is_empty() {
            return Err(HubError::InvalidVersion(input.to_string()));
        }

        Ok(Self {
            numbers,
            pre_release: pre_part.filter(|p| !p.is_empty()),
        })
    }

    /// Compare two versions: numeric release first, then pre-release ordering.
    /// Pre-releases sort before the corresponding final release.
    pub fn compare(&self, other: &Self) -> Ordering {
        let ordering = self
            .numbers
            .iter()
            .zip(other.numbers.iter())
            .map(|(a, b)| a.cmp(b))
            .find(|c| *c != Ordering::Equal)
            .unwrap_or_else(|| self.numbers.len().cmp(&other.numbers.len()));
        if ordering != Ordering::Equal {
            return ordering;
        }
        match (&self.pre_release, &other.pre_release) {
            (None, None) => Ordering::Equal,
            (Some(_), None) => Ordering::Less,
            (None, Some(_)) => Ordering::Greater,
            (Some(a), Some(b)) => a.cmp(b),
        }
    }
}

impl fmt::Display for UnityVersion {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.numbers.iter().map(|n| n.to_string()).collect::<Vec<_>>().join("."))?;
        if let Some(pre) = &self.pre_release {
            write!(f, "{pre}")?;
        }
        Ok(())
    }
}

/// Convenience alias mirroring how the Hub refers to versions in logs/UI.
pub type EditorVersionRef<'a> = std::borrow::Cow<'a, str>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_unity_version_with_feature_suffix() {
        let v = UnityVersion::parse("6000.1.3f1").unwrap();
        assert_eq!(v.numbers, vec![6000, 1, 3]);
        assert_eq!(v.pre_release.as_deref(), Some("f1"));
        assert_eq!(v.to_string(), "6000.1.3f1");
    }

    #[test]
    fn parses_unity_version_with_two_components() {
        let v = UnityVersion::parse("2022.3").unwrap();
        assert_eq!(v.numbers, vec![2022, 3]);
        assert_eq!(v.pre_release, None);
    }

    #[test]
    fn rejects_empty_version() {
        assert!(UnityVersion::parse("").is_err());
    }

    #[test]
    fn compares_releases_numerically() {
        let a = UnityVersion::parse("6000.1.3f1").unwrap();
        let b = UnityVersion::parse("6000.1.10f1").unwrap();
        assert_eq!(a.compare(&b), Ordering::Less);

        let c = UnityVersion::parse("6000.2.0f1").unwrap();
        assert_eq!(a.compare(&c), Ordering::Less);
    }

    #[test]
    fn pre_release_sorts_before_final_release() {
        let final_v = UnityVersion::parse("6000.1.3").unwrap();
        let beta = UnityVersion::parse("6000.1.3b1").unwrap();
        assert_eq!(beta.compare(&final_v), Ordering::Less);
    }
}

