//! Scanning of local Unity projects.

use crate::error::Result;
use crate::models::ProjectEntry;
use std::path::{Path, PathBuf};

/// File that marks a folder as a Unity project.
pub const PROJECT_VERSION_FILE: &str = "ProjectVersion.txt";

/// Scan a root folder for Unity projects (folders containing `Assets/ProjectSettings/ProjectVersion.txt`).
pub fn scan_root(root: &Path) -> Result<Vec<ProjectEntry>> {
    let mut projects = Vec::new();
    for entry in std::fs::read_dir(root)
        .map_err(|e| crate::error::HubError::Io(e))?
        .flatten()
    {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let version_path = path.join("Assets").join("ProjectSettings").join("ProjectVersion.txt");
        if !version_path.is_file() {
            continue;
        }
        let editor_version = std::fs::read_to_string(&version_path)
            .ok()
            .and_then(|s| parse_project_version(&s));
        projects.push(ProjectEntry {
            name: entry.file_name().to_string_lossy().to_string(),
            path: path.to_string_lossy().to_string(),
            editor_version,
            is_favorite: false,
            is_offline: false,
        });
    }
    projects.sort_by(|a, b| a.path.cmp(&b.path));
    Ok(projects)
}

/// Discover Unity projects from well-known locations plus the working directory.
pub fn discover_projects() -> Result<Vec<ProjectEntry>> {
    let mut projects = Vec::new();
    let roots = default_project_roots();
    for root in roots {
        if !root.exists() {
            continue;
        }
        projects.extend(scan_root(&root)?);
    }
    projects.sort_by(|a, b| a.path.cmp(&b.path));
    Ok(projects)
}

pub fn default_project_roots() -> Vec<PathBuf> {
    let mut roots = Vec::new();
    if let Ok(dir) = std::env::var("UNITY_HUB_PROJECT_ROOT") {
        if !dir.is_empty() {
            roots.push(PathBuf::from(dir));
        }
    }
    if let Ok(dir) = std::env::var("UNITY_HUB_PROJECT_ROOTS") {
        for root in dir.split(';') {
            let root = root.trim();
            if !root.is_empty() {
                roots.push(PathBuf::from(root));
            }
        }
    }
    #[cfg(target_os = "windows")]
    {
        if let Some(home) = std::env::var_os("USERPROFILE") {
            let home = PathBuf::from(home);
            roots.push(home.join("Documents").join("Unity"));
        }
    }
    #[cfg(target_os = "windows")]
    {
        roots.push(PathBuf::from(r"C:\Projects"));
    }
    #[cfg(not(target_os = "windows"))]
    {
        roots.push(PathBuf::from("/opt/unity/projects"));
    }
    roots.push(std::env::current_dir().unwrap_or_default());
    roots
}

/// Parse `ProjectSettings/ProjectVersion.txt` content and return `m_EditorVersion`.
pub fn parse_project_version(content: &str) -> Option<String> {
    for line in content.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("m_EditorVersion:") {
            let v = rest.trim().to_string();
            if !v.is_empty() {
                return Some(v);
            }
        }
    }
    // Fallback: if it's a plain version string
    let trimmed = content.trim();
    if !trimmed.is_empty() && !trimmed.contains('\n') && !trimmed.contains(':') {
        return Some(trimmed.to_string());
    }
    None
}

/// Parse revision/changeset from `m_EditorVersionWithRevision` if present.
pub fn parse_project_revision(content: &str) -> Option<String> {
    for line in content.lines() {
        let line = line.trim();
        if let Some(rest) = line.strip_prefix("m_EditorVersionWithRevision:") {
            // e.g. "7000.0.0a16 (0745a91df592)"
            if let Some(start) = rest.find('(') {
                if let Some(end) = rest[start..].find(')') {
                    let rev = &rest[start + 1..start + end];
                    if !rev.is_empty() {
                        return Some(rev.to_string());
                    }
                }
            }
        }
    }
    None
}

/// Read editor version from a project's ProjectSettings/ProjectVersion.txt.
pub fn read_project_editor_version(project_path: &Path) -> Option<String> {
    let file = project_path.join("ProjectSettings").join(PROJECT_VERSION_FILE);
    let content = std::fs::read_to_string(file).ok()?;
    parse_project_version(&content)
}

/// Read project version info (editor version and revision/changeset) from ProjectSettings/ProjectVersion.txt.
pub fn read_project_version_info(project_path: &Path) -> Option<(Option<String>, Option<String>)> {
    let file = project_path.join("ProjectSettings").join(PROJECT_VERSION_FILE);
    let content = std::fs::read_to_string(file).ok()?;
    Some((parse_project_version(&content), parse_project_revision(&content)))
}

/// Check if path looks like a Unity project (has ProjectSettings/ProjectVersion.txt).
pub fn is_unity_project(project_path: &Path) -> bool {
    project_path.join("ProjectSettings").join(PROJECT_VERSION_FILE).is_file()
}

/// Resolve a template name/path for create: if it looks like a .tgz file name, resolve under editor templates dir.
pub fn resolve_template_path(editor_install_path: &Path, template: &str) -> Option<std::path::PathBuf> {
    let tpl_dir = editor_install_path
        .join("Editor")
        .join("Data")
        .join("Resources")
        .join("PackageManager")
        .join("ProjectTemplates");
    let direct = tpl_dir.join(template);
    if direct.is_file() {
        return Some(direct);
    }
    // allow passing full path
    let as_path = std::path::PathBuf::from(template);
    if as_path.is_file() {
        return Some(as_path);
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn discovers_project_with_assets_folder() {
        let root = std::env::temp_dir().join("unity-hub-proj-test");
        let project_dir = root.join("MyProject");
        std::fs::create_dir_all(project_dir.join("Assets").join("ProjectSettings")).unwrap();
        std::fs::write(
            project_dir.join("Assets").join("ProjectSettings").join("ProjectVersion.txt"),
            "m_EditorVersion: 2022.3.15f1\nm_EditorVersionWithRevision: 2022.3.15f1 (abc1234)\n",
        )
        .unwrap();
        let found = scan_root(&root).unwrap();
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].name, "MyProject");
        assert_eq!(found[0].editor_version.as_deref(), Some("2022.3.15f1"));
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn parses_project_version_formats() {
        assert_eq!(parse_project_version("m_EditorVersion: 7000.0.0a16\n"), Some("7000.0.0a16".to_string()));
        assert_eq!(parse_project_version("2022.3.15f1"), Some("2022.3.15f1".to_string()));
        assert_eq!(parse_project_revision("m_EditorVersionWithRevision: 7000.0.0a16 (0745a91df592)\n"), Some("0745a91df592".to_string()));
    }

    #[test]
    fn ignores_non_project_folders() {
        let root = std::env::temp_dir().join("unity-hub-proj-test-ignore");
        std::fs::create_dir_all(&root).unwrap();
        let found = scan_root(&root).unwrap();
        assert!(found.is_empty());
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn reads_project_version_and_resolves_template_path() {
        let root = std::env::temp_dir().join(format!(
            "unity-hub-proj-read-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let proj = root.join("P");
        std::fs::create_dir_all(proj.join("ProjectSettings")).unwrap();
        std::fs::write(
            proj.join("ProjectSettings").join("ProjectVersion.txt"),
            "m_EditorVersion: 6000.0.23f1\nm_EditorVersionWithRevision: 6000.0.23f1 (abc123)\n",
        )
        .unwrap();
        assert!(is_unity_project(&proj));
        assert_eq!(read_project_editor_version(&proj).as_deref(), Some("6000.0.23f1"));
        let info = read_project_version_info(&proj).unwrap();
        assert_eq!(info.0.as_deref(), Some("6000.0.23f1"));
        assert_eq!(info.1.as_deref(), Some("abc123"));

        let install = root.join("EditorInstall");
        let tpl = install
            .join("Editor")
            .join("Data")
            .join("Resources")
            .join("PackageManager")
            .join("ProjectTemplates");
        std::fs::create_dir_all(&tpl).unwrap();
        let tpl_file = tpl.join("com.unity.template.3d.tgz");
        std::fs::write(&tpl_file, b"x").unwrap();
        assert_eq!(
            resolve_template_path(&install, "com.unity.template.3d.tgz"),
            Some(tpl_file)
        );
        assert!(resolve_template_path(&install, "missing.tgz").is_none());
        let _ = std::fs::remove_dir_all(&root);
    }
}