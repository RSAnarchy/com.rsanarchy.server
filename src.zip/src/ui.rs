//! Terminal UI helpers (rendered output of the rewrite).

use crate::models::{EditorInstall, ProjectEntry};

/// Render the installed editors list as text.
pub fn render_editors(installs: &[EditorInstall]) -> String {
    let mut out = String::new();
    for install in installs {
        out.push_str(&format!("Unity {}\n", install.version));
    }
    out
}

/// Render the discovered projects list as text.
pub fn render_projects(projects: &[ProjectEntry]) -> String {
    let mut out = String::new();
    for project in projects {
        out.push_str(&format!("{}\n", project.path));
    }
    out
}
