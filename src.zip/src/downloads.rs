//! Download pipeline helpers (networked HTTP download with install-state progress updates).

use crate::error::Result;
use std::io::{Read, Write};
use std::path::Path;

/// Download a URL to a file path, updating install-state download progress.
/// Best-effort Hub-like state transitions: queued/downloading -> complete|failed.
pub fn download_to_file_with_state(
    data_dir: &Path,
    uid: &str,
    url: &str,
    dest_path: &Path,
    expected_bytes: Option<i64>,
) -> Result<serde_json::Value> {
    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| crate::error::HubError::Other(format!("tokio runtime: {e}")))?;
    rt.block_on(async move {
        download_to_file_with_state_async(data_dir, uid, url, dest_path, expected_bytes).await
    })
}

async fn download_to_file_with_state_async(
    data_dir: &Path,
    uid: &str,
    url: &str,
    dest_path: &Path,
    expected_bytes: Option<i64>,
) -> Result<serde_json::Value> {
    let now0 = crate::hub_registry::now_millis();
    let _ = crate::install_state::set_download_state(data_dir, uid, "downloading", Some(0), expected_bytes, None, None, now0);

    let client = reqwest::Client::builder()
        .build()
        .map_err(|e| crate::error::HubError::Other(format!("http client: {e}")))?;

    let mut resp = match client.get(url).send().await {
        Ok(r) => r,
        Err(e) => {
            let now = crate::hub_registry::now_millis();
            let msg = e.to_string();
            let _ = crate::install_state::set_download_state(data_dir, uid, "failed", None, expected_bytes, Some("DOWNLOAD_ERROR"), Some(&msg), now);
            return Ok(serde_json::json!({"ok":false,"uid":uid,"url":url,"dest":dest_path.to_string_lossy(),"error":msg,"state":"failed"}));
        }
    };
    if !resp.status().is_success() {
        let now = crate::hub_registry::now_millis();
        let msg = format!("http status {}", resp.status());
        let _ = crate::install_state::set_download_state(data_dir, uid, "failed", None, expected_bytes, Some("HTTP_STATUS"), Some(&msg), now);
        return Ok(serde_json::json!({"ok":false,"uid":uid,"url":url,"dest":dest_path.to_string_lossy(),"error":msg,"state":"failed"}));
    }
    let total = resp.content_length().map(|v| v as i64).or(expected_bytes);
    if let Some(parent) = dest_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let mut file = match std::fs::File::create(dest_path) {
        Ok(f) => f,
        Err(e) => {
            let now = crate::hub_registry::now_millis();
            let msg = e.to_string();
            let _ = crate::install_state::set_download_state(data_dir, uid, "failed", None, total, Some("IO_ERROR"), Some(&msg), now);
            return Ok(serde_json::json!({"ok":false,"uid":uid,"url":url,"dest":dest_path.to_string_lossy(),"error":msg,"state":"failed"}));
        }
    };
    let mut done: i64 = 0;
    let mut last_update = std::time::Instant::now();
    loop {
        let chunk = match resp.chunk().await {
            Ok(Some(c)) => c,
            Ok(None) => break,
            Err(e) => {
                let now = crate::hub_registry::now_millis();
                let msg = e.to_string();
                let _ = crate::install_state::set_download_state(data_dir, uid, "failed", Some(done), total, Some("STREAM_ERROR"), Some(&msg), now);
                return Ok(serde_json::json!({"ok":false,"uid":uid,"url":url,"dest":dest_path.to_string_lossy(),"bytesDone":done,"bytesTotal":total,"error":msg,"state":"failed"}));
            }
        };
        if let Err(e) = file.write_all(&chunk) {
            let now = crate::hub_registry::now_millis();
            let msg = e.to_string();
            let _ = crate::install_state::set_download_state(data_dir, uid, "failed", Some(done), total, Some("WRITE_ERROR"), Some(&msg), now);
            return Ok(serde_json::json!({"ok":false,"uid":uid,"url":url,"dest":dest_path.to_string_lossy(),"bytesDone":done,"bytesTotal":total,"error":msg,"state":"failed"}));
        }
        done += chunk.len() as i64;
        if last_update.elapsed().as_millis() >= 50 {
            let now = crate::hub_registry::now_millis();
            let _ = crate::install_state::set_download_state(data_dir, uid, "downloading", Some(done), total, None, None, now);
            last_update = std::time::Instant::now();
        }
    }
    let _ = file.flush();
    let now = crate::hub_registry::now_millis();
    let _ = crate::install_state::set_download_state(data_dir, uid, "complete", Some(done), total, None, None, now);
    Ok(serde_json::json!({
        "ok": true,
        "uid": uid,
        "url": url,
        "dest": dest_path.to_string_lossy(),
        "bytesDone": done,
        "bytesTotal": total,
        "state": "complete"
    }))
}

fn b64_decode_std(s: &str) -> Option<Vec<u8>> {
    // Minimal standard base64 decoder (A-Za-z0-9+/ with = padding)
    let mut out = Vec::new();
    let mut buf: u32 = 0;
    let mut bits: u32 = 0;
    for b in s.bytes() {
        let val = match b {
            b'A'..=b'Z' => (b - b'A') as u32,
            b'a'..=b'z' => (b - b'a' + 26) as u32,
            b'0'..=b'9' => (b - b'0' + 52) as u32,
            b'+' => 62,
            b'/' => 63,
            b'=' => break,
            b'\r' | b'\n' | b' ' | b'\t' => continue,
            _ => return None,
        };
        buf = (buf << 6) | val;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push(((buf >> bits) & 0xFF) as u8);
        }
    }
    Some(out)
}

fn md5_compute(data: &[u8]) -> [u8; 16] {
    // RFC 1321 MD5
    fn f(x: u32, y: u32, z: u32) -> u32 { (x & y) | ((!x) & z) }
    fn g(x: u32, y: u32, z: u32) -> u32 { (x & z) | (y & (!z)) }
    fn h(x: u32, y: u32, z: u32) -> u32 { x ^ y ^ z }
    fn i(x: u32, y: u32, z: u32) -> u32 { y ^ (x | (!z)) }
    fn rotl(x: u32, n: u32) -> u32 { x.rotate_left(n) }
    let s: [u32; 64] = [
        7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,
        5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
        4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,
        6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21,
    ];
    let k: [u32; 64] = [
        0xd76aa478,0xe8c7b756,0x242070db,0xc1bdceee,0xf57c0faf,0x4787c62a,0xa8304613,0xfd469501,
        0x698098d8,0x8b44f7af,0xffff5bb1,0x895cd7be,0x6b901122,0xfd987193,0xa679438e,0x49b40821,
        0xf61e2562,0xc040b340,0x265e5a51,0xe9b6c7aa,0xd62f105d,0x02441453,0xd8a1e681,0xe7d3fbc8,
        0x21e1cde6,0xc33707d6,0xf4d50d87,0x455a14ed,0xa9e3e905,0xfcefa3f8,0x676f02d9,0x8d2a4c8a,
        0xfffa3942,0x8771f681,0x6d9d6122,0xfde5380c,0xa4beea44,0x4bdecfa9,0xf6bb4b60,0xbebfbc70,
        0x289b7ec6,0xeaa127fa,0xd4ef3085,0x04881d05,0xd9d4d039,0xe6db99e5,0x1fa27cf8,0xc4ac5665,
        0xf4292244,0x432aff97,0xab9423a7,0xfc93a039,0x655b59c3,0x8f0ccc92,0xffeff47d,0x85845dd1,
        0x6fa87e4f,0xfe2ce6e0,0xa3014314,0x4e0811a1,0xf7537e82,0xbd3af235,0x2ad7d2bb,0xeb86d391,
    ];
    let mut a0: u32 = 0x67452301;
    let mut b0: u32 = 0xefcdab89;
    let mut c0: u32 = 0x98badcfe;
    let mut d0: u32 = 0x10325476;
    // padding
    let bit_len = (data.len() as u64) * 8;
    let mut msg = data.to_vec();
    msg.push(0x80);
    while (msg.len() % 64) != 56 { msg.push(0); }
    msg.extend_from_slice(&bit_len.to_le_bytes());
    for chunk in msg.chunks(64) {
        let mut m = [0u32; 16];
        for j in 0..16 {
            m[j] = u32::from_le_bytes([chunk[j*4], chunk[j*4+1], chunk[j*4+2], chunk[j*4+3]]);
        }
        let (mut a, mut b, mut c, mut d) = (a0, b0, c0, d0);
        for j in 0..64 {
            let (mut fval, gidx) = if j < 16 {
                (f(b,c,d), j)
            } else if j < 32 {
                (g(b,c,d), (5*j + 1) % 16)
            } else if j < 48 {
                (h(b,c,d), (3*j + 5) % 16)
            } else {
                (i(b,c,d), (7*j) % 16)
            };
            fval = fval.wrapping_add(a).wrapping_add(k[j]).wrapping_add(m[gidx]);
            a = d;
            d = c;
            c = b;
            b = b.wrapping_add(rotl(fval, s[j]));
        }
        a0 = a0.wrapping_add(a);
        b0 = b0.wrapping_add(b);
        c0 = c0.wrapping_add(c);
        d0 = d0.wrapping_add(d);
    }
    let mut out = [0u8; 16];
    out[0..4].copy_from_slice(&a0.to_le_bytes());
    out[4..8].copy_from_slice(&b0.to_le_bytes());
    out[8..12].copy_from_slice(&c0.to_le_bytes());
    out[12..16].copy_from_slice(&d0.to_le_bytes());
    out
}

fn hex_encode(bytes: &[u8]) -> String {
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes {
        s.push_str(&format!("{:02x}", b));
    }
    s
}

/// Extract a ZIP archive to destination directory (Windows: uses PowerShell Expand-Archive).
pub fn extract_zip(zip_path: &Path, dest_dir: &Path) -> Result<serde_json::Value> {
    if let Some(parent) = dest_dir.parent() {
        let _ = std::fs::create_dir_all(parent);
    }
    std::fs::create_dir_all(dest_dir)?;
    // Use PowerShell Expand-Archive on Windows for compatibility without adding zip crate dependency.
    #[cfg(windows)]
    {
        let status = std::process::Command::new("powershell")
            .args([
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                &format!(
                    "Expand-Archive -LiteralPath '{}' -DestinationPath '{}' -Force",
                    zip_path.to_string_lossy().replace('\'', "''"),
                    dest_dir.to_string_lossy().replace('\'', "''")
                ),
            ])
            .status();
        match status {
            Ok(s) if s.success() => Ok(serde_json::json!({"ok":true,"method":"Expand-Archive","zip":zip_path.to_string_lossy(),"dest":dest_dir.to_string_lossy()})),
            Ok(s) => Ok(serde_json::json!({"ok":false,"method":"Expand-Archive","zip":zip_path.to_string_lossy(),"dest":dest_dir.to_string_lossy(),"error":format!("exit status {s}")})),
            Err(e) => Ok(serde_json::json!({"ok":false,"method":"Expand-Archive","zip":zip_path.to_string_lossy(),"dest":dest_dir.to_string_lossy(),"error":e.to_string()})),
        }
    }
    #[cfg(not(windows))]
    {
        let status = std::process::Command::new("unzip")
            .args(["-o", &zip_path.to_string_lossy(), "-d", &dest_dir.to_string_lossy()])
            .status();
        match status {
            Ok(s) if s.success() => Ok(serde_json::json!({"ok":true,"method":"unzip","zip":zip_path.to_string_lossy(),"dest":dest_dir.to_string_lossy()})),
            Ok(s) => Ok(serde_json::json!({"ok":false,"method":"unzip","zip":zip_path.to_string_lossy(),"dest":dest_dir.to_string_lossy(),"error":format!("exit status {s}")})),
            Err(e) => Ok(serde_json::json!({"ok":false,"method":"unzip","zip":zip_path.to_string_lossy(),"dest":dest_dir.to_string_lossy(),"error":e.to_string()})),
        }
    }
}

/// Verify file integrity against a Hub-style integrity string when supported.
/// Supported: `sha256-<base64|hex>`, `sha384-<base64|hex>`, `sha512-<base64|hex>`.
/// Returns (supported, matched, details).
pub fn verify_integrity(path: &Path, integrity: &str) -> Result<serde_json::Value> {
    let integrity = integrity.trim();
    if integrity.is_empty() {
        return Ok(serde_json::json!({"supported": false, "matched": false, "reason": "empty integrity"}));
    }
    let mut file = std::fs::File::open(path)?;
    let mut data = Vec::new();
    file.read_to_end(&mut data)?;
    let (algo, rest) = if let Some(r) = integrity.strip_prefix("sha256-") { ("sha256", r) }
    else if let Some(r) = integrity.strip_prefix("sha384-") { ("sha384", r) }
    else if let Some(r) = integrity.strip_prefix("sha512-") { ("sha512", r) }
    else if let Some(r) = integrity.strip_prefix("md5-") { ("md5", r) }
    else { ("", integrity) };
    if algo.is_empty() {
        return Ok(serde_json::json!({"supported": false, "matched": false, "reason": "unsupported or unknown integrity format", "integrity": integrity}));
    }
    use sha2::Digest;
    let expected_bytes: Option<Vec<u8>> = if rest.chars().all(|c| c.is_ascii_hexdigit()) && (rest.len() % 2 == 0) && (algo != "md5" || rest.len() == 32) {
        // hex (common for md5; also accept hex for sha*)
        let mut out = Vec::with_capacity(rest.len()/2);
        let bytes = rest.as_bytes();
        let mut i = 0;
        while i + 1 < bytes.len() {
            if let Ok(v) = u8::from_str_radix(std::str::from_utf8(&bytes[i..i+2]).unwrap_or(""), 16) {
                out.push(v);
            } else { return Ok(serde_json::json!({"supported": false, "matched": false, "reason": "invalid hex integrity"})); }
            i += 2;
        }
        Some(out)
    } else {
        b64_decode_std(rest)
    };
    let expected_bytes = match expected_bytes {
        Some(b) if !b.is_empty() => b,
        _ => return Ok(serde_json::json!({"supported": false, "matched": false, "reason": "could not decode integrity value", "algorithm": algo})),
    };
    let actual: Vec<u8> = match algo {
        "sha256" => { let mut h = sha2::Sha256::new(); h.update(&data); h.finalize().to_vec() }
        "sha384" => { let mut h = sha2::Sha384::new(); h.update(&data); h.finalize().to_vec() }
        "sha512" => { let mut h = sha2::Sha512::new(); h.update(&data); h.finalize().to_vec() }
        "md5" => md5_compute(&data).to_vec(),
        _ => Vec::new(),
    };
    let matched = actual == expected_bytes;
    Ok(serde_json::json!({
        "supported": true,
        "matched": matched,
        "algorithm": algo,
        "expectedHex": hex_encode(&expected_bytes),
        "actualHex": hex_encode(&actual),
        "size": data.len()
    }))
}
