//! Checksum verification against the Hub's `checksums.json` manifest.
//!
//! The manifest is a JSON array of `[path, sha512hex]` pairs covering shipped files.

use crate::error::{HubError, Result};
use serde::Deserialize;
use std::collections::BTreeMap;
use std::path::Path;

#[derive(Debug, Clone, Deserialize)]
#[serde(untagged)]
enum Entry {
    Pair(String, String),
}

/// Parsed checksum manifest: relative path -> expected hash (hex string).
#[derive(Debug, Clone, Default)]
pub struct Checksums {
    pub entries: BTreeMap<String, String>,
}

impl Checksums {
    pub fn load(path: &Path) -> Result<Self> {
        let content = std::fs::read_to_string(path)?;
        let raw: Vec<Entry> = serde_json::from_str(&content)?;
        let mut entries = BTreeMap::new();
        for entry in raw {
            let Entry::Pair(path, hash) = entry;
            entries.insert(path, hash);
        }
        Ok(Self { entries })
    }

    /// Look up the expected hash for a file path as recorded in the manifest.
    pub fn get(&self, path: &str) -> Option<&str> {
        self.entries.get(path).map(|s| s.as_str())
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

/// Verify that `unity.exe` has been preserved byte-for-byte in the rewrite.
/// Returns the SHA-512 hash of the CLI binary when both copies match.
pub fn verify_unity_cli_preserved(old_hub_root: &Path, runtime_root: &Path) -> Result<String> {
    let old_hash = sha512_file(&old_hub_root.join("unity.exe"))?;
    let runtime_hash = sha512_file(&runtime_root.join("unity.exe"))?;
    if old_hash != runtime_hash {
        return Err(HubError::I18n(format!(
            "unity.exe was modified: expected {old_hash}, got {runtime_hash}"
        )));
    }
    Ok(old_hash)
}

fn sha512_file(path: &Path) -> Result<String> {
    use sha2::{Digest, Sha512};
    let mut file = std::fs::File::open(path)?;
    let mut hasher = Sha512::new();
    std::io::copy(&mut file, &mut hasher)?;
    let hash = hasher.finalize();
    Ok(format!("{:x}", hash))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_checksums_manifest() {
        let manifest = r#"[["assets/icons/x.svg","abc123"],["unity.exe","def456"]]"#;
        let raw: Vec<Entry> = serde_json::from_str(manifest).unwrap();
        assert_eq!(raw.len(), 2);
        let mut cs = Checksums::default();
        for e in raw {
            let Entry::Pair(p, h) = e;
            cs.entries.insert(p, h);
        }
        assert_eq!(cs.get("unity.exe"), Some("def456"));
        assert_eq!(cs.len(), 2);
    }

    #[test]
    fn loads_old_hub_checksums() {
        let root = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("Old Hub");
        let cs = Checksums::load(&root.join("checksums.json")).unwrap();
        assert_eq!(cs.len(), 440, "expected 440 asset checksums");
        assert!(cs.get("assets/i18n/en/common.json").is_some());
        assert!(cs.get("assets/images/welcome-art.jpg").is_some());
    }

    #[test]
    fn unity_cli_kept_as_is() {
        let base = std::path::PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let hash = verify_unity_cli_preserved(&base.join("Old Hub"), &base.join("runtime")).unwrap();
        assert_eq!(hash.len(), 128, "SHA-512 hex should be 128 chars");
        assert_eq!(
            hash,
            "90fd5171be412e265564d3a0896b611402f7189f9b82a1e8c88b753e2ab08a3e3ffc64715ffb14327bc03f13e035394bb165676d94081db1dcc1c8183887ad6c"
        );
    }
}
