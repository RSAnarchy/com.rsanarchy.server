//! Scanning of installed Unity Editors on disk.

use crate::error::Result;
use crate::models::EditorInstall;
use std::path::{Path, PathBuf};

/// Name of the folder that holds an Editor's executable inside an install dir.
pub const EDITOR_FOLDER: &str = "Editor";

/// Well-known roots that may contain Unity Editor installs.
pub fn editor_roots() -> Vec<PathBuf> {
    let mut roots = Vec::new();
    if let Ok(dir) = std::env::var("UNITY_HUB_EDITOR_ROOT") {
        if !dir.is_empty() {
            roots.push(PathBuf::from(dir));
        }
    }
    if let Ok(dir) = std::env::var("UNITY_HUB_EDITOR_ROOTS") {
        for root in dir.split(';') {
            let root = root.trim();
            if !root.is_empty() {
                roots.push(PathBuf::from(root));
            }
        }
    }
    if let Ok(dir) = std::env::var("UNITY_EDITOR_INSTALL_ROOT") {
        if !dir.is_empty() {
            roots.push(PathBuf::from(dir));
        }
    }
    if roots.is_empty() {
        #[cfg(target_os = "windows")]
        {
            roots.push(PathBuf::from(
                r"C:\Program Files\Unity\Hub\Editor",
            ));
        }
        #[cfg(not(target_os = "windows"))]
        {
            roots.push(PathBuf::from("/opt/unity/Hub/Editor"));
        }
    }
    roots
}

/// Scan a single install root for installed Editor versions.
pub fn scan_root(root: &Path) -> Result<Vec<EditorInstall>> {
    let entries = std::fs::read_dir(root)
        .map_err(|e| crate::error::HubError::Io(e))?;
    let mut installs = Vec::new();
    for entry in entries.flatten() {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }
        let version = entry.file_name().to_string_lossy().to_string();
        let install = EditorInstall {
            version: version.clone(),
            install_name: version.clone(),
            install_path: path.to_string_lossy().to_string(),
            install_root: root.to_string_lossy().to_string(),
            is_64_bit: path.join(EDITOR_FOLDER).join("Unity.exe").is_file(),
            size_on_disk: dir_size(&path),
        };
        if install.is_64_bit && looks_like_editor_version(&version) {
            installs.push(install);
        }
    }
    installs.sort_by(|a, b| a.version.cmp(&b.version));
    Ok(installs)
}

/// Collect installs from all configured roots.
pub fn installed_editors() -> Result<Vec<EditorInstall>> {
    let mut installs = Vec::new();
    for root in editor_roots() {
        installs.extend(scan_root(&root)?);
    }
    installs.sort_by(|a, b| a.version.cmp(&b.version));
    Ok(installs)
}

/// Path to Unity editor executable within an install directory (Windows Hub layout).
pub fn editor_executable_path(install_path: &Path) -> PathBuf {
    #[cfg(target_os = "windows")]
    {
        install_path.join(EDITOR_FOLDER).join("Unity.exe")
    }
    #[cfg(not(target_os = "windows"))]
    {
        install_path.join(EDITOR_FOLDER).join("Unity")
    }
}

/// Find installed editor by version string (exact install/version folder name match).
pub fn find_installed_editor(version: &str) -> Result<Option<EditorInstall>> {
    let installs = installed_editors()?;
    Ok(installs.into_iter().find(|e| e.version == version || e.install_name == version))
}

/// List project template .tgz files for an editor install path.
pub fn list_editor_templates(install_path: &Path) -> Result<Vec<String>> {
    let templates_dir = install_path
        .join("Editor")
        .join("Data")
        .join("Resources")
        .join("PackageManager")
        .join("ProjectTemplates");
    if !templates_dir.is_dir() {
        return Ok(Vec::new());
    }
    let mut out = Vec::new();
    for entry in std::fs::read_dir(&templates_dir).map_err(crate::error::HubError::Io)?.flatten() {
        let p = entry.path();
        if p.extension().and_then(|s| s.to_str()) == Some("tgz") {
            if let Some(name) = p.file_name().and_then(|s| s.to_str()) {
                out.push(name.to_string());
            }
        }
    }
    out.sort();
    Ok(out)
}

/// Build command args for opening a project (3.22 EditorApp.openProject shape).
pub fn build_open_project_args(project_path: &str, extra_args: &[String]) -> Vec<String> {
    let mut args = vec![
        "-projectpath".to_string(),
        project_path.to_string(),
        "-acceptSoftwareTermsForThisRunOnly".to_string(),
    ];
    args.extend(extra_args.iter().cloned());
    args
}

/// Build command args for creating a project (3.22 EditorApp.createProject shape, core args).
pub fn build_create_project_args(
    project_path: &str,
    template: &str,
    cloud_organization: Option<&str>,
    cloud_project: Option<&str>,
) -> Vec<String> {
    let template_key = if template == "0" || template == "1" { "projectTemplate" } else { "cloneFromTemplate" };
    let mut args = vec![
        "-createproject".to_string(),
        project_path.to_string(),
        format!("-{}", template_key),
        template.to_string(),
    ];
    if let Some(org) = cloud_organization {
        args.push("-cloudOrganization".to_string());
        args.push(org.to_string());
    }
    if let Some(cp) = cloud_project {
        args.push("-cloudProject".to_string());
        args.push(cp.to_string());
    }
    args
}

/// Read editor modules metadata from `<install_path>/modules.json` (Hub/installer manifest).
/// Returns the parsed JSON value (usually an array of module objects) if present.
pub fn read_editor_modules(install_path: &Path) -> Result<Option<serde_json::Value>> {
    let path = install_path.join("modules.json");
    if !path.is_file() {
        return Ok(None);
    }
    let content = std::fs::read_to_string(&path)?;
    let trimmed = content.trim_start_matches('\u{feff}');
    let v: serde_json::Value = serde_json::from_str(trimmed)?;
    Ok(Some(v))
}

/// Resolve editor install path from version or path, then read modules.json if available.
pub fn get_editor_modules(editor: &str) -> Result<(PathBuf, Option<serde_json::Value>)> {
    let install_path = if Path::new(editor).exists() {
        PathBuf::from(editor)
    } else if let Some(inst) = find_installed_editor(editor)? {
        PathBuf::from(inst.install_path)
    } else {
        return Err(crate::error::HubError::Other(format!("editor not found: {editor}")));
    };
    let modules = read_editor_modules(&install_path)?;
    Ok((install_path, modules))
}

fn looks_like_editor_version(name: &str) -> bool {
    crate::versions::UnityVersion::parse(name).is_ok()
}

fn dir_size(path: &Path) -> u64 {
    let mut total = 0u64;
    if let Ok(entries) = std::fs::read_dir(path) {
        for entry in entries.flatten() {
            let p = entry.path();
            if p.is_dir() {
                total += dir_size(&p);
            } else if let Ok(meta) = std::fs::metadata(&p) {
                total += meta.len();
            }
        }
    }
    total
}

#[cfg(test)]
mod tests {
    use super::*;

    fn unique_temp_dir(label: &str) -> PathBuf {
        let dir = std::env::temp_dir().join(format!(
            "unity-hub-test-{}-{}-{}",
            label,
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir_all(&dir).unwrap();
        dir
    }

    #[test]
    fn scans_install_root_for_editor_version_dirs() {
        let root = unique_temp_dir("installs");
        let version_dir = root.join("6000.1.3f1");
        std::fs::create_dir_all(version_dir.join(EDITOR_FOLDER)).unwrap();
        std::fs::write(version_dir.join(EDITOR_FOLDER).join("Unity.exe"), b"").unwrap();

        let found = scan_root(&root).unwrap();
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].version, "6000.1.3f1");
        assert!(found[0].is_64_bit);

        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn ignores_non_version_directories() {
        let root = unique_temp_dir("installs-ignore");
        std::fs::create_dir_all(root.join("not-a-version")).unwrap();
        let found = scan_root(&root).unwrap();
        assert!(found.is_empty());
        let _ = std::fs::remove_dir_all(&root);
    }

    #[test]
    fn lists_editor_templates_and_builds_args() {
        let root = unique_temp_dir("templates");
        let install = root.join("6000.3.15f1");
        let tpl = install.join("Editor").join("Data").join("Resources").join("PackageManager").join("ProjectTemplates");
        std::fs::create_dir_all(&tpl).unwrap();
        std::fs::write(tpl.join("com.unity.template.3d-cross-platform.tgz"), b"x").unwrap();
        std::fs::write(tpl.join("com.unity.template.2d.tgz"), b"x").unwrap();

        let templates = list_editor_templates(&install).unwrap();
        assert_eq!(templates, vec!["com.unity.template.2d.tgz", "com.unity.template.3d-cross-platform.tgz"]);

        let open = build_open_project_args("C:\\P", &vec!["-foo".to_string()]);
        assert_eq!(open, vec!["-projectpath", "C:\\P", "-acceptSoftwareTermsForThisRunOnly", "-foo"]);
        let create = build_create_project_args("C:\\P", "com.unity.template.3d.tgz", Some("org1"), Some("cp1"));
        assert_eq!(create[0], "-createproject");
        assert!(create.contains(&"-cloneFromTemplate".to_string()));
        assert!(create.contains(&"-cloudOrganization".to_string()));

        let _ = std::fs::remove_dir_all(&root);
    }
}
