# Unity Hub 3.22 (Electron) → Rust Port

**Objective:** Port Unity Hub 3.22.6 (Electron) to Rust with 1:1 functionality, using Hub 4.0 architectural ideas where appropriate.

## Source (extracted for analysis)
- Install: `C:\Program Files\Unity Hub 3.22 electron`
- Extracted app: `electron-hub-3.22/app/` (from `resources/app.asar`, 3410 files)
  - `.vite/build/` — main process bundles (services, managers, bootstrap, IPC)
  - `.vite/renderer/` — `main_window`, `bug_reporter_window`
  - `images/`, `node_modules/`, `package.json` (name `unity-hub`, version `3.22.6`, main `.vite/build/index.js`)
- CLI (preserved as-is): `runtime/unity-hub-3.22.exe` copied from 3.22 `resources/unity.exe` (SHA-256 `E42CA022CCEF31D86DD1748213622E5B27E310EFAA6FC16F19426B739C84AB7D`, 28,111,840 bytes)

## Rust port workspace
- Crate: `unity-hub` (Rust 2024), targeting 3.22.6 functionality parity
- Modules: domain models, version handling, i18n/assets support, editor/project discovery, config/storage (SQLite), checksums, CLI
- Preserves existing 4.0-derived foundations where reusable; evolving toward 3.22 service parity

## Status
In progress — analyzing 3.22 bundle and implementing Rust service/domain parity. See test and CLI output for verified evidence.
