# Unity Hub 3.22.6 (Electron) → Rust Port

**Objective:** Port Unity Hub 3.22.6 (Electron) to Rust with 1:1 functionality, using Hub 4.0 architectural ideas where appropriate.

## Source (extracted for analysis)
- Install: `C:\Program Files\Unity Hub 3.22 electron`
- Extracted app: `electron-hub-3.22/app/` (from `resources/app.asar`, 3410 files)
  - `.vite/build/` — main process bundles (541 modules: services, managers, bootstrap, IPC)
  - `.vite/renderer/` — `main_window`, `bug_reporter_window` (48 files)
  - `package.json`: `unity-hub` v`3.22.6`, main `.vite/build/index.js`
- CLI preserved as-is: `runtime/unity-hub-3.22.exe` (copied from 3.22 `resources/unity.exe`, 28,111,840 bytes, SHA-256 `E42CA022CCEF31D86DD1748213622E5B27E310EFAA6FC16F19426B739C84AB7D`)

## Rust port workspace
- Crate: `unity-hub` v`3.22.6-port.0` (Rust 2024)
- Stack: `serde`/`serde_json`, `tokio`, `reqwest`+rustls, `rusqlite` (bundled), `clap`, `sha2`
- Modules: `error`, `models`, `versions`, `i18n`, `installs`, `projects`, `config`, `storage`, `checksums`, `updates`, `commands`, `ui`, `app_inventory`, `services/*`

## Ported service domains (Rust implementations/stubs mapped to 3.22)
- `services::hub_app` — reads extracted 3.22 app metadata
- `services::editor_inventory` — editor discovery/lookup (EditorInventoryService/editor-manager)
- `services::local_project` — project discovery/lookup (LocalProjectService/project-service)
- `services::installation_manager` — install/download task state (InstallationManager/DownloadManager)
- `services::license_service` — license state (license-service/licenseEulaManager)
- `services::auth_service` — auth/token state (AuthService/token managers)
- `services::settings_service` — persisted settings/preferences

## Functionality domains identified in 3.22 bundle (port targets)
- Editor inventory/management (install, locate, modules, releases)
- Project management (local projects, create/open, templates)
- Download & installation management
- License & EULA management
- Authentication & token management (Unity ID, broker/keyring)
- Cloud services & Unity Cloud API
- Unity Version Control (UVCS/Plastic) & Git/Perforce integration
- Settings/preferences & feature flags
- Updates & release feeds (CDN)
- Background tasks & notifications
- Bug reporter, tray, window management, IPC/protocol handling
- Analytics, diagnostics, CLI

## CLI (selected)
```
unity-hub editors|projects|verify|port-status
unity-hub project-open-plan|project-create-plan|project-version-info
unity-hub project-open <path> [--launch] [--data-dir PATH] [extra args...]
unity-hub project-create <path> <editor> <template> [--cloud-org X] [--cloud-project Y] [--launch]
unity-hub registry-projects|registry-editors|registry-recents|registry-add-project|registry-sync-projects|...
unity-hub storage-list|get|set
unity-hub prefs-*  (project dir, secondary install path, excluded editor folders, language/sort/table/banners/first-time/org flags, etc.)
unity-hub downloads-paused-get/clear/add-entry/remove-entry
unity-hub install-state-info|downloads|installs|file-claims|schema-meta|queue-download|set-download-state|cancel-download|queue-install|set-install-phase|clear-install|upsert-file-claim|remove-file-claim|clear-file-claims
unity-hub ipc channels
unity-hub ipc [--data-dir PATH] <method> [args...]
```

## Verification / current state
- **Latest session (this resume):** repaired truncated `src/ipc.rs` dispatch and restored compile state; `cargo check --offline` succeeds (exit 0, dev profile). Extended IPC/service wiring to focus on getting flows working.
- **Previously verified baseline (recorded):** `cargo test --offline` 57 passed, 0 failed; release CLI demos for real/sample Hub data (registry/install-state/prefs), project version/open/create plans with real installed editors/templates, and 3.22-aligned arg building. Debug CLI had `STATUS_STACK_OVERFLOW` in that session while release worked.
- **IPC/MainServices:** 299 method names extracted (`electron-hub-3.22/mainservices-methods.txt`), `ipc channels` lists them. Implemented/expanded handlers cover projects/editors/install-state/paused-downloads/file-claims and many storage-backed prefs/settings plus additional mappings (survey/template/org/cloud/hub info/feature flags/CLI plugin/update/user settings, generic `getStorageJson`/`setStorageJson`, `showItemInFolder`/reveal, `downloadManagerUtilities` actions, `openProjectWithEditor`/`createProject`/`isUnityProject`/`getProjectFromPath`/`checkTemplateExists`, app/info/data-dir helpers, etc.), backed by real Hub schemas/files/DB where available.
- **Preserved artifacts:** `runtime/unity-hub-3.22.exe` kept as-is (3.22 CLI).

## Remaining for full 1:1 functionality
Most of the 299 MainServices channels and 541 bundled main-process modules still require full behavioral parity: real download/install/module execution pipelines, complete project create/open/launch/options flows, license/auth/keyring/broker, cloud/VCS/updates/CDN, background tasks/tray/notifications/protocol/analytics/diagnostics, and GUI/renderer parity (`main_window`, `bug_reporter_window`). This workspace is an actively progressing, compiling Rust port foundation mapped to 3.22 structures and data formats.

## Remaining for full 1:1 functionality
Full 1:1 parity requires implementing all 3.22 behaviors across GUI (Electron renderer parity), IPC/protocol, auth/licensing/cloud integrations, editor install/download pipelines, VCS integrations, tray/notifications/updater, and all service logic present in the 541 bundled modules. This workspace provides a verified, compiling Rust port foundation mapped to the 3.22 app structure with core services and preserved CLI, ready for continued implementation.
