@echo off
setlocal
cd /d "%~dp0"
echo Building Unity Hub 3.22 Rust port (release)...
cargo build --release --offline
if errorlevel 1 exit /b %errorlevel%
echo.
echo Built: target\release\unity-hub.exe
