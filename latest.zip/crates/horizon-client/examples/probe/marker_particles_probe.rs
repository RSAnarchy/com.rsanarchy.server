//! Probe for tools/test_marker_particles_parity.py.
use horizon_client::{
    Result,
    animate_tick::{
        AnimateContext, AnimateTables, animate_tick, campfire_particles, make_campfire_smoke,
        marker_particle_target,
    },
    assets::Assets,
    biome::Biomes,
    blocks::BlockFacts,
    chunk::Chunk,
    collisions,
    command::args::GameMode,
    items::ItemStack,
    particles::{ParticleEngine, ParticleOptions, ParticleType},
    world::World,
};
use horizon_core::{
    position::BlockPos,
    random::{RandomSource, position_seed},
};
use horizon_world::{chunk::BlockState, registry::BlockStateId};
use serde_json::Value;
use std::{
    collections::HashMap,
    fs::File,
    io::{BufRead, BufReader, BufWriter, Write},
    path::Path,
    sync::Arc,
};

/// A `minecraft:name[k=v,...]` block state, as the cases write one.
fn parse_state(spec: &str) -> BlockState {
    let (name, properties) = match spec.split_once('[') {
        Some((name, rest)) => (name, rest.trim_end_matches(']')),
        None => (spec, ""),
    };
    BlockState {
        name: name.to_owned(),
        properties: properties
            .split(',')
            .filter_map(|pair| pair.split_once('='))
            .map(|(k, v)| (k.to_owned(), v.to_owned()))
            .collect(),
    }
}
/// A position as the oracle prints it: exact double bits.
fn d(v: f64) -> String {
    format!("{:016x}", v.to_bits())
}

/// The per-column offset the client jitters a model with: an `XZ` offset type's
/// two nibbles of `Mth.getSeed(x, 0, z)`, 0.25 either way.
fn column_offset(x: i32, z: i32) -> [f64; 3] {
    let seed = position_seed(BlockPos::new(x, 0, z));
    // The division is single precision, as the offset itself is: only the
    // centring and the 0.25 scale are double.
    let nibble = |shift: u32| ((seed >> shift) & 15) as f32 / 15.0;
    [
        ((f64::from(nibble(0)) - 0.5) * 0.5).clamp(-0.25, 0.25),
        0.0,
        ((f64::from(nibble(8)) - 0.5) * 0.5).clamp(-0.25, 0.25),
    ]
}

pub fn main() -> Result<()> {
    let args: Vec<String> = crate::args().collect();
    let root = Path::new(".local/horizon-client/26.3");
    let assets = Assets::load(root)?;
    let facts = BlockFacts::load(root, assets.registry)?;
    let biomes = Biomes::load(root)?;
    let collision = collisions::load(root, assets.registry)?;
    let tables = AnimateTables::load(root, assets.registry, &biomes)?;
    let mut world = World::new(facts.air, 0);
    let barrier = assets
        .registry
        .default_state("minecraft:barrier")
        .ok_or("barrier")?;
    for cz in -2..2 {
        for cx in -2..2 {
            world
                .chunks
                .insert((cx, cz), Arc::new(Chunk::empty(cx, cz)));
            for y in 33..96 {
                for z in 0..16 {
                    for x in 0..16 {
                        world.set(cx * 16 + x, y, cz * 16 + z, barrier)?;
                    }
                }
            }
        }
    }
    let mut engine = ParticleEngine::new(root, &HashMap::new(), &Default::default());
    // One all-of-that-block world per state the tick cases name: the whole
    // animateTick loop samples inside the box the barriers already fill.
    let mut tick_worlds: HashMap<String, World> = HashMap::new();
    let mut out = BufWriter::new(File::create(&args[2])?);
    for (index, line) in BufReader::new(File::open(&args[1])?).lines().enumerate() {
        let case: Value = serde_json::from_str(&line?)?;
        let kind = case["kind"].as_str().unwrap_or("marker");
        // A block's own tick through the whole ClientLevel.animateTick loop,
        // over a world that is all of it above y = 64 and all of the case's
        // floor below: every particle and sound it asks the engine for, from the
        // level random seeded by the case.
        if kind == "tick" {
            let spec = case["state"].as_str().ok_or("state")?.to_owned();
            let floor_spec = case["floor"].as_str().unwrap_or(&spec).to_owned();
            let key = format!("{spec}|{floor_spec}");
            if !tick_worlds.contains_key(&key) {
                let state = assets.registry.resolve(&parse_state(&spec))?;
                let floor = assets.registry.resolve(&parse_state(&floor_spec))?;
                let mut world = World::new(facts.air, 0);
                // The loop samples y 32 to 96, reads neighbours one block out
                // and a stalactite climbs ten blocks to its root, so the
                // stand-in world has to hold all of that: a case that ends
                // inside the sample box compares air against the oracle's
                // unending world.
                for cz in -3..3 {
                    for cx in -3..3 {
                        world
                            .chunks
                            .insert((cx, cz), Arc::new(Chunk::empty(cx, cz)));
                        for y in 31..=107 {
                            for z in 0..16 {
                                for x in 0..16 {
                                    let at = if y < 64 { floor } else { state };
                                    world.set(cx * 16 + x, y, cz * 16 + z, at)?;
                                }
                            }
                        }
                    }
                }
                tick_worlds.insert(key.clone(), world);
            }
            let world = &tick_worlds[&key];
            // A block whose model is jittered per column: the offset the client
            // gives its model, so the oracle's shape moves exactly as the game
            // moves it.
            let jitter = case["offset"].as_str() == Some("xz");
            let model_offset = move |_: BlockStateId, x: i32, z: i32| -> Option<[f64; 3]> {
                jitter.then(|| column_offset(x, z))
            };
            let ctx = AnimateContext {
                world,
                facts: &facts,
                collision: &collision,
                biomes: &biomes,
                registry: assets.registry,
                raining_at: &|_| false,
                height_no_leaves: &|_| 0,
                firefly_bush_sounds: false,
                creaking_active: false,
                sky_darken: 0,
                marker: None,
                model_offset: &model_offset,
                gateway_particles: &|_, _| 0,
                thundering: false,
                ultrawarm: false,
            };
            engine.clear();
            engine.sounds.clear();
            engine.created_requests = None;
            // `requested` records before the 32-block limiter, as the oracle's
            // level records at `addParticle` itself.
            engine.requested = Some(Vec::new());
            engine.camera = [0.5, 64.5, 0.5];
            engine.seed_randoms(case["seed"].as_i64().ok_or("seed")?, 0, 0);
            animate_tick(&tables, &mut engine, &ctx, [0, 64, 0]);
            writeln!(out, "== {index} tick")?;
            for (name, p, volume, pitch, _) in &engine.sounds {
                write!(out, "sound {name}")?;
                for x in p {
                    write!(out, " {}", d(*x))?;
                }
                writeln!(out, " {:08x} {:08x}", volume.to_bits(), pitch.to_bits())?;
            }
            for (options, p, v) in engine.requested.take().ok_or("requests")? {
                write!(out, "{}", options.ty.name())?;
                for x in p.into_iter().chain(v) {
                    write!(out, " {}", d(x))?;
                }
                writeln!(out)?;
            }
            writeln!(out, "next {}", engine.random().next_int())?;
            continue;
        }
        // The campfire's own particles: the block entity's tick and the smoke a
        // douse adds, both from the block at [0, 64, 0] with the level random
        // seeded by the case.
        if kind == "campfire" || kind == "make" {
            let seed = case["seed"].as_i64().ok_or("seed")?;
            let ctx = AnimateContext {
                world: &world,
                facts: &facts,
                collision: &collision,
                biomes: &biomes,
                registry: assets.registry,
                raining_at: &|_| false,
                height_no_leaves: &|_| 0,
                firefly_bush_sounds: false,
                creaking_active: false,
                sky_darken: 0,
                marker: None,
                model_offset: &|_, _, _| None,
                gateway_particles: &|_, _| 0,
                thundering: false,
                ultrawarm: false,
            };
            let pos = [0, 64, 0];
            // Every particle the level is asked for: the engine records them
            // instead of making them, and the camera sits on the block so the
            // limiter keeps them all.
            engine.clear();
            engine.requested = None;
            engine.created_requests = Some(Vec::new());
            engine.camera = [0.5, 64.5, 0.5];
            engine.seed_randoms(seed, 0, 0);
            if kind == "campfire" {
                let state = assets
                    .registry
                    .resolve(&parse_state(case["state"].as_str().ok_or("state")?))?;
                let slots = case["slots"].as_array().ok_or("slots")?;
                let mut cooking = [false; 4];
                for (slot, held) in slots.iter().take(4).enumerate() {
                    cooking[slot] = held.as_u64() != Some(0);
                }
                let blocks = [(pos, state.0)];
                for _ in 0..case["ticks"].as_u64().ok_or("ticks")? {
                    campfire_particles(&tables, &mut engine, &ctx, blocks.iter(), &|_| cooking);
                }
            } else {
                let signal = case["signal"].as_bool().ok_or("signal")?;
                let smoking = case["smoking"].as_bool().ok_or("smoking")?;
                for _ in 0..case["puffs"].as_u64().ok_or("puffs")? {
                    make_campfire_smoke(&mut engine, pos, signal, smoking);
                }
            }
            writeln!(out, "== {index} {kind}")?;
            for (options, p, v) in engine.created_requests.take().ok_or("requests")? {
                write!(out, "{}", options.ty.name())?;
                for x in p.into_iter().chain(v) {
                    write!(out, " {}", d(x))?;
                }
                writeln!(out)?;
            }
            writeln!(out, "next {}", engine.random().next_int())?;
            continue;
        }
        let mode = GameMode::ALL
            .into_iter()
            .find(|mode| Some(mode.name()) == case["mode"].as_str())
            .ok_or("mode")?;
        let stack = ItemStack::new(
            &format!("minecraft:{}", case["main"].as_str().ok_or("main")?),
            case["count"].as_u64().ok_or("count")? as u32,
        );
        let target = marker_particle_target(mode, Some(&stack));
        writeln!(out, "{}", target.unwrap_or("none"))?;
        // Exercise the real ambient sampling loop in a dry barrier-filled world.
        let options =
            ParticleOptions::block(ParticleType::BlockMarker, "item/barrier".into(), 0xFFFFFF);
        let options = |_| Some(options.clone());
        let ctx = AnimateContext {
            world: &world,
            facts: &facts,
            collision: &collision,
            biomes: &biomes,
            registry: assets.registry,
            raining_at: &|_| false,
            height_no_leaves: &|_| 0,
            firefly_bush_sounds: false,
            creaking_active: false,
            sky_darken: 0,
            marker: target.map(|name| (name, &options as &dyn Fn(_) -> _)),
            model_offset: &|_, _, _| None,
            gateway_particles: &|_, _| 0,
            thundering: false,
            ultrawarm: false,
        };
        engine.seed_randoms(1057, 0, 0);
        engine.requested = Some(Vec::new());
        animate_tick(&tables, &mut engine, &ctx, [0, 64, 0]);
        for (options, p, v) in engine.requested.take().ok_or("requests")? {
            assert_eq!(options.ty, ParticleType::BlockMarker);
            assert_eq!(v, [0.0; 3]);
            writeln!(out, "marker {} {} {}", p[0], p[1], p[2])?;
        }
        writeln!(out, "next {}", engine.random().next_int())?;
    }
    Ok(())
}
