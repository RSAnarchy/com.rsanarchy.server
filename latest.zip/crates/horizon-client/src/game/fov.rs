//! Field of view (`Camera.tickFov`, `calculateFov`,
//! `AbstractClientPlayer.getFieldOfViewModifier`), view and hurt bobbing
//! (`GameRenderer.bobHurt`, `bobView`), the portal and Nausea spin
//! (`GameRenderer.renderLevel`) and the spyglass (`SpyglassItem`,
//! `Hud.extractSpyglassOverlay`). The arithmetic is `horizon_client::camera`.
use super::Game;

pub(super) fn camera_effects_enabled(title: bool, studio_freecam: bool) -> bool {
    !title && !studio_freecam
}

pub(super) fn studio_draws_hand(studio_freecam: bool, ordinary_hand_visible: bool) -> bool {
    !studio_freecam && ordinary_hand_visible
}
use horizon_client::{
    camera::{
        BobState, CameraFluid, FovPlayer, HurtBob, UseItem, bob_matrix, field_of_view_modifier,
        spinning_effect_matrix,
    },
    fog::{FogType, fog_type},
    hud::HudBatch,
    hud_layout, hud_overlays,
};

fn valid_fov_modifier(modifier: f32, fallback: f32) -> f32 {
    if modifier.is_finite() && (0.01..=10.0).contains(&modifier) {
        modifier
    } else {
        fallback
    }
}

impl Game<'_> {
    /// `Player.isScoping`: using a spyglass.
    pub(super) fn scoping(&self) -> bool {
        self.using
            .and_then(|(slot, _)| self.stack_in(slot))
            .is_some_and(|s| &*s.item == "minecraft:spyglass")
    }
    /// `options.fovEffectScale`.
    pub(super) fn fov_effect_scale(&self) -> f32 {
        self.settings.file.double("fovEffectScale") as f32
    }
    /// `options.screenEffectScale` (Distortion Effects).
    pub(super) fn screen_effect_scale(&self) -> f32 {
        self.settings.file.double("screenEffectScale") as f32
    }
    /// `LocalPlayer.getEffectBlendFactor(NAUSEA, partial)`: 0 without the effect.
    pub(super) fn nausea_blend(&self, partial: f32) -> f32 {
        if self.potions.effects.get("nausea").is_none() {
            return 0.0;
        }
        let fx = &self.screen_fx;
        fx.o_nausea + partial * (fx.nausea - fx.o_nausea)
    }
    /// The spin `GameRenderer.renderLevel` multiplies into the level's
    /// projection: the larger of the portal and Nausea intensities, scaled by
    /// Distortion Effects squared, turning by `LocalPlayer.getSpinningEffectAngle`.
    pub(super) fn spinning_matrix(&self, partial: f32) -> glam::Mat4 {
        let fx = &self.screen_fx;
        let portal = fx.o_portal + partial * (fx.portal - fx.o_portal);
        let scale = self.screen_effect_scale();
        let intensity = portal.max(self.nausea_blend(partial)) * (scale * scale);
        spinning_effect_matrix(intensity, fx.spinning_time + partial * fx.spinning_speed)
    }
    /// What `AbstractClientPlayer.getFieldOfViewModifier` reads.
    fn fov_player(&self) -> Option<FovPlayer> {
        let p = self.player.as_ref()?;
        let using = self.using.and_then(|(slot, ticks)| {
            let stack = self.stack_in(slot)?;
            let item = match &*stack.item {
                "minecraft:bow" => UseItem::Bow,
                "minecraft:spyglass" => UseItem::Spyglass,
                _ => UseItem::Other,
            };
            Some((item, ticks as i32))
        });
        Some(FovPlayer {
            flying: p.flying,
            walking_speed: self.remote_walking_speed(),
            // Player.aiStep keeps `speed` as the float movement speed attribute.
            movement_speed: f64::from(p.speed),
            using,
        })
    }
    /// `Camera.tick`: the eye height and the field-of-view modifier ease
    /// halfway toward the player's each tick.
    pub(super) fn tick_fov(&mut self) {
        let first_person = self.camera_type.first_person();
        let effect = self.fov_effect_scale();
        let target = self.fov_player().map_or(1.0, |player| {
            let base = field_of_view_modifier(&player, first_person, effect);
            let mut modifier = base;
            self.native_compute_fov_modifier(&player, base, &mut modifier);
            valid_fov_modifier(modifier, base)
        });
        let target = self.zoomed_fov_target(target);
        // A server's spectator camera on a mob or an armor stand: its eye
        // height. Its modifier stays 1 (another player's own modifier is not
        // modelled here); the zoom extra still narrows it.
        if let Some(e) = self.camera_entity() {
            self.view
                .tick(Some(e.eye_height), self.zoomed_fov_target(1.0));
            return;
        }
        let eye = self.player.as_ref().map(|p| {
            if self.sleeping.is_some() {
                0.2
            } else {
                p.dimensions.eye_height
            }
        });
        self.view.tick(eye, target);
    }
    /// The player's `deathTime` while dead or dying: whole ticks counted by
    /// `LivingEntity.tickDeath`, so `deathTime + partialTicks` in
    /// `Camera.extractRenderState` rises smoothly across frames.
    pub(super) fn death_time(&self) -> Option<i32> {
        let p = self.player.as_ref()?;
        p.health
            .dead_or_dying()
            .then(|| self.ui.death_time.min(i32::MAX as u32) as i32)
    }
    /// The fluid at the camera, as `Camera.getFluidInCamera` reports it.
    pub(super) fn camera_fluid(&self, camera: [f64; 3]) -> CameraFluid {
        match fog_type(&self.world, self.res.facts(), camera, &self.near_plane()) {
            FogType::Water => CameraFluid::Water,
            FogType::Lava => CameraFluid::Lava,
            FogType::PowderSnow => CameraFluid::PowderSnow,
            FogType::Atmospheric => CameraFluid::None,
        }
    }
    /// `Camera.calculateFov` with `modifyFovBasedOnDeathOrFluid`.
    pub(super) fn fov_degrees(&self, partial: f32, camera: [f64; 3]) -> f32 {
        if self.studio.flying() {
            return self.studio.freecam.fov.clamp(1.0, 179.0);
        }
        let fov = self.view.calculate_fov(
            partial,
            self.settings.fov as i32,
            self.fov_effect_scale(),
            self.death_time(),
            self.camera_fluid(camera),
            false,
        );
        let vanilla = self.zoomed_fov_degrees(fov);
        let mut degrees = vanilla;
        self.native_compute_fov(partial, camera, &mut degrees);
        if degrees.is_finite() && (1.0..=179.0).contains(&degrees) {
            degrees
        } else {
            vanilla
        }
    }
    /// How many times the view is magnified right now: the player's field of
    /// view over the one actually in use, and 1 when nothing is zooming.
    ///
    /// Reads the result rather than any one zoom, so it covers all three:
    /// the spyglass (`AbstractClientPlayer.getFieldOfViewModifier`'s tenth
    /// while `isScoping`), the zoom mod (`native_zoom`) and any mod that
    /// narrows the field of view through `native_compute_fov`.
    pub(super) fn zoom_magnification(&self, camera: [f64; 3]) -> f32 {
        let now = self.fov_degrees(1.0, camera);
        let base = self.settings.fov.clamp(1.0, 179.0);
        if now.is_finite() && now > 0.5 {
            (base / now).max(1.0)
        } else {
            1.0
        }
    }
    /// What far terrain should plan for a zoomed view, or `None` when the
    /// `lodZoomDetail` extra is off or nothing is zooming (`lod::ZoomAim`).
    pub(super) fn lod_aim(&self, camera: [f64; 3]) -> Option<horizon_client::lod::ZoomAim> {
        if !self.settings.extras.lod_zoom_detail {
            return None;
        }
        horizon_client::lod::ZoomAim::new(
            self.yaw,
            self.fov_degrees(1.0, camera),
            self.zoom_magnification(camera),
        )
    }
    /// `Camera.calculateHudFov`: the first-person hand's field of view.
    pub(super) fn hud_fov_degrees(&self, partial: f32, camera: [f64; 3]) -> f32 {
        self.view.calculate_hud_fov(
            partial,
            self.fov_effect_scale(),
            self.death_time(),
            self.camera_fluid(camera),
        )
    }
    /// The pose `GameRenderer.renderLevel` multiplies into the projection:
    /// `bobHurt`, then `bobView` with the View Bobbing option.
    pub(super) fn bob_matrix(&self, partial: f32) -> glam::Mat4 {
        let Some(p) = self.player.as_ref() else {
            return glam::Mat4::IDENTITY;
        };
        let hurt = &p.health.hurt;
        let state = BobState {
            living: Some(HurtBob {
                hurt_time: p.health.hurt_animation_time as f32 - partial,
                hurt_duration: hurt.hurt_duration,
                hurt_dir: p.health.hurt_dir,
                death_time: self.death_time().map(|t| t as f32 + partial),
            }),
            player: Some((
                self.avatar.backwards_interpolated_walk_distance(partial),
                self.avatar.interpolated_bob(partial),
            )),
        };
        let tilt = self.settings.file.double("damageTiltStrength");
        glam::Mat4::from_cols_array(&bob_matrix(&state, tilt, self.settings.view_bobbing).m)
            * self.native_shake_matrix(partial)
    }
    /// `AbstractClientPlayer.tick` and `aiStep` (`ClientAvatarState.tick`,
    /// `updateBob`), `rideTick`'s `resetBob` and `LocalPlayer.move`'s walked
    /// distance, after the player's movement this tick. `before` is the
    /// ground state, velocity and position at the start of the tick.
    pub(super) fn tick_avatar(&mut self, before: (bool, [f64; 3], [f64; 3]), riding: bool) {
        let Some(p) = self.player.as_ref() else {
            return;
        };
        let (ground, velocity, start) = before;
        let swimming = p.pose == horizon_client::pose::Pose::Swimming;
        let alive = !p.health.dead_or_dying();
        let (dx, dz) = (
            (p.position.x - start[0]) as f32,
            (p.position.z - start[2]) as f32,
        );
        self.avatar.tick(start);
        self.avatar
            .update_bob(ground && alive && !swimming, velocity);
        if riding {
            self.avatar.reset_bob();
        } else {
            self.avatar.add_walked(dx, dz);
        }
    }
    /// `SpyglassItem.use`: the sound, then start scoping (a mod's `Start`
    /// may refuse that, not the sound).
    pub(super) fn use_spyglass(&mut self) {
        // Player.playSound: at the feet (getY), not the eyes.
        let at = self
            .player
            .as_ref()
            .map(|p| [p.position.x, p.position.y, p.position.z]);
        self.audio.play("minecraft:item.spyglass.use", at, 1.0, 1.0);
        self.award_stat("used", "minecraft:spyglass", 1);
        self.start_using_item();
    }
    /// `SpyglassItem.releaseUsing` / `finishUsingItem` (after 1200 ticks).
    pub(super) fn stop_spyglass(&mut self) {
        let at = self.eye_position();
        self.audio
            .play("minecraft:item.spyglass.stop_using", at, 1.0, 1.0);
    }
    /// `Hud.extractCameraOverlays`: the spyglass scope, its size easing
    /// towards 1.125 by half the frame's game ticks and reset to 0.5 while
    /// not scoping in first person.
    pub(super) fn draw_spyglass(&mut self, batch: &mut HudBatch) {
        self.scope_scale += 0.5 * self.frame_ticks * (1.125 - self.scope_scale);
        if !self.camera_type.first_person() {
            return;
        }
        if !self.scoping() {
            self.scope_scale = 0.5;
            return;
        }
        let draws =
            hud_overlays::spyglass(batch.width as i32, batch.height as i32, self.scope_scale);
        hud_layout::paint(batch, &self.gui.atlas, &draws);
    }
}

#[cfg(test)]
mod tests {
    use super::{camera_effects_enabled, studio_draws_hand, valid_fov_modifier};
    #[test]
    fn modifier_validation() {
        assert_eq!(valid_fov_modifier(0.5, 1.0), 0.5);
        for value in [f32::NAN, f32::INFINITY, 0.0, 10.1] {
            assert_eq!(valid_fov_modifier(value, 1.0), 1.0);
        }
    }

    #[test]
    fn freecam_uses_unshaken_camera_and_player_view_keeps_hands() {
        assert!(!camera_effects_enabled(false, true));
        assert!(camera_effects_enabled(false, false));
        assert!(!camera_effects_enabled(true, false));
        assert!(studio_draws_hand(false, true));
        assert!(!studio_draws_hand(true, true));
        assert!(!studio_draws_hand(false, false));
    }
}
