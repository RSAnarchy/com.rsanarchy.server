//! Chat, the command registries and the per-world state behind commands
//! (game rules, the world clock, difficulty), bound to the game.
#[cfg(test)]
mod end_clock_tests;
#[cfg(test)]
mod suggestion_completion_tests;

use super::{Game, Screen};
use horizon_client::{
    chat::{
        Chat, ChatAbilities, ChatAction, ChatScreen, ChatSource, ChatVisibility, Commands,
        QUEUE_EXPAND_ID, SYSTEM_INDICATOR, normalize_chat_message,
    },
    command::{ArgType, Dispatcher, MOD_COMMAND, Registries},
    gamerules::GameRules,
    hud::HudBatch,
    screen_draw::Measure,
    text::{ClickEvent, Style, Text},
};
use horizon_world::registry::{BlockRegistry, BlockStateId};
use std::{
    collections::BTreeMap,
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
};

/// The tree the chat parses and completes with: `Remote::chat_tree`, which is
/// a server's, once it has sent one (ClientPacketListener.commands), else the
/// game's own, plus the commands native mods own (`chat_tree_for`).
pub(super) fn chat_tree(
    remote: &Option<super::remote::Remote>,
) -> &horizon_client::command::Dispatcher {
    match remote.as_ref() {
        Some(server) => &server.chat_tree,
        None => horizon_client::command::vanilla::game_dispatcher(),
    }
}
/// The arguments of a typed `/profiler` the client answers itself: only when the chat tree's `profiler` is Horizon's, else the server or mod that owns the name runs it.
fn horizon_profiler_args<'a>(
    message: &'a str,
    server_tree: Option<&horizon_client::command::Dispatcher>,
) -> Option<&'a str> {
    let args = message
        .strip_prefix('/')
        .and_then(super::profile_capture::profiler_args)?;
    server_tree
        .is_none_or(|tree| tree.has_horizon_profiler())
        .then_some(args)
}
use winit::{
    event::KeyEvent,
    keyboard::{KeyCode, PhysicalKey},
};

/// `base` with the commands native mods own (`native_commands`) added: each a
/// literal that takes the rest of the line as it was typed, run by
/// `native_command` (`Dispatcher::with_mod_commands`), so the chat box colours
/// and completes them as it does the game's own.
pub(super) fn with_native_commands(
    base: &horizon_client::command::Dispatcher,
    names: &[&str],
) -> horizon_client::command::Dispatcher {
    // A name the tree already has keeps that command (colour, completion).
    base.with_mod_commands(
        names
            .iter()
            .copied()
            .filter(|name| base.find(name).is_none()),
    )
}

/// Add Studio's local command grammar to the suggestion tree. Commands are
/// still dispatched by `studio_command`; this tree supplies coloring,
/// completion, and Tab acceptance in chat.
fn with_studio_commands(base: &Dispatcher) -> Dispatcher {
    fn literal(d: &mut Dispatcher, parent: usize, name: &str) -> usize {
        let node = d.literal(parent, name);
        d.executes(node, MOD_COMMAND);
        node
    }
    fn argument(d: &mut Dispatcher, parent: usize, name: &str, ty: ArgType) -> usize {
        let node = d.argument(parent, name, ty);
        d.executes(node, MOD_COMMAND);
        node
    }

    let mut d = base.clone();
    let root = d.find("studio").unwrap_or_else(|| d.literal(0, "studio"));
    d.executes(root, MOD_COMMAND);

    let record = literal(&mut d, root, "record");
    let start = literal(&mut d, record, "start");
    argument(&mut d, start, "name", ArgType::Word);
    literal(&mut d, record, "stop");
    literal(&mut d, record, "status");

    let replay = literal(&mut d, root, "replay");
    let open = literal(&mut d, replay, "open");
    argument(&mut d, open, "path", ArgType::Greedy);
    literal(&mut d, replay, "pause");
    literal(&mut d, replay, "resume");
    let speed = literal(&mut d, replay, "speed");
    argument(
        &mut d,
        speed,
        "multiplier",
        ArgType::Double {
            min: 0.01,
            max: 20.0,
        },
    );
    let seek = literal(&mut d, replay, "seek");
    argument(
        &mut d,
        seek,
        "milliseconds",
        ArgType::Integer {
            min: 0,
            max: i32::MAX,
        },
    );
    literal(&mut d, replay, "status");
    literal(&mut d, replay, "close");

    let freecam = literal(&mut d, root, "freecam");
    argument(
        &mut d,
        freecam,
        "state",
        ArgType::StrEnum(&["on", "off"], "argument.enum.invalid"),
    );

    let keyframe = literal(&mut d, root, "keyframe");
    literal(&mut d, keyframe, "add");
    let remove = literal(&mut d, keyframe, "remove");
    argument(
        &mut d,
        remove,
        "index",
        ArgType::Integer {
            min: 0,
            max: i32::MAX,
        },
    );
    literal(&mut d, keyframe, "clear");

    let path = literal(&mut d, root, "path");
    argument(
        &mut d,
        path,
        "state",
        ArgType::StrEnum(&["lock", "unlock"], "argument.enum.invalid"),
    );
    d
}

impl Game<'_> {
    /// The tree the chat box colours, completes and parses with for the
    /// world's connection: `base`, the tree the server sent, or the game's own
    /// before it does. Built where that base changes — once per connection —
    /// rather than at each keystroke, and asking the mods then, not per key.
    pub(super) fn chat_tree_for(
        &mut self,
        base: Option<&horizon_client::command::Dispatcher>,
    ) -> horizon_client::command::Dispatcher {
        let mut names = Vec::new();
        self.native_commands(&mut names);
        let base = match base {
            Some(tree) => tree,
            None => horizon_client::command::vanilla::game_dispatcher(),
        };
        with_studio_commands(&with_native_commands(base, &names)).with_profiler()
    }
}

/// The local player's name (offline single player).
pub const PLAYER_NAME: &str = "Player";

/// `ServerClockManager.ServerClockInstance`: the part of a clock that advances
/// it. The total ticks live in `World.day_time` (Overworld) and
/// `World.end_clock` (the End).
#[derive(Clone, Copy, Debug)]
pub struct WorldClock {
    pub partial: f32,
    pub rate: f32,
    pub paused: bool,
}
impl Default for WorldClock {
    fn default() -> Self {
        Self {
            partial: 0.0,
            rate: 1.0,
            paused: false,
        }
    }
}
/// A clock time marker from the timelines (ClockTimeMarker).
#[derive(Clone, Copy, Debug)]
pub struct TimeMarker {
    pub ticks: i64,
    pub period: Option<i64>,
    pub show: bool,
}
impl TimeMarker {
    pub fn occurs_at(&self, total: i64) -> bool {
        match self.period {
            Some(p) => self.ticks == total.rem_euclid(p),
            None => self.ticks == total,
        }
    }
    pub fn resolve(&self, total: i64) -> i64 {
        match self.period {
            Some(p) => {
                let d = self.ticks - total.rem_euclid(p);
                total + if d > 0 { d } else { p + d }
            }
            None => self.ticks,
        }
    }
}
/// `ChatComponent.Draft`: the text the chat box kept, and whether it was a command.
pub struct ChatDraft {
    pub text: String,
    pub command: bool,
}
/// `ChatScreen.ExitReason`: why the chat screen went away.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(super) enum ChatExit {
    /// Another screen replaced it (death, a container, a disconnect).
    Interrupted,
    /// The player closed it (Escape).
    Intentional,
    /// A message was sent.
    Done,
}
/// `ChatScreen.shouldDiscardDraft`.
fn should_discard_draft(reason: ChatExit, save_chat_drafts: bool) -> bool {
    reason != ChatExit::Interrupted && (reason != ChatExit::Intentional || !save_chat_drafts)
}
/// UI and command state that lives beside the game.
#[derive(Default)]
pub struct UiState {
    pub chat: Chat,
    pub chat_screen: Option<ChatScreen>,
    /// `ChatComponent.latestDraft`.
    pub chat_draft: Option<ChatDraft>,
    /// `ChatScreen.isDraft`: the box opened with the draft and is unchanged since.
    pub chat_draft_shown: bool,
    /// When the chat screen opened (its input took the focus: the cursor blink).
    pub chat_opened: Option<std::time::Instant>,
    /// The chat screen is `InBedChatScreen`: the sleeper's, with a Leave Bed button.
    pub in_bed_chat: bool,
    pub registries: Registries,
    pub rules: GameRules,
    pub clock: WorldClock,
    /// The End's clock (`World.end_clock` holds its total ticks).
    pub end_clock: WorldClock,
    /// Command state for registered clocks Horizon does not tick: the built-in
    /// two keep their ticks in World.day_time and World.end_clock.
    pub command_clocks: BTreeMap<String, (i64, WorldClock)>,
    /// Time markers and timelines of the overworld clock.
    pub markers: BTreeMap<String, TimeMarker>,
    pub timelines: BTreeMap<String, Option<i64>>,
    /// 0 peaceful .. 3 hard.
    pub difficulty: u8,
    /// F1: hide the HUD.
    pub hide_gui: bool,
    /// Native HUD mode: keep hands visible while the HUD is hidden.
    pub show_hand_when_hidden: bool,
    /// Death message key set by the cause of death (e.g. /kill).
    pub death_cause: Option<String>,
    /// What this frame's HUD shows that Horizon's overlays keep clear of (`Game::hud_room`),
    /// set by `hud_layers` before anything draws.
    pub room: horizon_client::hud_kit::room::Room,
    /// F2 screenshots not written yet: each reports in chat once its PNG is.
    pub screenshot_messages: Vec<std::path::PathBuf>,
    /// The options screens.
    pub options: horizon_client::options_ui::OptionsUi,
    /// The prepared resources before resource packs are layered on.
    pub vanilla_root: std::path::PathBuf,
    /// Death screen cause and when the player died (buttons wait 20 ticks).
    pub death_text: Option<Text>,
    pub died_at: Option<std::time::Instant>,
    /// `DeathScreen.TitleConfirmScreen` and when it opened (its buttons wait
    /// 20 ticks, `setDelay`).
    pub death_confirm: Option<std::time::Instant>,
    /// `LivingEntity.deathTime` of the window's player: ticks since it died.
    pub death_time: u32,
}

impl UiState {
    pub fn hud_mode(&self) -> super::native_client_services::HudMode {
        use super::native_client_services::HudMode;
        match (self.hide_gui, self.show_hand_when_hidden) {
            (false, _) => HudMode::AllVisible,
            (true, true) => HudMode::NoHud,
            (true, false) => HudMode::AllHidden,
        }
    }

    pub fn set_hud_mode(&mut self, mode: super::native_client_services::HudMode) {
        use super::native_client_services::HudMode;
        self.hide_gui = mode != HudMode::AllVisible;
        self.show_hand_when_hidden = mode == HudMode::NoHud;
    }

    pub fn hand_hidden(&self) -> bool {
        self.hide_gui && !self.show_hand_when_hidden
    }

    /// The effective first-person hand gate, before per-hand mod cancellation.
    pub fn hands_drawn(
        &self,
        spectator: bool,
        sleeping: bool,
        first_person: bool,
        alive: bool,
        dead_screen: bool,
    ) -> bool {
        !spectator && !self.hand_hidden() && !sleeping && first_person && alive && !dead_screen
    }

    fn toggle_hide_gui(&mut self) {
        use super::native_client_services::HudMode;
        self.set_hud_mode(if self.hide_gui {
            HudMode::AllVisible
        } else {
            HudMode::AllHidden
        });
    }

    /// The state a window starts with: the chat remembers the commands kept
    /// in the game folder (`ChatComponent`'s constructor).
    pub fn new() -> Self {
        let mut ui = Self::default();
        if let Ok(dir) = std::env::current_dir() {
            ui.chat.load_history(&dir);
        }
        ui
    }
}

#[cfg(test)]
mod hud_mode_tests {
    use super::UiState;
    use crate::mod_api::{self, ClientTickPreEvent, Hooks, Host, HudMode};

    #[test]
    fn hud_modes_drive_the_effective_hud_and_hand_gate() {
        let mut ui = UiState::default();
        for (mode, hidden, hand) in [
            (HudMode::AllVisible, false, true),
            (HudMode::NoHud, true, true),
            (HudMode::AllHidden, true, false),
        ] {
            ui.set_hud_mode(mode);
            assert_eq!(ui.hud_mode(), mode);
            // This is the same flag that every HUD gate and API 410 read.
            assert_eq!(ui.hide_gui, hidden);
            assert_eq!(ui.hands_drawn(false, false, true, true, false), hand);
            // No mode can bypass the other first-person hand restrictions.
            assert!(!ui.hands_drawn(true, false, true, true, false));
            assert!(!ui.hands_drawn(false, true, true, true, false));
            assert!(!ui.hands_drawn(false, false, false, true, false));
            assert!(!ui.hands_drawn(false, false, true, false, false));
            assert!(!ui.hands_drawn(false, false, true, true, true));
        }
    }

    #[test]
    fn vanilla_f1_remains_two_state_and_clears_the_hand_override() {
        let mut ui = UiState::default();
        assert_eq!(ui.hud_mode(), HudMode::AllVisible);
        ui.toggle_hide_gui();
        assert_eq!(ui.hud_mode(), HudMode::AllHidden);
        assert!(ui.hand_hidden());
        ui.toggle_hide_gui();
        assert_eq!(ui.hud_mode(), HudMode::AllVisible);
        ui.set_hud_mode(HudMode::NoHud);
        ui.toggle_hide_gui();
        assert_eq!(ui.hud_mode(), HudMode::AllVisible);
        ui.toggle_hide_gui();
        assert_eq!(ui.hud_mode(), HudMode::AllHidden);
        // Existing hidden state also hides hands without a separate setting.
        let ui = UiState {
            hide_gui: true,
            ..Default::default()
        };
        assert_eq!(ui.hud_mode(), HudMode::AllHidden);
        assert!(ui.hand_hidden());
    }

    struct Client(UiState);
    impl Host for Client {
        fn hud_mode(&self) -> HudMode {
            self.0.hud_mode()
        }
        fn set_hud_mode(&mut self, mode: HudMode) {
            self.0.set_hud_mode(mode);
        }
    }
    struct ThreeState;
    impl Hooks for ThreeState {
        fn client_tick_pre(&self, host: &mut dyn Host, _: &mut ClientTickPreEvent) {
            host.set_hud_mode(match host.hud_mode() {
                HudMode::AllVisible => HudMode::NoHud,
                HudMode::NoHud => HudMode::AllHidden,
                HudMode::AllHidden => HudMode::AllVisible,
            });
        }
    }

    #[test]
    fn generated_dispatch_exposes_hud_mode_helpers_to_existing_callbacks() {
        let mods: Vec<Box<dyn Hooks>> = vec![Box::new(ThreeState)];
        let mut client = Client(UiState::default());
        for (mode, hidden, hand) in [
            (HudMode::NoHud, true, true),
            (HudMode::AllHidden, true, false),
            (HudMode::AllVisible, false, true),
        ] {
            mod_api::dispatch_client_tick_pre(&mut client, &mods);
            assert_eq!(client.hud_mode(), mode);
            assert_eq!(client.0.hide_gui, hidden);
            assert_eq!(client.0.hands_drawn(false, false, true, true, false), hand);
        }
        mod_api::dispatch_client_tick_pre(&mut client, &[]);
        assert_eq!(client.hud_mode(), HudMode::AllVisible);
    }

    /// Exercise the generated Host bridge against a real Game with silent audio
    /// and no window, renderer, server loop or network connection.
    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES"]
    fn native_hud_mode_game_bridge_respects_client_and_guest_guards() {
        use crate::game::{execution_role::ExecutionRole, native_machines::tests::server_game};
        let mut game = server_game();
        assert!(game.window.is_none());
        assert!(game.renderer.is_none());
        let mods: Vec<Box<dyn Hooks>> = vec![Box::new(ThreeState)];
        for role in [
            ExecutionRole::IntegratedServer,
            ExecutionRole::DedicatedServer,
        ] {
            game.options.execution_role = role;
            mod_api::dispatch_client_tick_pre(&mut game, &mods);
            assert_eq!(Host::hud_mode(&game), HudMode::AllVisible);
        }
        game.options.execution_role = ExecutionRole::Client;
        mod_api::dispatch_client_tick_pre(&mut game, &mods);
        assert_eq!(Host::hud_mode(&game), HudMode::NoHud);
        assert!(game.ui.hide_gui);
        assert!(game.ui.hands_drawn(false, false, true, true, false));

        // A server callback borrowing another actor cannot change the window's mode.
        game.lan_acting = Some(17);
        mod_api::dispatch_client_tick_pre(&mut game, &mods);
        assert_eq!(Host::hud_mode(&game), HudMode::NoHud);
        game.lan_acting = None;
        mod_api::dispatch_client_tick_pre(&mut game, &mods);
        assert_eq!(Host::hud_mode(&game), HudMode::AllHidden);
        assert!(!game.ui.hands_drawn(false, false, true, true, false));

        game.toggle_hide_gui();
        assert_eq!(Host::hud_mode(&game), HudMode::AllVisible);
        Host::set_hud_mode(&mut game, HudMode::NoHud);
        game.toggle_hide_gui();
        assert_eq!(Host::hud_mode(&game), HudMode::AllVisible);
        game.toggle_hide_gui();
        assert_eq!(Host::hud_mode(&game), HudMode::AllHidden);
        assert!(game.ui.hand_hidden());
    }
}

/// The ids `build_registries` lists from the prepared resources' folders.
/// The folders don't change while the game runs, so each root is read once
/// instead of at every world opening (thousands of files).
struct ResourceIds {
    recipes: Vec<String>,
    templates: Vec<String>,
    /// `entity-types.json`'s keys, sorted (empty when the file is missing).
    entity_types: Vec<String>,
    enchantments: Vec<String>,
    structures: Vec<String>,
    biomes: Vec<String>,
    clocks: Vec<String>,
    /// The overworld clock's timelines, their periods and time markers.
    timelines: Vec<(String, Option<i64>)>,
    markers: Vec<(String, TimeMarker)>,
}
static RESOURCE_IDS: Mutex<Vec<(PathBuf, Arc<ResourceIds>)>> = Mutex::new(Vec::new());

/// The `minecraft:` ids of the `.json` files directly in `dir`, sorted.
fn json_ids_in(dir: &Path) -> Vec<String> {
    let mut out: Vec<String> = std::fs::read_dir(dir)
        .into_iter()
        .flatten()
        .flatten()
        .filter_map(|e| {
            e.file_name()
                .to_str()?
                .strip_suffix(".json")
                .map(|n| format!("minecraft:{n}"))
        })
        .collect();
    out.sort();
    out
}

/// The overworld clock's timelines (with their periods) and their time
/// markers, read from `data/minecraft/timeline`.
fn overworld_timelines(root: &Path) -> (Vec<(String, Option<i64>)>, Vec<(String, TimeMarker)>) {
    let dir = root.join("data/minecraft/timeline");
    let (mut timelines, mut markers) = (Vec::new(), Vec::new());
    for name in json_ids_in(&dir) {
        let path = dir.join(format!("{}.json", name.trim_start_matches("minecraft:")));
        let Ok(v) =
            serde_json::from_slice::<serde_json::Value>(&std::fs::read(path).unwrap_or_default())
        else {
            continue;
        };
        if v["clock"].as_str() != Some("minecraft:overworld") {
            continue;
        }
        let period = v["period_ticks"].as_i64();
        timelines.push((name.clone(), period));
        for (marker, def) in v["time_markers"].as_object().into_iter().flatten() {
            let (ticks, show) = match def {
                serde_json::Value::Number(n) => (n.as_i64().unwrap_or(0), false),
                other => (
                    other["ticks"].as_i64().unwrap_or(0),
                    other["show_in_commands"].as_bool().unwrap_or(false),
                ),
            };
            markers.push((
                marker.clone(),
                TimeMarker {
                    ticks,
                    period,
                    show,
                },
            ));
        }
    }
    (timelines, markers)
}

fn resource_ids(root: &Path) -> Arc<ResourceIds> {
    let mut cache = RESOURCE_IDS.lock().unwrap_or_else(|e| e.into_inner());
    if let Some((_, ids)) = cache.iter().find(|(cached, _)| cached == root) {
        return ids.clone();
    }
    let data = root.join("data/minecraft");
    let mut entity_types: Vec<String> = serde_json::from_slice::<serde_json::Value>(
        &std::fs::read(root.join("entity-types.json")).unwrap_or_default(),
    )
    .ok()
    .and_then(|v| {
        v.as_object().map(|o| {
            o.keys()
                .map(|k| horizon_client::command::args::normalize(k))
                .collect()
        })
    })
    .unwrap_or_default();
    entity_types.sort();
    let (timelines, markers) = overworld_timelines(root);
    let ids = Arc::new(ResourceIds {
        // `/recipe <id>` must suggest a content mod's recipes too.
        recipes: json_ids_of_every_namespace(root, "recipe"),
        templates: templates_under(&root.join("worldgen/structure")),
        entity_types,
        enchantments: json_ids_in(&data.join("enchantment")),
        structures: json_ids_in(&data.join("worldgen/structure")),
        biomes: json_ids_in(&data.join("worldgen/biome")),
        clocks: json_ids_in(&data.join("world_clock")),
        timelines,
        markers,
    });
    cache.push((root.to_owned(), ids.clone()));
    ids
}

/// Every block's properties and their values, as `/setblock` completes them.
type BlockProperties = BTreeMap<String, Vec<(String, Vec<String>)>>;
static BLOCK_PROPERTIES: Mutex<Vec<(usize, Arc<BlockProperties>)>> = Mutex::new(Vec::new());

/// `BlockProperties` of a block registry, listed once: a registry never
/// changes once built, and walking its tens of thousands of states took
/// about 30 ms of every world opening.
fn block_properties(registry: &'static BlockRegistry) -> Arc<BlockProperties> {
    let key = std::ptr::from_ref(registry) as usize;
    let mut cache = BLOCK_PROPERTIES.lock().unwrap_or_else(|e| e.into_inner());
    if let Some((_, properties)) = cache.iter().find(|(cached, _)| *cached == key) {
        return properties.clone();
    }
    let mut blocks: BTreeMap<String, BTreeMap<String, Vec<String>>> = BTreeMap::new();
    for id in 0..registry.len() {
        let Some(state) = registry.state(BlockStateId(id as u32)) else {
            continue;
        };
        let props = blocks.entry(state.name.clone()).or_default();
        for (k, v) in &state.properties {
            let values = props.entry(k.clone()).or_default();
            if !values.contains(v) {
                values.push(v.clone());
            }
        }
    }
    let properties: Arc<BlockProperties> = Arc::new(
        blocks
            .into_iter()
            .map(|(k, v)| (k, v.into_iter().collect()))
            .collect(),
    );
    cache.push((key, properties.clone()));
    properties
}

static COMMAND_EXPORTS: Mutex<Vec<(PathBuf, Option<Arc<Registries>>)>> = Mutex::new(Vec::new());

/// What the registries take from a folder's `command-registries.json`
/// (vanilla's built-in registries), read once like the resource ids: parsing
/// its 1.6 MB again took about 15 ms of every world opening. Only the part
/// the registries fill from stays, not the parsed export (4.2 MB, against
/// 2.2 MB). A dedicated server opens its world once and keeps nothing.
fn command_export(dir: &Path, keep: bool) -> Option<Arc<Registries>> {
    let mut cache = COMMAND_EXPORTS.lock().unwrap_or_else(|e| e.into_inner());
    if let Some((_, export)) = cache.iter().find(|(cached, _)| cached == dir) {
        return export.clone();
    }
    let export = std::fs::read(dir.join("command-registries.json"))
        .ok()
        .and_then(|bytes| serde_json::from_slice(&bytes).ok())
        .map(|export| Arc::new(Registries::from_export(&export)));
    if keep {
        cache.push((dir.to_owned(), export.clone()));
    }
    export
}

/// The ids of the `.json` files in `data/<namespace>/<kind>` of every
/// namespace of `root` (vanilla's and the content mods'), sorted.
fn json_ids_of_every_namespace(root: &Path, kind: &str) -> Vec<String> {
    let data = root.join("data");
    let mut namespaces: std::collections::BTreeSet<String> = std::fs::read_dir(&data)
        .into_iter()
        .flatten()
        .flatten()
        .filter(|e| e.path().is_dir())
        .map(|e| e.file_name().to_string_lossy().into_owned())
        .collect();
    // A prepared root's namespaces live in its data file, not on the disk.
    if let Some(files) = horizon_core::prepared_files::files_under(&data) {
        namespaces.extend(
            files
                .iter()
                .filter_map(|f| Some(f.split_once('/')?.0.to_owned())),
        );
    }
    let mut out: Vec<String> = namespaces
        .iter()
        .flat_map(|ns| ids_in(&data.join(ns).join(kind), "json", ns))
        .collect();
    out.sort();
    out
}

/// The templates of every namespace folder under `root` (vanilla's and the
/// content mods'), as `namespace:path`, sorted.
fn templates_under(root: &Path) -> Vec<String> {
    let Ok(namespaces) = std::fs::read_dir(root) else {
        return Vec::new();
    };
    let mut out: Vec<String> = namespaces
        .flatten()
        .filter(|e| e.path().is_dir())
        .flat_map(|e| ids_in(&e.path(), "nbt", &e.file_name().to_string_lossy()))
        .collect();
    out.sort();
    out
}

/// The `namespace:` ids of the `extension` files under `root`, sorted.
fn ids_in(root: &Path, extension: &str, namespace: &str) -> Vec<String> {
    let suffix = format!(".{extension}");
    // A prepared root's folder: from its data file, without listing the disk.
    if let Some(files) = horizon_core::prepared_files::files_under(root) {
        let mut out: Vec<String> = files
            .iter()
            .filter_map(|file| file.strip_suffix(&suffix))
            .filter(|path| !path.is_empty() && !path.ends_with('/'))
            .map(|path| format!("{namespace}:{path}"))
            .collect();
        out.sort();
        return out;
    }
    let mut out = Vec::new();
    let mut stack = vec![root.to_owned()];
    while let Some(dir) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(&dir) else {
            continue;
        };
        for e in entries.flatten() {
            let path = e.path();
            // The listing's own type, without another look at each file; a
            // link is followed, as `Path::is_dir` does.
            let is_dir = e
                .file_type()
                .is_ok_and(|t| t.is_dir() || (t.is_symlink() && path.is_dir()));
            if is_dir {
                stack.push(path);
            } else if path.extension().and_then(|x| x.to_str()) == Some(extension)
                && let Ok(rel) = path.strip_prefix(root)
            {
                out.push(format!(
                    "{namespace}:{}",
                    rel.with_extension("").to_string_lossy().replace('\\', "/")
                ));
            }
        }
    }
    out.sort();
    out
}

/// `SuggestionProviders.SUMMONABLE_ENTITIES`: Entity types available for
/// `/summon` autocomplete, filtering out types that cannot be summoned.
pub(super) fn summonable_entities(
    entity_types: &[String],
    mob_types: impl IntoIterator<Item = impl AsRef<str>>,
) -> Vec<String> {
    let mut summonable: Vec<String> = if !entity_types.is_empty() {
        entity_types
            .iter()
            .filter(|id| !matches!(id.as_str(), "minecraft:player" | "minecraft:fishing_bobber"))
            .cloned()
            .collect()
    } else {
        let mut list: Vec<String> = mob_types
            .into_iter()
            .map(|k| horizon_client::command::args::normalize(k.as_ref()))
            .filter(|id| !matches!(id.as_str(), "minecraft:player" | "minecraft:fishing_bobber"))
            .collect();
        list.extend(
            [
                "minecraft:item",
                "minecraft:experience_orb",
                "minecraft:falling_block",
                "minecraft:arrow",
                "minecraft:lightning_bolt",
                "minecraft:minecart",
                "minecraft:chest_minecart",
                "minecraft:hopper_minecart",
                "minecraft:furnace_minecart",
                "minecraft:tnt_minecart",
                "minecraft:wind_charge",
                "minecraft:breeze_wind_charge",
            ]
            .map(String::from),
        );
        list
    };
    // content mods' thrown types.
    let thrown = horizon_client::projectiles::thrown_types().iter();
    summonable.extend(thrown.map(|t| t.id.to_owned()));
    summonable.sort();
    summonable.dedup();
    summonable
}

impl Game<'_> {
    /// The caches `build_registries` and `join_server` read (`resource_ids`,
    /// `block_properties`, `command_export`, `builtin_registries`), filled on a helper
    /// thread while the title screen is up: the first world opened or server joined
    /// built them in its frame (20 ms of the Join click on an M4 Pro). Whoever needs one
    /// before it is done waits for it, as before.
    pub(super) fn preload_registries(&self) {
        if self.options.dedicated.is_some() {
            return;
        }
        let dirs = [self.options.resources.clone(), self.ui.vanilla_root.clone()];
        let registry = self.pack.assets.registry;
        let spawned = std::thread::Builder::new()
            .name("Registries preload".into())
            .spawn(move || {
                horizon_threads::behind_server();
                super::remote::builtin_registries(&dirs[0]);
                resource_ids(&dirs[0]);
                block_properties(registry);
                for dir in &dirs {
                    if command_export(dir, true).is_some() {
                        break;
                    }
                }
            });
        if let Err(e) = spawned {
            log::warn!("Horizon: registries preload: {e}");
        }
    }
    /// `PlayerList.isOp` for the single-player owner: the world's Allow Commands.
    pub(super) fn allow_commands(&self) -> bool {
        self.level.allow_commands == Some(true)
    }
    /// `IntegratedServer.setWorldAllowCommands`, then `updatePermissions`.
    pub(super) fn set_allow_commands(&mut self, allow: bool) {
        self.level.allow_commands = Some(allow);
        self.ui.registries.permission = owner_permission(allow);
    }
    /// Commands the game issues itself (the server console, harnesses, the
    /// control socket) run at the owner's level whatever Allow Commands says.
    pub(super) fn as_console<T>(&mut self, f: impl FnOnce(&mut Self) -> T) -> T {
        let level = std::mem::replace(&mut self.ui.registries.permission, 4);
        let out = f(self);
        self.ui.registries.permission = level;
        out
    }
    /// Active enchantment registry snapshot for command codecs and completions.
    /// Replace both ID views; keep the existing registry tags intact.
    pub(super) fn sync_enchantment_registries(&mut self) {
        let mut ids: Vec<String> = self
            .enchantments()
            .list
            .iter()
            .map(|entry| entry.id.to_string())
            .collect();
        ids.sort();
        ids.dedup();
        self.ui.registries.enchantments = ids.clone();
        self.ui
            .registries
            .by_registry
            .entry("minecraft:enchantment".into())
            .or_default()
            .ids = ids;
    }
    /// `ResourceOrIdArgument`'s loot tables are the server's: every table the
    /// world plays with, the game's, the content mods' and its packs'.
    pub(super) fn sync_loot_table_ids(&mut self) {
        let mut ids: Vec<String> = self.items().loot_table_ids().map(str::to_owned).collect();
        ids.sort();
        self.ui.registries.loot_tables = ids;
    }
    /// Registry contents for argument parsing (built when a world opens).
    pub(super) fn build_registries(&mut self) {
        let permission = owner_permission(self.allow_commands());
        let reg = &mut self.ui.registries;
        reg.permission = permission;
        let ids = resource_ids(&self.options.resources);
        self.ui.registries.recipes = ids.recipes.clone();
        self.ui.registries.damage_types = self
            .health_resources
            .damage
            .entries()
            .map(|(_, d)| d.name.clone())
            .collect();
        self.sync_loot_table_ids();
        // ResourceOrIdArgument decodes an inline feature while the command is
        // parsed, with the codec and blocks placement uses (the live features
        // never change once installed).
        self.ui.registries.inline_feature =
            self.res
                .behaviours()
                .live_features()
                .cloned()
                .map(|features| {
                    horizon_client_core::registries::InlineFeatureCheck::new(move |tag| {
                        let json = horizon_client::scoreboard::tag_to_json(tag).to_string();
                        features
                            .decode_inline(&json)
                            .map(drop)
                            .map_err(|e| e.to_string())
                    })
                });
        self.ui.registries.templates = ids.templates.clone();
        self.ui.registries.sounds = self.audio.event_names();
        self.ui.registries.attributes = [
            "armor",
            "armor_toughness",
            "attack_damage",
            "attack_knockback",
            "attack_speed",
            "block_break_speed",
            "block_interaction_range",
            "burning_time",
            "camera_distance",
            "explosion_knockback_resistance",
            "entity_interaction_range",
            "fall_damage_multiplier",
            "flying_speed",
            "follow_range",
            "gravity",
            "jump_strength",
            "knockback_resistance",
            "luck",
            "max_absorption",
            "max_health",
            "mining_efficiency",
            "movement_efficiency",
            "movement_speed",
            "oxygen_bonus",
            "safe_fall_distance",
            "scale",
            "sneaking_speed",
            "spawn_reinforcements",
            "step_height",
            "submerged_mining_speed",
            "sweeping_damage_ratio",
            "tempt_range",
            "water_movement_efficiency",
        ]
        .iter()
        .map(|a| format!("minecraft:{a}"))
        .collect();
        let reg = &mut self.ui.registries;
        let mut items: Vec<String> = self
            .res
            .items()
            .order
            .iter()
            .map(|s| s.to_string())
            .collect();
        items.sort();
        reg.items = items;
        reg.item_tags = self
            .res
            .items()
            .item_tags
            .keys()
            .map(|k| horizon_client::command::args::normalize(k))
            .collect();
        reg.item_tags.sort();
        reg.block_tags = self
            .res
            .items()
            .block_tags
            .keys()
            .map(|k| horizon_client::command::args::normalize(k))
            .collect();
        reg.block_tags.sort();
        reg.blocks = BlockProperties::clone(&block_properties(self.pack.assets.registry));
        reg.summonable = summonable_entities(&ids.entity_types, self.res.mob_types().keys());
        let mut types = ids.entity_types.clone();
        if types.is_empty() {
            types = reg.summonable.clone();
            types.push("minecraft:player".into());
            types.sort();
        }
        reg.entity_types = types;
        // The mob effect registry: every effect `/effect` and the
        // `mob_effect` resource arguments accept.
        reg.effects = horizon_client::brewing::all_effects()
            .map(|e| horizon_client::brewing::namespaced(e.id).to_owned())
            .collect();
        reg.effects.sort();
        reg.enchantments = ids.enchantments.clone();
        reg.structures = ids.structures.clone();
        reg.biomes = ids.biomes.clone();
        reg.clocks = ids.clocks.clone();
        reg.dimensions = vec![
            "minecraft:overworld".into(),
            "minecraft:the_nether".into(),
            "minecraft:the_end".into(),
        ];
        reg.players = vec![PLAYER_NAME.into()];
        // Timelines of the overworld clock and their time markers.
        self.ui.timelines = ids.timelines.iter().cloned().collect();
        self.ui.markers = ids.markers.iter().cloned().collect();
        // Vanilla's built-in registries (mob effects, components, dialogs...).
        for dir in [&self.options.resources, &self.ui.vanilla_root] {
            if let Some(export) = command_export(dir, self.options.dedicated.is_none()) {
                self.ui.registries.fill_from_exported(&export);
                break;
            }
        }
        let reg = &mut self.ui.registries;
        reg.timelines = self.ui.timelines.keys().cloned().collect();
        reg.time_markers = self
            .ui
            .markers
            .iter()
            .filter(|(_, m)| m.show)
            .map(|(k, _)| k.clone())
            .collect();
        self.sync_enchantment_registries();
        // After the export, which keys the registry with vanilla's tags.
        self.ui.registries.sync_damage_type_ids();
        // The world's packs' item and block tags join vanilla's, as
        // `TagLoader` binds them before the commands exist.
        self.sync_pack_tag_ids();
    }
    /// The registry snapshot `ServerCommandSuggestionsProvider` answers from,
    /// with the named random sequences the world has now
    /// (`RandomSequences.forAllSequences` fills `/random`'s `sequence`
    /// argument from the live list).
    pub(super) fn suggestion_registries(&mut self) -> &mut Registries {
        self.ui.registries.random_sequences = self.rand_sequences.ids();
        &mut self.ui.registries
    }
    /// The block the player is looking at, for coordinate suggestions, and
    /// the entity, for entity arguments (ClientSuggestionProvider).
    /// `ClientSuggestionProvider.getRelevantCoordinates` and
    /// `getAbsoluteCoordinates` read `Minecraft.hitResult` only when it is a
    /// block: an entity in front of the block leaves the `~` defaults.
    fn refresh_dynamic_registries(&mut self) {
        let hit = if self.pick_entity_hit().is_some() {
            None
        } else {
            self.pick()
        };
        self.ui.registries.target_block = hit.as_ref().map(|h| h.pos);
        self.ui.registries.target_point =
            hit.map(|h| h.point.map(horizon_client::java_text::format_fixed2));
        self.ui.registries.selected_entities = self.crosshair_entity_uuid().into_iter().collect();
        // ClientPacketListener.getOnlinePlayerNames on a server.
        if let Some(names) = self.remote_online_names() {
            self.ui.registries.players = names;
        }
        self.ui.registries.custom_completions = self.remote_custom_completions();
    }
    /// `ChatComponent.createScreen`: T or / opens the chat with the draft kept
    /// last time, when this method can restore it (a command draft only for
    /// /), else with its prefix.
    pub(super) fn open_chat_method(&mut self, prefix: &str) {
        // handleKeybinds: the number keys select before key.chat and key.command.
        self.select_queued_hotbar();
        let command = prefix == "/";
        let draft = self
            .ui
            .chat_draft
            .as_ref()
            .filter(|d| !command || d.command)
            .map(|d| d.text.clone());
        self.open_chat(draft.as_deref().unwrap_or(prefix), draft.is_some());
        self.ui.chat_draft_shown = draft.is_some() && self.ui.chat_screen.is_some();
    }
    /// Open the chat box on `initial`; `is_draft` when that text is the saved
    /// draft (`ChatComponent.createScreen`), which draws grey italic until it
    /// is edited.
    pub(super) fn open_chat(&mut self, initial: &str, is_draft: bool) {
        if self.player.is_none() {
            return;
        }
        self.ui.chat_draft_shown = false;
        self.refresh_dynamic_registries();
        let size = self
            .renderer
            .as_ref()
            .map_or([1280, 720], |r| [r.config.width, r.config.height]);
        let b = HudBatch::new(size);
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        let mut screen = ChatScreen::new(
            &m,
            &c,
            initial,
            is_draft,
            self.ui.chat.recent.len(),
            b.width as i32,
            b.height as i32,
            self.chat_abilities(),
        );
        screen.auto_suggestions = self.settings.auto_suggestions;
        self.ui.chat_screen = Some(screen);
        self.ui.chat_opened = Some(std::time::Instant::now());
        self.screen = Screen::Chat;
        self.keys.clear();
        self.left = false;
        self.right = false;
        self.capture(false);
    }
    /// The open chat box's text and its cursor, counted in characters; `None`
    /// while the chat screen isn't open. API 559.
    #[allow(dead_code)]
    pub(super) fn native_chat_input(&self) -> Option<(String, usize)> {
        let screen = self.ui.chat_screen.as_ref()?;
        Some((screen.input.value.clone(), screen.input.cursor))
    }
    /// Replaces the open chat box's text and puts the cursor at `cursor`
    /// (characters, clamped to the text), as an edit: completions refresh as
    /// they do for typing. What typing can't put in the box isn't put there
    /// either (`chat_box_text`), and the 256-character limit holds. An error
    /// while the chat screen isn't open. API 559.
    #[allow(dead_code)]
    pub(super) fn native_set_chat_input(
        &mut self,
        text: &str,
        cursor: usize,
    ) -> Result<(), String> {
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        let Some(screen) = self.ui.chat_screen.as_mut() else {
            return Err("the chat isn't open".into());
        };
        screen.suggest_command(&m, &c, &chat_box_text(text));
        screen.input.move_cursor_to(&m, cursor, false);
        Ok(())
    }
    pub(super) fn close_chat(&mut self, reason: ChatExit) {
        // InBedChatScreen.onClose: leaving the screen means getting up; the
        // screen goes once the player has woken (`tick_in_bed_chat`).
        if self.ui.in_bed_chat && self.sleeping.is_some() {
            self.wake_up();
            return;
        }
        let text = self
            .ui
            .chat_screen
            .as_ref()
            .map_or_else(String::new, |s| s.value().to_owned());
        self.keep_chat_draft(&text, reason);
        self.ui.chat_draft_shown = false;
        self.ui.chat_screen = None;
        self.ui.chat.reset_scroll();
        if self.screen == Screen::Chat {
            self.screen = Screen::Playing;
            self.capture(true);
        }
    }
    /// `ChatScreen.removed`: the text left in the box becomes the draft unless
    /// `shouldDiscardDraft` (closed on purpose without Save Chat Drafts, or
    /// sent); blank text discards the draft. A draft still shown unchanged
    /// stays as it is.
    fn keep_chat_draft(&mut self, text: &str, reason: ChatExit) {
        // During PvP & HUD's chat search the box holds the query: the draft is the text the
        // search put aside, whichever way the chat closed.
        let aside;
        let text = if self.pvp.chat_search {
            self.pvp.chat_search = false;
            aside = std::mem::take(&mut self.pvp.chat_search_aside);
            aside.as_str()
        } else {
            text
        };
        let unchanged =
            self.ui.chat_draft_shown && self.ui.chat_draft.as_ref().is_some_and(|d| d.text == text);
        if should_discard_draft(reason, self.settings.file.bool("saveChatDrafts"))
            || text.trim().is_empty()
        {
            self.ui.chat_draft = None;
        } else if !unchanged {
            self.ui.chat_draft = Some(ChatDraft {
                text: text.to_owned(),
                command: text.starts_with('/'),
            });
        }
    }
    /// `Gui.tick`: a sleeper gets `InBedChatScreen`; when the player has
    /// woken (`onPlayerWokeUp`) it closes, or turns into the plain chat
    /// screen if something was typed.
    pub(super) fn tick_in_bed_chat(&mut self) {
        // Another screen took over the open chat (death, a container the
        // server opened): `ChatScreen.removed` runs with the INTERRUPTED reason.
        if self.screen != Screen::Chat && self.ui.chat_screen.is_some() {
            let text = self
                .ui
                .chat_screen
                .as_ref()
                .map_or_else(String::new, |s| s.value().to_owned());
            self.keep_chat_draft(&text, ChatExit::Interrupted);
            self.ui.chat_draft_shown = false;
            self.ui.chat_screen = None;
            self.ui.chat.reset_scroll();
        }
        if self.screen != Screen::Chat {
            self.ui.in_bed_chat = false;
        }
        if self.ui.in_bed_chat {
            if self.sleeping.is_none() {
                self.ui.in_bed_chat = false;
                let text = self
                    .ui
                    .chat_screen
                    .as_ref()
                    .map_or_else(String::new, |s| s.value().to_owned());
                self.close_chat(ChatExit::Interrupted);
                if !text.is_empty() {
                    // InBedChatScreen.onPlayerWokeUp: a new ChatScreen with
                    // the typed text, not a draft.
                    self.open_chat(&text, false);
                }
            }
        } else if self.sleeping.is_some() && self.screen == Screen::Playing {
            self.open_chat("", false);
            self.ui.in_bed_chat = self.screen == Screen::Chat;
        }
    }
    /// The Leave Bed button of `InBedChatScreen`: its bounds.
    fn leave_bed_button(width: f32, height: f32) -> (i32, i32, i32, i32) {
        (width as i32 / 2 - 100, height as i32 - 40, 200, 20)
    }
    /// The Leave Bed button's draws. It registers as a button
    /// (`widgets::record`), so the pad's and the keyboard's focus reach it (the
    /// pad's starts on it) and `horizon-ctl click-button` finds it.
    fn leave_bed_draws(
        m: &Measure,
        mouse: (i32, i32),
        width: f32,
        height: f32,
    ) -> Vec<horizon_client::screen_draw::Draw> {
        let (x, y, w, h) = Self::leave_bed_button(width, height);
        let label = Text::literal(horizon_client::lang::get_or(
            "multiplayer.stopSleeping",
            "Leave Bed",
        ));
        horizon_client::widgets::record(
            &label.plain(),
            [x as f32, y as f32, w as f32, h as f32],
            true,
        );
        let mut button = Vec::new();
        horizon_client::screen_draw::button(
            &mut button,
            m,
            &label,
            x,
            y,
            w,
            h,
            true,
            horizon_client::screen_draw::inside(mouse, x, y, w, h),
            horizon_client::hud_overlays::now_ms(),
        );
        button
    }
    /// `Minecraft.computeChatAbilities` from the Chat option.
    pub(super) fn chat_abilities(&self) -> ChatAbilities {
        ChatAbilities::new(ChatVisibility::from_option(self.settings.chat_visibility))
    }
    /// A chat message from the game (ChatComponent.addServerSystemMessage).
    pub(super) fn system_message(&mut self, text: Text) {
        if let Some(capture) = self.chat_capture.as_mut() {
            capture.push(text);
            return;
        }
        // Connected to a server (single player's own included), the chat on
        // screen is the connection's: the game's own messages join it.
        if self.remote.is_some() {
            self.chat_line(text, ChatSource::Server);
            return;
        }
        // The Chat option's Hidden level takes the server's messages too.
        self.local_chat_line(text, Some(SYSTEM_INDICATOR), ChatSource::Server);
    }
    /// A player's chat line on the window's own chat: a guest's message on
    /// the server's own chat (`HostEvent::Chat`). `ChatListener`
    /// checks `canReceivePlayerMessages` for these, so Commands Only and
    /// Hidden drop them; command feedback (`/list`, `/tp`) is a system
    /// message and takes the system-message permission instead.
    pub(super) fn player_message(&mut self, text: Text) {
        if let Some(capture) = self.chat_capture.as_mut() {
            capture.push(text);
            return;
        }
        // A server's client receives the line as a packet (PlayerChat or
        // DisguisedChat) and filters it there.
        if self.remote.is_none() {
            self.local_chat_line(text, None, ChatSource::Player);
        }
    }
    /// A line on the window's own chat when the Chat option lets `source`
    /// through.
    fn local_chat_line(&mut self, text: Text, indicator: Option<u32>, source: ChatSource) {
        if !self.ui.chat.shows(source) {
            return;
        }
        let focused = self.screen == Screen::Chat;
        self.ui.chat.add(
            &self.gui.atlas,
            text,
            indicator,
            source,
            self.visual_ticks(),
            focused,
        );
    }
    /// Keys while the chat screen is open.
    pub(super) fn chat_key(&mut self, event: &KeyEvent) {
        if let Some(shortcut) = self.edit_shortcut(event) {
            let m = Measure(&self.gui.atlas.font);
            let c = Commands {
                dispatcher: chat_tree(&self.remote),
                registries: &self.ui.registries,
            };
            if let Some(screen) = self.ui.chat_screen.as_mut() {
                screen.shortcut(&m, &c, shortcut, &mut self.clipboard);
            }
            return;
        }
        let PhysicalKey::Code(key) = event.physical_key else {
            return;
        };
        self.chat_key_code(key, event.text.as_deref());
    }
    /// A key (and the text it typed) while the chat screen is open.
    pub(super) fn chat_key_code(&mut self, key: KeyCode, typed_text: Option<&str>) {
        // The live modifiers, not `self.keys`: every ModifiersChanged runs
        // sync_toggle, which drops ShiftLeft and ControlLeft from `self.keys`
        // while a screen is open.
        let ctrl = self.has_control_down_with_quirk();
        let shift = self.has_shift_down();
        // PvP & HUD's chat search: Ctrl+F starts and stops it, Enter stops it (sends nothing).
        if self.pvp_chat().search
            && match key {
                KeyCode::KeyF => ctrl,
                KeyCode::Enter | KeyCode::NumpadEnter => self.pvp.chat_search,
                _ => false,
            }
        {
            self.toggle_chat_search();
            return;
        }
        match key {
            // ChatScreen.keyPressed: the chat scrolls a page.
            KeyCode::PageUp | KeyCode::PageDown
                if !self
                    .ui
                    .chat_screen
                    .as_ref()
                    .is_some_and(|s| s.suggestions_visible()) =>
            {
                let n = self.ui.chat.lines_per_page(true) as i32 - 1;
                self.ui
                    .chat
                    .scroll_by(if key == KeyCode::PageUp { n } else { -n }, true);
                return;
            }
            _ => {}
        }
        let Some(mut screen) = self.ui.chat_screen.take() else {
            return;
        };
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        match screen.key(&m, &c, &self.ui.chat.recent, key, shift, ctrl) {
            ChatAction::Close => {
                // Escape: the box still holds its text, which close_chat keeps as the draft
                // (a search's query gives way to the text it put aside: keep_chat_draft).
                self.ui.chat_screen = Some(screen);
                self.close_chat(ChatExit::Intentional);
            }
            ChatAction::Submit(message) => {
                // InBedChatScreen sends without closing (`closeOnSubmit` is
                // false): the box empties and the screen stays.
                if self.ui.in_bed_chat && self.sleeping.is_some() {
                    screen.suggest_command(&m, &c, "");
                    self.ui.chat.reset_scroll();
                    self.ui.chat_screen = Some(screen);
                } else {
                    // The screen is taken here, so close_chat sees no text: a sent
                    // message discards the draft (DONE).
                    self.close_chat(ChatExit::Done);
                }
                if !message.is_empty() {
                    self.handle_chat_input(&message);
                }
            }
            ChatAction::None => {
                // charTyped: the text the key typed.
                if let Some(text) = typed_text
                    && self.types_text()
                {
                    screen.type_text(&m, &c, text);
                }
                self.ui.chat_screen = Some(screen);
            }
        }
        self.notify_chat_suggestion_completion();
    }
    fn notify_chat_suggestion_completion(&mut self) {
        if let Some(completion) = self
            .ui
            .chat_screen
            .as_mut()
            .and_then(ChatScreen::take_suggestion_completion)
        {
            self.native_chat_suggestion_applied(
                &completion.original,
                completion.range.0,
                completion.range.1,
                &completion.text,
                &completion.input,
            );
        }
    }
    /// The server's completions for an `ask_server` request
    /// (ClientPacketListener.handleCommandSuggestions).
    pub(super) fn chat_server_suggestions(
        &mut self,
        id: i32,
        range: (usize, usize),
        list: Vec<(String, Option<String>)>,
    ) {
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        if let Some(screen) = self.ui.chat_screen.as_mut() {
            screen.server_suggestions(&m, &c, id, range, list);
        }
    }
    /// Text typed into the chat box (control socket `chat`).
    pub(super) fn chat_type(&mut self, text: &str) {
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        if let Some(screen) = self.ui.chat_screen.as_mut() {
            screen.type_text(&m, &c, text);
        }
    }
    /// ChatScreen.handleChatInput: the message comes in normalized
    /// (`normalizeChatMessage`: trimmed, whitespace runs collapsed, cut to the
    /// 256 UTF-16 units the packet holds), into history, then as a command or
    /// a chat line. The Chat option's restrictions stop the message here too,
    /// so a control-socket `chat` cannot send what the player's setting hides.
    pub(super) fn handle_chat_input(&mut self, message: &str) {
        let message = normalize_chat_message(message);
        if message.is_empty() || !self.chat_abilities().allows(&message) {
            return;
        }
        self.ui.chat.add_recent(&message);
        if let Some(args) =
            horizon_profiler_args(&message, self.remote.as_ref().map(|r| &r.chat_tree))
        {
            self.profiler_chat(args);
            return;
        }
        // On a server (single player's own included) the server runs it,
        // unless a client mod owns the command.
        if self.remote.is_some() {
            if let Some(command) = message.strip_prefix('/')
                && self.client_mod_command(command)
            {
                return;
            }
            self.send_chat(&message);
            return;
        }
        if let Some(command) = message.strip_prefix('/') {
            // A native mod's command first.
            if !self.client_mod_command(command) {
                self.run_command(command);
            }
        } else {
            let line = Text::translate(
                "chat.type.text",
                &[self.player_display_name(), Text::literal(message.as_str())],
            );
            let focused = self.screen == Screen::Chat;
            self.ui.chat.add(
                &self.gui.atlas,
                line,
                None,
                ChatSource::Player,
                self.visual_ticks(),
                focused,
            );
        }
    }
    pub(super) fn chat_scroll(&mut self, amount: f32) {
        let cursor = self.cursor;
        let height = self.renderer.as_ref().map_or(720.0, |r| {
            HudBatch::new([r.config.width, r.config.height]).height
        });
        let _ = height;
        let mouse = (cursor.0.floor() as i32, cursor.1.floor() as i32);
        if let Some(screen) = self.ui.chat_screen.as_mut()
            && screen.scroll(mouse, amount as f64)
        {
            return;
        }
        // ChatScreen.mouseScrolled: `hasShiftDown`, either Shift key.
        let shift = self.has_shift_down();
        let amount = amount.clamp(-1.0, 1.0) * if shift { 1.0 } else { 7.0 };
        self.ui.chat.scroll_by(amount as i32, true);
    }
    pub(super) fn chat_click(&mut self) {
        let cursor = self.cursor;
        let height = self.renderer.as_ref().map_or(720.0, |r| {
            HudBatch::new([r.config.width, r.config.height]).height
        });
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        if self.ui.in_bed_chat && self.sleeping.is_some() {
            let width = self.renderer.as_ref().map_or(1280.0, |r| {
                HudBatch::new([r.config.width, r.config.height]).width
            });
            let (x, y, w, h) = Self::leave_bed_button(width, height);
            if horizon_client::screen_draw::inside((cursor.0 as i32, cursor.1 as i32), x, y, w, h) {
                self.wake_up();
                return;
            }
        }
        if let Some(screen) = self.ui.chat_screen.as_mut() {
            if screen.click(&m, &c, cursor.0 as f64, cursor.1 as f64) {
                self.notify_chat_suggestion_completion();
                return;
            }
        } else {
            return;
        }
        let style = self
            .ui
            .chat
            .style_at(
                &self.gui.atlas.font,
                height as i32,
                cursor.0 as f64,
                cursor.1 as f64,
            )
            .or_else(|| {
                self.ui.chat.queue_style_at(
                    &self.gui.atlas.font,
                    height as i32,
                    cursor.0 as f64,
                    cursor.1 as f64,
                )
            });
        // PvP & HUD's copy on click: a message where the click has nothing else to do.
        if self.pvp_chat().copy
            && !self.has_shift_down()
            && style.as_ref().is_none_or(|s| s.click.is_none())
            && let Some(message) =
                self.ui
                    .chat
                    .message_at(height as i32, cursor.0 as f64, cursor.1 as f64)
        {
            use horizon_client::clipboard::Clipboard;
            self.clipboard.set(message);
            let copied =
                Text::translate_with_fallback("horizon.chat.copied", "Message copied", &[]);
            self.titles.set_overlay(copied, false);
            return;
        }
        let Some(style) = style else {
            return;
        };
        // ChatScreen.handleComponentClicked: with Shift held only an
        // insertion acts, else only the click event.
        if self.has_shift_down() {
            if let Some(insertion) = style.insertion
                && let Some(screen) = self.ui.chat_screen.as_mut()
            {
                screen.type_text(&m, &c, &insertion);
            }
            return;
        }
        match style.click {
            Some(ClickEvent::CopyToClipboard(value)) => {
                use horizon_client::clipboard::Clipboard;
                self.clipboard.set(&value);
            }
            Some(ClickEvent::OpenFile(path)) => {
                super::packs::open_folder(std::path::Path::new(&path));
            }
            Some(ClickEvent::OpenUrl(url)) => self.click_url(url),
            Some(ClickEvent::SuggestCommand(command)) => {
                if let Some(screen) = self.ui.chat_screen.as_mut() {
                    screen.suggest_command(&m, &c, &command);
                }
            }
            Some(ClickEvent::RunCommand(command)) => self.click_command(&command),
            Some(ClickEvent::Profiler(command)) => {
                if let Some(args) = command
                    .strip_prefix('/')
                    .and_then(super::profile_capture::profiler_args)
                {
                    self.profiler_chat(args);
                }
            }
            // Screen.defaultHandleGameClickEvent: the dialog opens over the
            // screen, and closes back to it.
            Some(ClickEvent::ShowDialog(dialog)) => self.show_dialog_ref(&dialog),
            // Screen.defaultHandleGameClickEvent: custom actions retain chat.
            // ChatScreen.handleComponentClicked: the queue row's internal id
            // shows the next held-back message; other custom ids go on.
            Some(ClickEvent::Custom { id, .. }) if id == QUEUE_EXPAND_ID => {
                self.accept_next_delayed_message();
            }
            Some(ClickEvent::Custom { id, payload }) => {
                if let Some(remote) = &self.remote {
                    remote.session.send_custom_click(&id, payload);
                }
            }
            // Screen.defaultHandleClickEvent: a page link means nothing in chat.
            Some(ClickEvent::ChangePage(_)) | None => {}
        }
    }
    /// `Screen.clickUrlAction`: nothing with Web Links off, else the link
    /// opens, after the confirmation unless Prompt on Links is off.
    pub(super) fn click_url(&mut self, url: String) {
        if !self.settings.chat_links {
            return;
        }
        if self.settings.chat_links_prompt {
            self.link_prompt = Some(url);
        } else {
            super::packs::open_uri(&url);
        }
    }
    /// `ConfirmLinkScreen` (untrusted): the link and its warning over the
    /// chat, answered yes to open it.
    fn link_prompt_layout(
        &self,
        url: &str,
        size: (f32, f32),
    ) -> horizon_client::confirm_screen::Choice {
        let warning = Text::translate("chat.link.warning", &[]).with_color(0xFF_CCCC);
        let message = Text::literal(url)
            .append(Text::literal("\n"))
            .append(warning);
        // ConfirmLinkScreen.addButtons: yes, copy and no, 100 wide each.
        horizon_client::confirm_screen::Choice::new(
            &self.gui.atlas.font,
            size,
            &Text::translate("chat.link.confirm", &[]),
            &message,
            3,
            100.0,
        )
    }
    pub(super) fn draw_link_prompt(&self, batch: &mut HudBatch) {
        let Some(url) = &self.link_prompt else {
            return;
        };
        horizon_client::widgets::cover_frame();
        // ConfirmLinkScreen: the question and the link (its warning is a
        // widget of its own, not narrated).
        horizon_client::widgets::begin_screen(|| {
            super::screen_info::confirm(
                "chat/confirm_link",
                &super::screen_info::tr("chat.link.confirm", &[]),
                url,
            )
        });
        let atlas = &self.gui.atlas;
        let (w, h) = (batch.width, batch.height);
        horizon_client::ui::menu_background(batch, atlas, 0.0, 0.0, w, h, true);
        let labels = [
            Text::translate("gui.yes", &[]),
            Text::translate("chat.copy", &[]),
            Text::translate("gui.no", &[]),
        ];
        let mut layout = self.link_prompt_layout(url, (w, h));
        layout.declare_no(2);
        layout.draw(batch, atlas, self.cursor, &labels);
    }
    /// The prompt's answer: the link opens on yes; either way the chat is back.
    pub(super) fn answer_link_prompt(&mut self, yes: bool) {
        if let Some(url) = self.link_prompt.take()
            && yes
        {
            super::packs::open_uri(&url);
        }
    }
    pub(super) fn link_prompt_click(&mut self) {
        let Some(url) = self.link_prompt.clone() else {
            return;
        };
        let pressed = self
            .link_prompt_layout(&url, self.gui_size())
            .pressed_at(self.cursor);
        if let Some(button) = pressed {
            self.audio.play_button_click();
            if button == LINK_COPY {
                // ConfirmLinkScreen.copyToClipboard, then the callback's no.
                use horizon_client::clipboard::Clipboard;
                self.clipboard.set(&url);
            }
            self.answer_link_prompt(button == LINK_YES);
        }
    }
    /// `Screen.clickCommandAction`: run a clicked command as the player
    /// without adding it to the chat history. A client mod's command goes
    /// first, as `ClientPacketListener.sendUnattendedCommand` lets client
    /// commands take it.
    pub(super) fn click_command(&mut self, command: &str) {
        let command = command.strip_prefix('/').unwrap_or(command);
        if self.client_mod_command(command) {
            return;
        }
        if self.remote.is_some() {
            self.send_unattended_command(command);
        } else {
            self.run_command(command);
        }
    }
    /// PvP & HUD's chat search on or off. The box holds the query: what was typed is put aside
    /// when the search starts and comes back when it stops.
    fn toggle_chat_search(&mut self) {
        let typed = self.ui.chat_screen.as_ref().map(|s| s.value().to_owned());
        let next = if self.pvp.chat_search {
            std::mem::take(&mut self.pvp.chat_search_aside)
        } else {
            self.pvp.chat_search_aside = typed.unwrap_or_default();
            String::new()
        };
        self.pvp.chat_search = !self.pvp.chat_search;
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        if let Some(screen) = self.ui.chat_screen.as_mut() {
            screen.suggest_command(&m, &c, &next);
        }
    }
    /// Chat lines over the HUD (focused while the chat screen is open).
    pub(super) fn draw_chat(&mut self, batch: &mut HudBatch) {
        let focused = self.screen == Screen::Chat;
        let options = self.pvp_chat();
        self.ui.chat.set_qol(&self.gui.atlas, options.qol());
        // A search ends with its option; a chat closed some other way ends it in keep_chat_draft.
        if self.pvp.chat_search && self.ui.chat_screen.is_none() {
            // The chat went without closing (leaving the world): nothing to give back.
            self.pvp.chat_search = false;
            self.pvp.chat_search_aside.clear();
        } else if self.pvp.chat_search && !options.search {
            self.toggle_chat_search();
        }
        let query = self
            .ui
            .chat_screen
            .as_ref()
            .filter(|_| focused && self.pvp.chat_search)
            .map(|s| s.value());
        self.ui.chat.set_search(&self.gui.atlas, query);
        self.ui.chat.search_prompt = focused && self.pvp.chat_search;
        // `ChatComponent`'s queue row: the messages Chat Delay holds back.
        self.ui.chat.queue = self.chat_queue_len();
        if self.ui.hide_gui && !focused {
            return;
        }
        self.ui.chat.smooth = self.settings.extras.chat_animation;
        self.ui.chat.hide_indicator = !self.settings.extras.chat_indicator;
        // The fractional tick makes the smooth chat extra's slide move every
        // frame; vanilla's fade reads it too.
        let now = self.visual_ticks() as f32 + self.clock.fraction() as f32;
        self.ui.chat.draw(batch, &self.gui.atlas, now, focused);
    }
    /// `HoverEvent.EntityTooltipInfo.getTooltipLines`: the name when the
    /// event has one, the entity type and the UUID.
    fn entity_tooltip_lines(entity: &serde_json::Value) -> Vec<(Text, u32)> {
        let mut lines = Vec::new();
        if let Some(name) = entity.get("name") {
            let name = horizon_client::component::to_text(name, &mut |s| Text::literal(s));
            lines.push((name, u32::MAX));
        }
        let id = entity
            .get("id")
            .and_then(serde_json::Value::as_str)
            .unwrap_or_default();
        let kind = Text::translate(&format!("entity.{}", id.replace(':', ".")), &[]);
        lines.push((
            Text::translate("gui.entity_tooltip.type", &[kind]),
            u32::MAX,
        ));
        if let Some(uuid) = entity.get("uuid").and_then(Self::entity_uuid) {
            lines.push((Text::literal(uuid), u32::MAX));
        }
        lines
    }
    /// The UUID of a ShowEntity event: its string, or the int array
    /// `UUIDUtil.CODEC` writes (most significant word first).
    fn entity_uuid(v: &serde_json::Value) -> Option<String> {
        if let Some(s) = v.as_str() {
            return Some(s.to_owned());
        }
        let words = v.as_array().filter(|w| w.len() == 4)?;
        let mut bits = 0u128;
        for w in words {
            bits = (bits << 32) | u128::from(w.as_i64()? as u32);
        }
        Some(horizon_protocol::crypto::uuid_string(bits))
    }
    pub(super) fn draw_chat_screen(&mut self, batch: &mut HudBatch) {
        let Some(mut screen) = self.ui.chat_screen.take() else {
            return;
        };
        // ChatScreen.updateNarrationState: the restricted prompt is
        // `displayMode.showRestrictedPrompt`, the abilities' restrictions.
        let in_bed = self.ui.in_bed_chat && self.sleeping.is_some();
        horizon_client::widgets::begin_screen(|| {
            super::screen_info::chat(
                in_bed,
                screen.value(),
                screen.abilities.any_restriction(),
                &super::screen_info::tr,
            )
        });
        let m = Measure(&self.gui.atlas.font);
        let c = Commands {
            dispatcher: chat_tree(&self.remote),
            registries: &self.ui.registries,
        };
        screen.resize(&m, &c, batch.width as i32, batch.height as i32);
        // Options.getBackgroundColor(Integer.MIN_VALUE).
        let background = if self.settings.file.bool("backgroundForChatOnly") {
            i32::MIN
        } else {
            self.settings.text_background(0.0) as i32
        };
        let mouse = (self.cursor.0.floor() as i32, self.cursor.1.floor() as i32);
        let blink = self
            .ui
            .chat_opened
            .map_or(0, |t| t.elapsed().as_millis() as u64);
        let draws = screen.draw(&m, mouse, blink, background);
        horizon_client::screen_draw::paint(batch, &self.gui.atlas, &draws);
        self.ui.chat_screen = Some(screen);
        if in_bed {
            let button = Self::leave_bed_draws(&m, mouse, batch.width, batch.height);
            horizon_client::screen_draw::paint(batch, &self.gui.atlas, &button);
        }
        // The hovered message part's tooltip (`renderComponentHoverEffect`),
        // or the text of the message tag under the cursor.
        let height = batch.height as i32;
        let (cx, cy) = (f64::from(self.cursor.0), f64::from(self.cursor.1));
        let wrap = (batch.width as i32 / 2).max(200);
        // handleTagIcon: the chat-modified icons over the cursor or its message.
        let (tag_tooltip, tag_icons) =
            self.ui
                .chat
                .focused_tags(&self.gui.atlas.font, height, cx, cy);
        horizon_client::hud_layout::paint(batch, &self.gui.atlas, &tag_icons);
        let style = self
            .ui
            .chat
            .style_at(&self.gui.atlas.font, height, cx, cy)
            .or_else(|| {
                self.ui
                    .chat
                    .queue_style_at(&self.gui.atlas.font, height, cx, cy)
            });
        if let Some(style) = style {
            // ActiveTextCollector.ClickableStyleFinder: a click event, or an
            // insertion while Shift is held (ChatScreen.includeInsertions).
            if style.click.is_some() || (style.insertion.is_some() && self.has_shift_down()) {
                horizon_client::widgets::request_cursor(
                    horizon_client::widgets::Cursor::PointingHand,
                );
            }
            if let Some(hover) = style.hover {
                let lines = self.wrapped_rows(&hover, wrap);
                self.draw_tooltip_lines(batch, &lines, self.cursor.0, self.cursor.1);
            } else if let Some(stack) = style
                .hover_item
                .as_deref()
                .and_then(horizon_client::item_data::stack_from_hover)
                .filter(|s| self.items().get(&s.item).is_some())
            {
                self.draw_stack_tooltip(batch, &stack, self.cursor.0, self.cursor.1);
            } else if let Some(entity) = style
                .hover_entity
                .as_deref()
                .filter(|_| self.settings.file.bool("advancedItemTooltips"))
            {
                // ChatScreen: a ShowEntity tooltip only with advanced tooltips on.
                let lines = Self::entity_tooltip_lines(entity);
                self.draw_tooltip_lines(batch, &lines, self.cursor.0, self.cursor.1);
            }
        } else if let Some(tag) = &tag_tooltip {
            // The message tag's text, split at 210.
            let lines = self.wrapped_rows(tag, 210);
            self.draw_tooltip_lines(batch, &lines, self.cursor.0, self.cursor.1);
        }
    }
    /// `Font.split`: a tooltip text wrapped at `width`, one white row per line.
    pub(super) fn wrapped_rows(&self, text: &Text, width: i32) -> Vec<(Text, u32)> {
        let split = self
            .gui
            .atlas
            .font
            .split(&text.resolve_legacy(), width as f32);
        split.into_iter().map(|row| (row, u32::MAX)).collect()
    }
    /// Advance every clock (`ServerClockManager.tick`) when `advance_time`
    /// allows it.
    pub(super) fn advance_clock(&mut self) {
        if !self.ui.rules.bool("advance_time") {
            return;
        }
        Self::tick_clock(&mut self.ui.clock, &mut self.world.day_time);
        Self::tick_clock(&mut self.ui.end_clock, &mut self.world.end_clock);
    }
    /// `ServerClockInstance.tick`: the rate's fraction adds up, whole ticks
    /// move the total.
    fn tick_clock(c: &mut WorldClock, total: &mut i64) {
        if c.paused {
            return;
        }
        c.partial += c.rate;
        let whole = c.partial.floor();
        c.partial -= whole;
        *total += whole as i64;
    }
    /// `ServerClockManager.getInstance`: the clock a key names, as `/time`
    /// addresses it.
    pub(super) fn command_clock_time(&self, clock: &str) -> i64 {
        match clock {
            "minecraft:overworld" => self.world.day_time,
            "minecraft:the_end" => self.world.end_clock,
            _ => self.ui.command_clocks.get(clock).map_or(0, |c| c.0),
        }
    }
    pub(super) fn set_command_clock_time(&mut self, clock: &str, total: i64) {
        match clock {
            "minecraft:overworld" => self.world.day_time = total,
            "minecraft:the_end" => self.world.end_clock = total,
            _ => {
                self.ui
                    .command_clocks
                    .entry(clock.to_owned())
                    .or_default()
                    .0 = total;
            }
        }
    }
    pub(super) fn command_clock_state(&mut self, clock: &str) -> &mut WorldClock {
        match clock {
            "minecraft:overworld" => &mut self.ui.clock,
            "minecraft:the_end" => &mut self.ui.end_clock,
            _ => {
                &mut self
                    .ui
                    .command_clocks
                    .entry(clock.to_owned())
                    .or_default()
                    .1
            }
        }
    }
    /// `ServerClockInstance.packNetworkState`: the rate players' clients
    /// advance the overworld clock at, 0 while it is paused (`/time pause`)
    /// or `advance_time` is off.
    pub(super) fn network_clock_rate(&self) -> f32 {
        if self.ui.rules.bool("advance_time") && !self.ui.clock.paused {
            self.ui.clock.rate
        } else {
            0.0
        }
    }
    /// The engine-side rule values (block behaviour and health).
    pub(super) fn level_rules(&self) -> horizon_world::level::GameRules {
        let r = &self.ui.rules;
        horizon_world::level::GameRules {
            water_source_conversion: r.bool("water_source_conversion"),
            lava_source_conversion: r.bool("lava_source_conversion"),
            random_tick_speed: r.int("random_tick_speed"),
            block_drops: r.bool("block_drops"),
            mob_griefing: r.bool("mob_griefing"),
            max_snow_accumulation_height: r.int("max_snow_accumulation_height"),
            spawn_mobs: r.bool("spawn_mobs"),
            spawn_monsters: r.bool("spawn_monsters"),
            fire_spread_radius_around_player: r.int("fire_spread_radius_around_player"),
            spread_vines: r.bool("spread_vines"),
        }
    }
    /// Apply rules mirrored in other state (natural regeneration, difficulty).
    pub(super) fn sync_rules(&mut self) {
        self.world.health_rules.natural_regeneration =
            self.ui.rules.bool("natural_health_regeneration");
        // Player.isInvulnerableTo: the damage-type rules.
        self.world.health_rules.drowning_damage = self.ui.rules.bool("drowning_damage");
        self.world.health_rules.fall_damage = self.ui.rules.bool("fall_damage");
        self.world.health_rules.fire_damage = self.ui.rules.bool("fire_damage");
        self.world.health_rules.freeze_damage = self.ui.rules.bool("freeze_damage");
        horizon_client::mobs::sulfur_cube::set_tnt_explodes(self.ui.rules.bool("tnt_explodes"));
        use horizon_world::food::Difficulty;
        self.world.health_rules.difficulty = match self.ui.difficulty {
            0 => Difficulty::Peaceful,
            1 => Difficulty::Easy,
            3 => Difficulty::Hard,
            _ => Difficulty::Normal,
        };
    }
    /// `ServerClockManager.ServerClockInstance.loadFrom`: restore the built-in
    /// clocks when a world opens; clear the other command-state cache.
    pub(super) fn load_world_state(&mut self) {
        self.ui.rules =
            GameRules::load_with_features(&self.world_root, &self.level.enabled_features);
        self.ui.clock = WorldClock::default();
        self.ui.end_clock = WorldClock::default();
        self.ui.command_clocks.clear();
        // PrimaryLevelData: the difficulty comes back from level.dat's difficulty_settings.
        self.ui.difficulty = self.level.difficulty_id();
        if let Ok(bytes) = std::fs::read(self.world_root.join("data/minecraft/world_clocks.dat"))
            && let Ok(raw) = horizon_world::compression::Compression::Gzip.decode(&bytes, 1 << 20)
            && let Ok((root, _)) =
                horizon_world::nbt::read_named(&raw, horizon_world::nbt::Limits::default())
        {
            use horizon_world::nbt::Tag;
            for (key, clock) in [
                ("minecraft:overworld", &mut self.ui.clock),
                ("minecraft:the_end", &mut self.ui.end_clock),
            ] {
                let Some(c) = root.tag.get("data").and_then(|d| d.get(key)) else {
                    continue;
                };
                if let Some(Tag::Float(r)) = c.get("rate") {
                    clock.rate = f32::from_bits(*r);
                }
                if let Some(Tag::Float(p)) = c.get("partial_tick") {
                    clock.partial = f32::from_bits(*p);
                }
                if let Some(Tag::Byte(p)) = c.get("paused") {
                    clock.paused = *p != 0;
                }
            }
        }
        self.ui.chat.clear();
        self.build_registries();
        // The world opens with its test instances (`Registries.TEST_INSTANCE`).
        self.snapshot_test_defs();
        self.sync_rules();
    }
    /// Save the clock beside level.dat (Level.write saves the game rules: a
    /// second writer of game_rules.dat could leave it with the rules loaded
    /// when the world opened).
    pub(super) fn save_world_state(&mut self) {
        if self.world_root.as_os_str().is_empty() {
            return;
        }
        use horizon_world::nbt::Tag;
        // The other clocks stay as saved; the built-in ones keep the fields
        // Horizon does not model, and (like vanilla's codec) omit rate, partial
        // tick and pause while they have their defaults.
        let path = self.world_root.join("data/minecraft/world_clocks.dat");
        let existing = horizon_client::save::read_dat(&path);
        let mut data = match existing.as_ref().and_then(|r| r.get("data")) {
            Some(d @ Tag::Compound(_)) => d.clone(),
            _ => Tag::Compound(Default::default()),
        };
        for (key, total, c) in [
            ("minecraft:overworld", self.world.day_time, self.ui.clock),
            ("minecraft:the_end", self.world.end_clock, self.ui.end_clock),
        ] {
            let mut clock = match data.get(key) {
                Some(c @ Tag::Compound(_)) => c.clone(),
                _ => Tag::Compound(Default::default()),
            };
            if let Tag::Compound(map) = &mut clock {
                map.insert("total_ticks".into(), Tag::Long(total));
                for (field, value, default) in [
                    (
                        "partial_tick",
                        Tag::Float(c.partial.to_bits()),
                        c.partial == 0.0,
                    ),
                    ("rate", Tag::Float(c.rate.to_bits()), c.rate == 1.0),
                    ("paused", Tag::Byte(i8::from(c.paused)), !c.paused),
                ] {
                    if default {
                        map.remove(&field.into());
                    } else {
                        map.insert(field.into(), value);
                    }
                }
            }
            if let Tag::Compound(map) = &mut data {
                map.insert(key.into(), clock);
            }
        }
        let root = Tag::compound([
            ("data", data),
            ("DataVersion", Tag::Int(horizon_world::DATA_VERSION)),
        ]);
        if let Err(e) = horizon_client::save::write_dat(&path, root) {
            log::warn!("the world clocks were not written: {e}");
        }
    }
    /// F1 hides the HUD (see `hud`); the screenshot key still works.
    pub(super) fn toggle_hide_gui(&mut self) {
        self.ui.toggle_hide_gui();
    }
    /// F2: ScreenShot.grab into `screenshots/` with vanilla's file name. The
    /// file it will write, `None` without a window to draw.
    pub(super) fn take_screenshot(&mut self) -> Option<std::path::PathBuf> {
        // Its grab would take a sequence's frame.
        if self.screenshot_sequence.is_some() {
            return None;
        }
        let dir = horizon_client::logging::player_dir().join("screenshots");
        if std::fs::create_dir_all(&dir).is_err() {
            return None;
        }
        // A screenshot still being written has no file yet: its name is taken all the same.
        let name = screenshot_name(&dir, &self.ui.screenshot_messages);
        let renderer = self.renderer.as_mut()?;
        let path = dir.join(name);
        renderer.screenshot = Some(horizon_client::gfx::ScreenshotRequest {
            path: path.clone(),
            size: None,
            scaled: true,
            background: true,
        });
        self.ui.screenshot_messages.push(path.clone());
        Some(path)
    }
    /// `Minecraft.handleGlobalKeyPress`'s screenshot branch: the
    /// `key.screenshot` mapping (F2 by default) takes the picture before a
    /// screen or a text box sees the key, and the debug modifier suppresses it.
    pub(super) fn screenshot_shortcut(&mut self, key: KeyCode, repeat: bool) -> bool {
        if repeat
            || horizon_client::keybinds::key_name(key)
                != Some(self.settings.keys.get("key.screenshot"))
        {
            return false;
        }
        self.screenshot_action()
    }
    /// key.screenshot from any device: not while F3 is down, where F3+F2 is a
    /// debug key.
    pub(super) fn screenshot_action(&mut self) -> bool {
        if self.debug_keys.modifier_down {
            return false;
        }
        self.take_screenshot();
        true
    }
    /// A screenshot written on its thread: F2's reports in chat. Any other was the world
    /// icon's (`tick_world_icon`): a failure tries again a second later, as
    /// `tryTakeScreenshotIfNeeded` does.
    pub(super) fn finish_screenshot(&mut self, saved: horizon_client::gfx::SavedScreenshot) {
        let Some(at) = self
            .ui
            .screenshot_messages
            .iter()
            .position(|p| *p == saved.path)
        else {
            if let Err(error) = saved.result {
                log::warn!("Horizon: couldn't save the world icon: {error}");
            }
            return;
        };
        let path = self.ui.screenshot_messages.remove(at);
        let message = match &saved.result {
            Ok(_) => {
                log::info!("Saved screenshot to {}", path.display());
                let name = path.file_name().unwrap_or_default().to_string_lossy();
                let link = Text::styled(
                    name,
                    Style {
                        underlined: Some(true),
                        click: Some(ClickEvent::OpenFile(path.to_string_lossy().into_owned())),
                        ..Style::default()
                    },
                );
                Text::translate("screenshot.success", &[link])
            }
            Err(e) => Text::translate("screenshot.failure", &[Text::literal(e.clone())]),
        };
        let focused = self.screen == Screen::Chat;
        self.ui.chat.add(
            &self.gui.atlas,
            message,
            None,
            ChatSource::Client,
            self.visual_ticks(),
            focused,
        );
    }
}
/// `yyyy-MM-dd_HH.mm.ss[_n].png` (Util.getFilenameFormattedDateTime, in local time).
/// What a mod may write into the chat box: the characters `ChatScreen`'s
/// typing lets in (`StringUtil.isAllowedChatCharacter`: no control
/// characters, no DEL, no section sign).
fn chat_box_text(text: &str) -> String {
    text.chars()
        .filter(|&ch| ch >= ' ' && ch != '\u{7f}' && ch != '§')
        .collect()
}
pub fn screenshot_name(dir: &std::path::Path, pending: &[std::path::PathBuf]) -> String {
    // Util.getFilenameFormattedDateTime: the local date and time.
    let base = chrono::Local::now().format("%Y-%m-%d_%H.%M.%S").to_string();
    let mut n = 1;
    loop {
        let name = if n == 1 {
            format!("{base}.png")
        } else {
            format!("{base}_{n}.png")
        };
        let path = dir.join(&name);
        if !path.exists() && !pending.contains(&path) {
            return name;
        }
        n += 1;
    }
}

/// `IntegratedServer.getProfilePermissions` for the owner: `OWNER` (4) when
/// commands are allowed, else `ALL` (0).
fn owner_permission(allow_commands: bool) -> u8 {
    if allow_commands { 4 } else { 0 }
}

/// `ConfirmLinkScreen`'s buttons, left to right: yes, copy, no.
const LINK_YES: usize = 0;
const LINK_COPY: usize = 1;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_typed_profiler_is_the_clients_unless_the_server_owns_the_name() {
        let vanilla = horizon_client::command::vanilla::game_dispatcher();
        let ours = vanilla.with_profiler();
        assert_eq!(
            super::horizon_profiler_args("/profiler share", Some(&ours)),
            Some(" share")
        );
        assert_eq!(super::horizon_profiler_args("/profiler", None), Some(""));
        assert_eq!(
            super::horizon_profiler_args("/profilers", Some(&ours)),
            None
        );
        let mut server = vanilla.clone();
        let node = server.literal(0, "profiler");
        server.executes(node, "server:profiler");
        let theirs = server.with_profiler();
        assert_eq!(
            super::horizon_profiler_args("/profiler share", Some(&theirs)),
            None
        );
    }

    /// A mod's text reaches the chat box as typing would leave it: emoji and
    /// accents stay, control characters, DEL and the section sign go.
    #[test]
    fn a_mods_chat_text_keeps_what_typing_allows() {
        assert_eq!(
            super::chat_box_text("hi :smile: → 😀 é"),
            "hi :smile: → 😀 é"
        );
        assert_eq!(super::chat_box_text("a\nb\tc\u{7f}d§6e"), "abcd6e");
    }

    /// `ChatScreen.shouldDiscardDraft`.
    #[test]
    fn draft_discard_follows_the_exit_reason() {
        assert!(!should_discard_draft(ChatExit::Interrupted, false));
        assert!(!should_discard_draft(ChatExit::Interrupted, true));
        assert!(should_discard_draft(ChatExit::Intentional, false));
        assert!(!should_discard_draft(ChatExit::Intentional, true));
        assert!(should_discard_draft(ChatExit::Done, true));
    }

    /// `Screenshot.getFile` picks the first free name of the second; an F2
    /// screenshot still being written on its thread has no file yet, so a
    /// second press in the same second takes the next name, not the same one.
    #[test]
    fn a_screenshot_being_written_keeps_its_name() {
        let dir = std::env::temp_dir().join(format!("horizon-shots-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        let first = screenshot_name(&dir, &[]);
        let second = screenshot_name(&dir, &[dir.join(&first)]);
        assert_ne!(first, second);
        // Unless the clock turned to the next second in between.
        let same_second = second.starts_with(first.trim_end_matches(".png"));
        assert!(
            !same_second || second == first.replace(".png", "_2.png"),
            "{second}"
        );
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn resource_ids_are_listed_once_per_root() {
        let root = std::env::temp_dir().join(format!("horizon-ids-{}", std::process::id()));
        let recipe = root.join("data/minecraft/recipe");
        std::fs::create_dir_all(recipe.join("sub")).unwrap();
        std::fs::write(recipe.join("b.json"), "{}").unwrap();
        std::fs::write(recipe.join("sub/a.json"), "{}").unwrap();
        std::fs::write(recipe.join("notes.txt"), "").unwrap();
        let first = resource_ids(&root);
        assert_eq!(first.recipes, ["minecraft:b", "minecraft:sub/a"]);
        std::fs::write(recipe.join("c.json"), "{}").unwrap();
        assert!(Arc::ptr_eq(&first, &resource_ids(&root)));
        let _ = std::fs::remove_dir_all(&root);
    }

    /// A content mod's recipes are suggested with vanilla's, so `/recipe`
    /// offers the ids the recipe index knows.
    #[test]
    fn recipes_of_every_namespace_are_listed() {
        let root = std::env::temp_dir().join(format!("horizon-recipe-ids-{}", std::process::id()));
        for dir in ["data/minecraft/recipe", "data/mymod/recipe/press"] {
            std::fs::create_dir_all(root.join(dir)).unwrap();
        }
        std::fs::write(root.join("data/minecraft/recipe/stick.json"), "{}").unwrap();
        std::fs::write(root.join("data/mymod/recipe/press/iron.json"), "{}").unwrap();
        assert_eq!(
            resource_ids(&root).recipes,
            ["minecraft:stick", "mymod:press/iron"]
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    /// Only the overworld clock's timelines count; a marker is a bare tick
    /// count (hidden from commands) or an object that may show itself.
    #[test]
    fn overworld_timelines_and_markers() {
        let root = std::env::temp_dir().join(format!("horizon-timelines-{}", std::process::id()));
        let dir = root.join("data/minecraft/timeline");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(
            dir.join("day.json"),
            r#"{"clock":"minecraft:overworld","period_ticks":24000,
                "time_markers":{"minecraft:noon":6000,
                "minecraft:night":{"ticks":13000,"show_in_commands":true}}}"#,
        )
        .unwrap();
        std::fs::write(
            dir.join("other.json"),
            r#"{"clock":"minecraft:the_end","time_markers":{"minecraft:x":1}}"#,
        )
        .unwrap();
        std::fs::write(dir.join("broken.json"), "{").unwrap();
        let (timelines, markers) = overworld_timelines(&root);
        assert_eq!(timelines, [("minecraft:day".to_owned(), Some(24000))]);
        let mut markers: Vec<_> = markers
            .iter()
            .map(|(name, m)| (name.as_str(), m.ticks, m.period, m.show))
            .collect();
        markers.sort();
        assert_eq!(
            markers,
            [
                ("minecraft:night", 13000, Some(24000), true),
                ("minecraft:noon", 6000, Some(24000), false),
            ]
        );
        let _ = std::fs::remove_dir_all(&root);
    }

    /// The export is read once per folder; a folder without one stays without.
    #[test]
    fn command_exports_are_read_once_per_folder() {
        let dir = std::env::temp_dir().join(format!("horizon-export-{}", std::process::id()));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("command-registries.json"), r#"{"effects":["a"]}"#).unwrap();
        let first = command_export(&dir, true).unwrap();
        assert_eq!(first.effects, ["a"]);
        std::fs::write(dir.join("command-registries.json"), "{}").unwrap();
        assert!(Arc::ptr_eq(&first, &command_export(&dir, true).unwrap()));
        assert!(command_export(&dir.join("missing"), true).is_none());
        // A dedicated server's read is not kept.
        let other = dir.join("other");
        std::fs::create_dir_all(&other).unwrap();
        std::fs::write(
            other.join("command-registries.json"),
            r#"{"effects":["b"]}"#,
        )
        .unwrap();
        let once = command_export(&other, false).unwrap();
        assert_eq!(once.effects, ["b"]);
        assert!(!Arc::ptr_eq(&once, &command_export(&other, false).unwrap()));
        let _ = std::fs::remove_dir_all(&dir);
    }

    /// A native mod's command is in the tree the chat box uses (#456): known
    /// rather than red, and offered as it types. With no mod claiming one the
    /// tree is the game's own, as it was before the mods were asked.
    #[test]
    fn native_mod_commands_join_the_chat_tree() {
        let reg = Registries::default();
        let vanilla = horizon_client::command::vanilla::game_dispatcher();
        let plain = with_native_commands(vanilla, &[]);
        assert_eq!(plain.nodes.len(), vanilla.nodes.len());
        assert!(plain.find("flyspeed").is_none());
        let tree = with_native_commands(vanilla, &["flyspeed"]);
        assert!(tree.find("flyspeed").is_some());
        // The rest of the line goes to the mod, as `native_command` gets it.
        let parse = tree.parse("flyspeed 4", &reg);
        assert_eq!(
            parse.executable().unwrap().1,
            horizon_client::command::MOD_COMMAND
        );
        let parse = tree.parse("fly", &reg);
        let offered: Vec<String> = tree
            .client_suggestions(&parse, 3, &reg)
            .1
            .into_iter()
            .map(|s| s.text)
            .collect();
        assert!(offered.contains(&"flyspeed".to_owned()), "{offered:?}");
        // A name the game has keeps that command: the chat still knows it.
        let shared = with_native_commands(vanilla, &["help"]);
        assert!(shared.find("help").is_some());
        assert_eq!(
            shared.parse("help", &reg).executable().map(|e| e.1),
            vanilla.parse("help", &reg).executable().map(|e| e.1)
        );
        assert_eq!(shared.nodes.len(), vanilla.nodes.len());
    }

    #[test]
    fn studio_command_tree_suggests_subcommands_and_arguments() {
        let reg = Registries::default();
        let base = horizon_client::command::vanilla::game_dispatcher();
        let tree = with_studio_commands(base);
        let suggestions = |input: &str| {
            let parse = tree.parse(input, &reg);
            tree.client_suggestions(&parse, input.len(), &reg)
                .1
                .into_iter()
                .map(|suggestion| suggestion.text)
                .collect::<Vec<_>>()
        };

        assert_eq!(
            suggestions("studio "),
            ["freecam", "keyframe", "path", "record", "replay"]
        );
        assert_eq!(suggestions("studio record "), ["start", "status", "stop"]);
        assert_eq!(
            suggestions("studio replay "),
            [
                "close", "open", "pause", "resume", "seek", "speed", "status"
            ]
        );
        assert_eq!(suggestions("studio freecam "), ["off", "on"]);
        assert_eq!(suggestions("studio keyframe "), ["add", "clear", "remove"]);
        assert_eq!(suggestions("studio path "), ["lock", "unlock"]);
        assert_eq!(
            tree.parse("studio replay open some-recording.mcpr", &reg)
                .executable()
                .unwrap()
                .1,
            MOD_COMMAND
        );
    }

    /// When `entity_types` is empty (no `entity-types.json`), fallback includes
    /// standard mobs, non-mob entities, and `wind_charge` / `breeze_wind_charge`.
    #[test]
    fn summonable_entities_empty_fallback_includes_mobs_and_non_mobs() {
        let mobs = ["cow", "zombie", "skeleton"];
        let summonable = summonable_entities(&[], mobs);
        assert!(summonable.contains(&"minecraft:cow".to_string()));
        assert!(summonable.contains(&"minecraft:zombie".to_string()));
        assert!(summonable.contains(&"minecraft:skeleton".to_string()));
        assert!(summonable.contains(&"minecraft:item".to_string()));
        assert!(summonable.contains(&"minecraft:arrow".to_string()));
        assert!(summonable.contains(&"minecraft:lightning_bolt".to_string()));
        assert!(summonable.contains(&"minecraft:minecart".to_string()));
        assert!(summonable.contains(&"minecraft:wind_charge".to_string()));
        assert!(summonable.contains(&"minecraft:breeze_wind_charge".to_string()));
    }

    /// Non-summonables `minecraft:player` and `minecraft:fishing_bobber` are
    /// never included in `reg.summonable`.
    #[test]
    fn summonable_entities_never_includes_player_or_fishing_bobber() {
        let all_types = vec![
            "minecraft:cow".to_string(),
            "minecraft:player".to_string(),
            "minecraft:fishing_bobber".to_string(),
            "minecraft:wind_charge".to_string(),
        ];
        let summonable = summonable_entities(&all_types, &[] as &[&str]);
        assert!(!summonable.contains(&"minecraft:player".to_string()));
        assert!(!summonable.contains(&"minecraft:fishing_bobber".to_string()));
        assert!(summonable.contains(&"minecraft:cow".to_string()));
        assert!(summonable.contains(&"minecraft:wind_charge".to_string()));

        let fallback = summonable_entities(&[], ["player", "fishing_bobber", "zombie"]);
        assert!(!fallback.contains(&"minecraft:player".to_string()));
        assert!(!fallback.contains(&"minecraft:fishing_bobber".to_string()));
        assert!(fallback.contains(&"minecraft:zombie".to_string()));
    }

    /// `minecraft:wind_charge` and `minecraft:breeze_wind_charge` are in
    /// `reg.summonable`, and `/summon wind` or `/summon minecraft:wind_charg`
    /// suggest them via `Suggests::SummonableEntities` / `resource_matches`.
    #[test]
    fn summonable_entities_suggests_wind_charge_variants() {
        let all_types = vec![
            "minecraft:wind_charge".to_string(),
            "minecraft:breeze_wind_charge".to_string(),
            "minecraft:zombie".to_string(),
        ];
        let summonable = summonable_entities(&all_types, &[] as &[&str]);
        assert!(summonable.contains(&"minecraft:wind_charge".to_string()));
        assert!(summonable.contains(&"minecraft:breeze_wind_charge".to_string()));

        assert!(horizon_client::command::args::resource_matches(
            "wind",
            "minecraft:wind_charge"
        ));
        assert!(horizon_client::command::args::resource_matches(
            "wind",
            "minecraft:breeze_wind_charge"
        ));
        assert!(horizon_client::command::args::resource_matches(
            "minecraft:wind_charg",
            "minecraft:wind_charge"
        ));
        assert!(!horizon_client::command::args::resource_matches(
            "minecraft:wind_charg",
            "minecraft:breeze_wind_charge"
        ));

        let reg = Registries {
            permission: 2,
            summonable,
            ..Default::default()
        };
        let vanilla = horizon_client::command::vanilla::game_dispatcher();

        let parse = vanilla.parse("summon wind", &reg);
        let (_range, suggestions) = vanilla.client_suggestions(&parse, "summon wind".len(), &reg);
        let texts: Vec<String> = suggestions.into_iter().map(|s| s.text).collect();
        assert!(texts.contains(&"minecraft:wind_charge".to_string()));
        assert!(texts.contains(&"minecraft:breeze_wind_charge".to_string()));

        let parse = vanilla.parse("summon minecraft:wind_charg", &reg);
        let (_range, suggestions) =
            vanilla.client_suggestions(&parse, "summon minecraft:wind_charg".len(), &reg);
        let texts: Vec<String> = suggestions.into_iter().map(|s| s.text).collect();
        assert_eq!(texts, vec!["minecraft:wind_charge".to_string()]);
    }

    /// `Registries::fill_from_export` and `fill_from_exported` populate
    /// `self.summonable` and `self.entity_types` when present in export JSON,
    /// and sort/dedup properly.
    #[test]
    fn export_propagation_populates_and_dedups_summonable_and_entity_types() {
        let export_json = serde_json::json!({
            "summonable": [
                "minecraft:zombie",
                "minecraft:arrow",
                "minecraft:zombie",
                "minecraft:wind_charge"
            ],
            "entity_types": [
                "minecraft:zombie",
                "minecraft:player",
                "minecraft:arrow",
                "minecraft:zombie"
            ]
        });
        let mut reg = Registries::default();
        reg.fill_from_export(&export_json);
        assert_eq!(
            reg.summonable,
            vec![
                "minecraft:arrow".to_string(),
                "minecraft:wind_charge".to_string(),
                "minecraft:zombie".to_string(),
            ]
        );
        assert_eq!(
            reg.entity_types,
            vec![
                "minecraft:arrow".to_string(),
                "minecraft:player".to_string(),
                "minecraft:zombie".to_string(),
            ]
        );

        let mut dest = Registries::default();
        dest.fill_from_exported(&reg);
        assert_eq!(dest.summonable, reg.summonable);
        assert_eq!(dest.entity_types, reg.entity_types);

        let mut prefilled = Registries {
            summonable: vec!["minecraft:pig".to_string()],
            entity_types: vec!["minecraft:pig".to_string()],
            ..Default::default()
        };
        prefilled.fill_from_exported(&reg);
        assert_eq!(prefilled.summonable, vec!["minecraft:pig".to_string()]);
        assert_eq!(prefilled.entity_types, vec!["minecraft:pig".to_string()]);
    }

    /// The sleeper's chat: Leave Bed is a button target for the pad and the
    /// keyboard, right above the chat box, and the D-pad steps between the
    /// two.
    #[test]
    fn leave_bed_is_a_focus_target_above_the_chat_box() {
        use super::super::key_focus;
        use horizon_client::{
            font::Font,
            gamepad::{Button, focus_step_strict},
            widgets::Kind,
        };
        use std::collections::HashMap;
        // The missing-glyph metrics measure without game assets.
        let font = Font::load(
            Path::new("/nonexistent-horizon-chat-test-resources"),
            &HashMap::new(),
            &[],
            (1, 1),
            (0, 0),
            horizon_client::hud::Rect {
                u0: 0.0,
                v0: 0.0,
                u1: 1.0,
                v1: 1.0,
                w: 1,
                h: 1,
            },
        );
        let m = Measure(&font);
        let registries = Registries::default();
        let c = Commands {
            dispatcher: horizon_client::command::vanilla::game_dispatcher(),
            registries: &registries,
        };
        let (width, height) = (427.0, 240.0);
        let mut screen = ChatScreen::new(
            &m,
            &c,
            "",
            false,
            0,
            width as i32,
            height as i32,
            ChatAbilities::new(ChatVisibility::Full),
        );
        screen.draw(&m, (0, 0), 0, 0);
        Game::leave_bed_draws(&m, (0, 0), width, height);
        horizon_client::widgets::end_frame(u64::MAX);

        let targets = key_focus::drawn_targets();
        let (x, y, w, h) = Game::leave_bed_button(width, height);
        let bed = targets
            .iter()
            .copied()
            .find(|t| t.rect == [x as f32, y as f32, w as f32, h as f32])
            .expect("Leave Bed is a focus target");
        assert_eq!(bed.kind, Kind::Button);
        assert!(key_focus::keyboard_targets(targets.clone(), false).contains(&bed));
        let field = targets
            .iter()
            .copied()
            .find(|t| t.kind == Kind::Field)
            .expect("the chat box is a focus target");
        let rects: Vec<_> = targets.iter().map(|t| t.rect).collect();
        let step =
            |from: [f32; 4], button| focus_step_strict(from, button, &rects).map(|i| targets[i]);
        assert_eq!(step(field.rect, Button::DPadUp), Some(bed));
        assert_eq!(step(bed.rect, Button::DPadDown), Some(field));
    }
}

#[cfg(test)]
mod enchantment_snapshot_tests {
    use crate::game::{Audio, Game, Options, Progress, Settings, load_resources};

    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES"]
    fn synchronized_definitions_refresh_existing_enchantment_views() {
        let root = std::path::PathBuf::from(std::env::var_os("HORIZON_TEST_RESOURCES").unwrap());
        let settings = Settings::default();
        let loaded = load_resources(
            root.clone(),
            None,
            &root,
            &settings,
            std::time::Instant::now(),
            false,
            true,
            &Progress::new(),
            &mut |_, _| unreachable!(),
        )
        .unwrap();
        let mut options = Options::parse(std::iter::empty()).unwrap().unwrap();
        options.resources = root.clone();
        options.execution_role = crate::game::execution_role::ExecutionRole::IntegratedServer;
        let mut game = Game::new(
            &loaded.resources,
            loaded.pack,
            loaded.gui.unwrap(),
            options,
            settings,
            Audio::silent(&root),
            None,
        )
        .unwrap();
        game.build_registries();

        let dir =
            std::path::PathBuf::from(std::env::var_os("HORIZON_HOME").unwrap()).join("h024-model");
        let pack = dir.join("datapacks/model");
        let tags = pack.join("data/h024/tags/enchantment");
        std::fs::create_dir_all(&tags).unwrap();
        std::fs::write(
            pack.join("pack.mcmeta"),
            r#"{"pack":{"description":"fixture"}}"#,
        )
        .unwrap();
        std::fs::write(tags.join("empty.json"), r#"{"values":[]}"#).unwrap();
        std::fs::write(
            dir.join("datapacks.json"),
            r#"{"enabled":["file/model"],"disabled":[]}"#,
        )
        .unwrap();
        game.world_root = dir;
        game.world_tables = game.build_world_tables(false, &[]).unwrap().0;
        assert!(
            game.world_tables.is_some(),
            "the real active table container must be available"
        );
        let base = game.stations().enchantments.clone();
        assert!(base.get("minecraft:sharpness").is_some());
        // Same definition independently admitted by fresh Java. This is controlled
        // synchronized model input, NOT a world-pack or packet-delivery claim.
        let definition = serde_json::json!({"description":"H024 audit","supported_items":"minecraft:diamond_sword",
            "weight":1,"max_level":1,"min_cost":{"base":1,"per_level_above_first":0},
            "max_cost":{"base":1,"per_level_above_first":0},"anvil_cost":1,"slots":["mainhand"],"effects":{}});
        let synced = std::sync::Arc::new(base.with_entries([("h024:audit", &definition)]).unwrap());
        game.world_tables.as_mut().unwrap().stations.enchantments = synced.clone();
        game.world_tables.as_mut().unwrap().items.enchantments = synced;
        assert!(
            game.enchantments().get("h024:audit").is_some(),
            "actual authority adopts the definition first"
        );
        let tags = vec!["h024:retained_tag".to_owned()];
        game.ui
            .registries
            .by_registry
            .entry("minecraft:enchantment".into())
            .or_default()
            .tags = tags.clone();
        let item_ids = game.ui.registries.ids("minecraft:item").to_vec();
        let effects = game.ui.registries.effects.clone();
        game.sync_function_registries();
        for phase in [0, 1] {
            if phase == 1 {
                game.build_registries();
            }
            let reg = &game.ui.registries;
            assert!(
                reg.ids("minecraft:enchantment")
                    .contains(&"h024:audit".to_owned()),
                "active custom ID reaches actual Game sync/build snapshot"
            );
            assert!(
                reg.ids("minecraft:enchantment")
                    .contains(&"minecraft:sharpness".to_owned())
            );
            assert!(
                !reg.ids("minecraft:enchantment")
                    .contains(&"h024:missing".to_owned())
            );
            assert_eq!(
                reg.ids("minecraft:enchantment"),
                reg.enchantments.as_slice()
            );
            assert_eq!(reg.by_registry["minecraft:enchantment"].tags, tags);
            assert_eq!(reg.ids("minecraft:item"), item_ids);
            assert_eq!(reg.effects, effects);
        }
        game.world_tables.as_mut().unwrap().stations.enchantments = base.clone();
        game.world_tables.as_mut().unwrap().items.enchantments = base;
        assert!(game.enchantments().get("h024:audit").is_none());
        game.sync_function_registries();
        assert!(
            !game
                .ui
                .registries
                .ids("minecraft:enchantment")
                .contains(&"h024:audit".to_owned()),
            "refresh replaces rather than accumulating stale IDs"
        );
        assert_eq!(
            game.ui.registries.ids("minecraft:enchantment"),
            game.ui.registries.enchantments.as_slice()
        );
        assert_eq!(
            game.ui.registries.by_registry["minecraft:enchantment"].tags,
            tags
        );
    }
}

#[cfg(test)]
mod damage_type_registry_tests {
    use crate::game::{Audio, Game, Options, Progress, Settings, load_resources};

    /// A world pack's damage type is a `/damage` type once the world opens,
    /// beside vanilla's, and the registry keeps vanilla's tags.
    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES"]
    fn a_world_packs_damage_type_parses_in_damage() {
        let root = std::path::PathBuf::from(std::env::var_os("HORIZON_TEST_RESOURCES").unwrap());
        let settings = Settings::default();
        let loaded = load_resources(
            root.clone(),
            None,
            &root,
            &settings,
            std::time::Instant::now(),
            false,
            true,
            &Progress::new(),
            &mut |_, _| unreachable!(),
        )
        .unwrap();
        let mut options = Options::parse(std::iter::empty()).unwrap().unwrap();
        options.resources = root.clone();
        options.execution_role = crate::game::execution_role::ExecutionRole::IntegratedServer;
        let mut game = Game::new(
            &loaded.resources,
            loaded.pack,
            loaded.gui.unwrap(),
            options,
            settings,
            Audio::silent(&root),
            None,
        )
        .unwrap();

        let dir = std::path::PathBuf::from(std::env::var_os("HORIZON_HOME").unwrap())
            .join("damage-type-ids");
        let pack = dir.join("datapacks/model");
        let types = pack.join("data/example/damage_type");
        std::fs::create_dir_all(&types).unwrap();
        std::fs::write(pack.join("pack.mcmeta"), r#"{"pack":{"description":""}}"#).unwrap();
        std::fs::write(
            types.join("test.json"),
            r#"{"message_id":"example.test","scaling":"never","exhaustion":0.0}"#,
        )
        .unwrap();
        std::fs::write(
            dir.join("datapacks.json"),
            r#"{"enabled":["file/model"],"disabled":[]}"#,
        )
        .unwrap();
        game.world_root = dir;
        (game.world_tables, game.health_resources) = game.build_world_tables(false, &[]).unwrap();
        game.level.allow_commands = Some(true);
        game.build_registries();

        let reg = &game.ui.registries;
        assert!(
            reg.damage_types.contains(&"example:test".to_owned()),
            "the damage catalog holds the pack's type"
        );
        let parse = |input: &str| {
            horizon_client::command::vanilla::dispatcher()
                .parse(input, reg)
                .executable()
                .map(|_| ())
                .map_err(|e| format!("{e:?}"))
        };
        assert_eq!(parse("damage @s 1 example:test"), Ok(()));
        assert_eq!(parse("damage @s 1 minecraft:magic"), Ok(()));
        assert!(parse("damage @s 1 example:missing").is_err());
        assert!(
            reg.tags("minecraft:damage_type")
                .contains(&"minecraft:is_fire".to_owned()),
            "vanilla's damage type tags stay"
        );
    }
}
