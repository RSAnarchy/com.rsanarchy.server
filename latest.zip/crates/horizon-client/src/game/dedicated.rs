//! The dedicated server (net.minecraft.server.Main and DedicatedServer):
//! `horizon-client --dedicated [--nogui] [--port N] [--world NAME]
//! [--universe DIR] [--initSettings]`. It reads server.properties and
//! eula.txt from the working directory, opens `<universe>/<level-name>` and
//! runs the same game as single player, without a local player: the world,
//! its simulation and the play-state hub that LAN hosting uses, configured
//! from server.properties, with the operator, whitelist and ban lists and a
//! console on standard input.
use super::{Game, Options, lan::LanSettings, world_loading::WorldRequest};
use horizon_client::{
    Result,
    lan::{LoginGate, NetConfig, NetLog, OnlineMode, hub::HubConfig},
    server::{
        eula, profiles,
        properties::{GAME_MODES, ServerProperties, SystemEntropy},
        user_cache::UserCache,
        user_lists::{
            BanEntry, BanList, Change, IpBanList, NameAndId, OpEntry, OpList, WhiteEntry,
            WhiteList, format_date,
        },
    },
    text::Text,
};
use horizon_perf_format::v1::{StopReason, Trigger};
use horizon_protocol::text::translatable;
use horizon_world::nbt::{JavaString, Tag};
use std::{
    io::Write,
    path::PathBuf,
    sync::{
        Arc, Mutex, OnceLock,
        atomic::{AtomicBool, AtomicU64, Ordering},
        mpsc,
    },
    time::{Duration, Instant},
};

pub(super) mod events;
mod management;
mod predicate_graph;
pub(super) mod report;
mod status;
mod transfer;

/// What the tick loop tells `ServerWatchdog`: when the tick in progress was
/// due (`getNextTickTime`), how long a tick is, and whether the server runs.
struct Watchdog {
    /// The thread running the ticks, whose stack the report carries.
    server: horizon_threads::stack_dump::Watched,
    base: Instant,
    next_nanos: AtomicU64,
    tick_nanos: AtomicU64,
    running: AtomicBool,
}

impl Watchdog {
    /// `DedicatedServer.initServer`: a thread that stops a server whose tick
    /// runs `max_tick_time` ms past its due time; none when that is 0 or less.
    /// Started from the thread that runs the ticks.
    fn start(max_tick_time: i64) -> Option<Arc<Self>> {
        let max = Duration::from_millis(u64::try_from(max_tick_time).ok().filter(|m| *m > 0)?);
        let watchdog = Arc::new(Self {
            server: horizon_threads::stack_dump::Watched::current(),
            base: Instant::now(),
            next_nanos: AtomicU64::new(0),
            tick_nanos: AtomicU64::new(50_000_000),
            running: AtomicBool::new(true),
        });
        let shared = watchdog.clone();
        std::thread::Builder::new()
            .name("Server Watchdog".into())
            .spawn(move || shared.run(max))
            .ok()?;
        Some(watchdog)
    }
    /// The tick loop is about to run the tick due at `next`.
    fn tick_due(&self, next: Instant, tick: Duration) {
        let nanos = next.saturating_duration_since(self.base).as_nanos();
        self.next_nanos
            .store(u64::try_from(nanos).unwrap_or(u64::MAX), Ordering::Relaxed);
        let tick = u64::try_from(tick.as_nanos()).unwrap_or(u64::MAX);
        self.tick_nanos.store(tick, Ordering::Relaxed);
    }
    /// `ServerWatchdog.run`.
    fn run(&self, max: Duration) {
        let max = u64::try_from(max.as_nanos()).unwrap_or(u64::MAX);
        while self.running.load(Ordering::Relaxed) {
            let next = self.next_nanos.load(Ordering::Relaxed);
            let now = u64::try_from(self.base.elapsed().as_nanos()).unwrap_or(u64::MAX);
            let behind = now.saturating_sub(next);
            if behind > max {
                // ServerWatchdog: the server thread's stack first, while it is still stuck.
                let stack = self.server.stack(Duration::from_secs(5));
                let took = format!("{:.2}", behind as f32 / 1e9);
                let should = format!(
                    "{:.2}",
                    self.tick_nanos.load(Ordering::Relaxed) as f32 / 1e9
                );
                log_from(
                    "Server Watchdog",
                    "ERROR",
                    &format!("A single server tick took {took} seconds (should be max {should})"),
                );
                log_from(
                    "Server Watchdog",
                    "ERROR",
                    "Considering it to be crashed, server will forcibly shutdown.",
                );
                let message = format!(
                    "ServerWatchdog detected that a single server tick took {took} seconds (should be max {should})"
                );
                match horizon_client::crash::report_watchdog(
                    std::path::Path::new("."),
                    "server",
                    message,
                    stack,
                ) {
                    Some(path) => log_from(
                        "Server Watchdog",
                        "ERROR",
                        &format!(
                            "This crash report has been saved to: {}",
                            path.canonicalize().unwrap_or(path).display()
                        ),
                    ),
                    None => log_from(
                        "Server Watchdog",
                        "ERROR",
                        "We were unable to save this crash report to disk.",
                    ),
                }
                std::process::exit(1);
            }
            // Thread.sleep(nextTickTime + maxTickTime - now).
            let wait = (next + max).saturating_sub(now).max(1_000_000);
            std::thread::sleep(Duration::from_nanos(wait));
        }
    }
}

/// Double.toString for the magnitudes positions have (no exponent form
/// between 1e-3 and 1e7).
pub(super) fn java_double(v: f64) -> String {
    if v == 0.0 || (1e-3..1e7).contains(&v.abs()) {
        format!("{v:?}")
    } else {
        let s = format!("{v:E}");
        let (m, e) = s.split_once('E').unwrap_or((&s, "0"));
        let m = if m.contains('.') {
            m.to_owned()
        } else {
            format!("{m}.0")
        };
        format!("{m}E{e}")
    }
}

/// What the startup read before the game's resources were loaded.
struct Setup {
    props: ServerProperties,
    universe: PathBuf,
    level_name: String,
    port: Option<u16>,
    started: Instant,
}
static SETUP: OnceLock<Mutex<Option<Setup>>> = OnceLock::new();
/// usercache.json (Services.nameToIdCache): used by the server thread only.
static USER_CACHE: Mutex<Option<UserCache>> = Mutex::new(None);

/// PlayerList.placeNewPlayer: a player who joined is cached (and the file saved).
pub(super) fn player_joined(id: u128, name: &str) {
    if let Some(cache) = USER_CACHE.lock().unwrap().as_mut() {
        cache.add(NameAndId {
            id,
            name: name.to_owned(),
        });
    }
}

/// A player in the user cache by name (`UserCache::find_by_name`), on a dedicated server.
pub(super) fn cached_user_by_name(name: &str) -> Option<NameAndId> {
    USER_CACHE.lock().unwrap().as_ref()?.find_by_name(name)
}

/// A player in the user cache by id, on a dedicated server.
pub(super) fn cached_user_by_id(id: u128) -> Option<NameAndId> {
    USER_CACHE.lock().unwrap().as_mut()?.get_by_id(id)
}

/// How many players the server has ever seen (the user cache's size), for
/// `/worldstats`. Zero without a cache (no dedicated server).

/// `server.toml`'s `[anticheat]`, beside server.properties when horizon-server runs the game; the
/// default (on) without the file or the section, off (with an error logged) when the section is wrong.
fn load_anticheat() -> horizon_anticheat::Config {
    let Ok(text) = std::fs::read_to_string("server.toml") else {
        return Default::default();
    };
    match horizon_anticheat::Config::from_server_toml(&text) {
        Ok(config) => {
            if config.enabled {
                log(
                    "INFO",
                    "Anticheat on (server.toml [anticheat]; enabled = false turns it off)",
                );
            }
            config
        }
        Err(e) => {
            log(
                "ERROR",
                &format!("server.toml: {e}; the anticheat stays off"),
            );
            horizon_anticheat::Config {
                enabled: false,
                ..Default::default()
            }
        }
    }
}

/// `server.toml`'s `[chat_filter]` (docs/chat-filter.md), through the filter the executable installed
/// (`horizon_server_files::chat_guard`): none without one.
fn load_chat_filter() -> Option<Box<dyn horizon_server_files::chat_guard::ChatGuard>> {
    let text = std::fs::read_to_string("server.toml").unwrap_or_default();
    let loaded = horizon_server_files::chat_guard::load(&text, std::path::Path::new("."));
    for (level, line) in &loaded.log {
        log(level, line);
    }
    loaded.guard
}

/// `server.toml`'s `[combat]` (docs/pvp.md): `legacy = true` resolves melee hits by 1.8.9's rules. Off without
/// the file or the section, and (with an error logged) when the section is wrong.
fn load_combat() -> bool {
    #[derive(serde::Deserialize)]
    #[serde(deny_unknown_fields)]
    struct Combat {
        #[serde(default)]
        legacy: bool,
    }
    let Ok(text) = std::fs::read_to_string("server.toml") else {
        return false;
    };
    let section = toml::from_str::<toml::Table>(&text)
        .map_err(|e| e.to_string())
        .and_then(|mut t| match t.remove("combat") {
            Some(section) => section
                .try_into::<Combat>()
                .map(|c| c.legacy)
                .map_err(|e| format!("[combat]: {e}")),
            None => Ok(false),
        });
    match section {
        Ok(legacy) => {
            if legacy {
                log(
                    "INFO",
                    "1.8 combat rules on (server.toml [combat]; legacy = false turns them off)",
                );
            }
            legacy
        }
        Err(e) => {
            log(
                "ERROR",
                &format!("server.toml: {e}; fights keep 26.3's rules"),
            );
            false
        }
    }
}

/// `server.toml`'s `[entities]` (docs/server.md): `villager_lobotomize` and its check interval. Off without
/// the file or the section, and (with an error logged) when the section is wrong.
fn load_entities() {
    let text = std::fs::read_to_string("server.toml").unwrap_or_default();
    match parse_entities(&text) {
        Ok((on, interval)) => {
            if on {
                log(
                    "INFO",
                    &format!(
                        "villagers that cannot move skip their brain, rechecked every {interval} ticks (server.toml [entities])"
                    ),
                );
            }
            horizon_client::mobs::villager::lobotomy::configure(on, interval);
        }
        Err(e) => log(
            "ERROR",
            &format!("server.toml: {e}; villagers keep their brains"),
        ),
    }
}

/// The `[entities]` section of a `server.toml`: (`villager_lobotomize`, its check interval in ticks). The
/// section's other keys (`dab`...) belong to other settings, so they are skipped here; `horizon-server` refuses
/// typos when it reads the file.
fn parse_entities(text: &str) -> std::result::Result<(bool, u32), String> {
    #[derive(serde::Deserialize)]
    #[serde(default)]
    struct Entities {
        villager_lobotomize: bool,
        villager_lobotomize_check_interval: u32,
    }
    impl Default for Entities {
        fn default() -> Self {
            Self {
                villager_lobotomize: false,
                villager_lobotomize_check_interval:
                    horizon_client::mobs::villager::lobotomy::DEFAULT_INTERVAL,
            }
        }
    }
    let mut table = toml::from_str::<toml::Table>(text).map_err(|e| e.to_string())?;
    let Some(section) = table.remove("entities") else {
        return Ok((
            false,
            Entities::default().villager_lobotomize_check_interval,
        ));
    };
    let e: Entities = section.try_into().map_err(|e| format!("[entities]: {e}"))?;
    if e.villager_lobotomize_check_interval == 0 {
        return Err("[entities]: villager_lobotomize_check_interval must be at least 1".into());
    }
    Ok((e.villager_lobotomize, e.villager_lobotomize_check_interval))
}

/// The secret for Velocity's player information forwarding, from `forwarding.secret` beside server.properties.
/// No file means no forwarding. A file that is empty or can't be read stops the start, because an empty secret
/// would let anyone sign a login, and a typo must not leave a server open that was meant to be behind a proxy.
fn forwarding_secret(online: bool) -> Result<Option<Vec<u8>>> {
    const FILE: &str = "forwarding.secret";
    if !std::path::Path::new(FILE).exists() {
        return Ok(None);
    }
    if online {
        log(
            "WARN",
            "forwarding.secret is ignored: the proxy authenticates the players, so set \"online-mode\" to \"false\".",
        );
        return Ok(None);
    }
    let text = std::fs::read(FILE).map_err(|e| format!("{FILE}: {e}"))?;
    let secret = text.trim_ascii().to_vec();
    if secret.is_empty() {
        return Err(format!(
            "{FILE} is empty: put the proxy's forwarding secret in it, or remove the file"
        )
        .into());
    }
    log(
        "INFO",
        "Velocity player information forwarding is on (forwarding.secret)",
    );
    Ok(Some(secret))
}

/// `MinecraftServer.runServer`'s overload warning for a server `behind` its
/// schedule, in milliseconds and in ticks of `tick`.
fn overload_warning(behind: Duration, tick: Duration) -> String {
    format!(
        "Can't keep up! Is the server overloaded? Running {}ms or {} ticks behind",
        behind.as_millis(),
        behind.as_nanos() / tick.as_nanos().max(1)
    )
}

/// `ServerGamePacketListenerImpl.tick`'s idle kick: a player whose last action is more than
/// `minutes` (`player-idle-timeout`, none when 0 or less) behind, counted here in ticks, is kicked,
/// unless the End poem is showing (`ServerPlayer.wonGame`): its client sends no action until it
/// asks to respawn.
fn idles_out(idle_ticks: u64, minutes: i32, won_game: bool) -> bool {
    let Ok(minutes @ 1..) = u64::try_from(minutes) else {
        return false;
    };
    !won_game && idle_ticks > minutes * 1200
}

/// Log4j's console pattern: `[HH:mm:ss] [thread/LEVEL]: message`.
pub(super) fn log(level: &str, message: &str) {
    log_from("Server thread", level, message);
}

/// A line from another of vanilla's threads (the login's User Authenticator).
fn log_from(thread: &str, level: &str, message: &str) {
    let file_level = match level {
        "WARN" => ::log::Level::Warn,
        "ERROR" => ::log::Level::Error,
        _ => ::log::Level::Info,
    };
    horizon_client::logging::write_as(thread, file_level, message);
    CAPTURE.with_borrow_mut(|lines| {
        if let Some(lines) = lines {
            lines.push(message.to_owned());
        }
    });
    // Log4j's %d{HH:mm:ss}: the local time, as in logs/latest.log.
    // The launcher can close its stdout pipe while the server keeps running.
    let _ = writeln!(
        std::io::stdout().lock(),
        "[{}] [{thread}/{level}]: {message}",
        chrono::Local::now().format("%H:%M:%S")
    );
}

thread_local! {
    /// The lines logged while a control request runs a console command.
    static CAPTURE: std::cell::RefCell<Option<Vec<String>>> = const { std::cell::RefCell::new(None) };
}

/// Runs `f` and returns the lines it logged.
fn capture_log(f: impl FnOnce()) -> Vec<String> {
    CAPTURE.set(Some(Vec::new()));
    f();
    CAPTURE.take().unwrap_or_default()
}

/// Main.main up to the server start: arguments, server.properties (stored
/// back at once), eula.txt. False when the process should stop here.
pub(super) fn preflight(options: &mut Options) -> Result<bool> {
    let args = options.dedicated.clone().unwrap_or_default();
    let mut universe = PathBuf::from(".");
    let mut world = None;
    let mut port = None;
    let mut init_settings = false;
    let mut it = args.iter();
    while let Some(arg) = it.next() {
        let name = arg.trim_start_matches('-');
        match name {
            "nogui"
            | "demo"
            | "bonusChest"
            | "forceUpgrade"
            | "eraseCache"
            | "recreateRegionFiles"
            | "safeMode"
            | "jfrProfile" => {}
            "initSettings" => init_settings = true,
            "help" => {
                eprintln!(
                    "Option                Description\n------                -----------\n--help\n--initSettings        Initializes 'server.properties' and 'eula.txt', then quits\n--nogui\n--port <Integer>      (default: -1)\n--universe <String>   (default: .)\n--world <String>"
                );
                return Ok(false);
            }
            "universe" => universe = PathBuf::from(it.next().ok_or("--universe needs a value")?),
            "world" => world = Some(it.next().ok_or("--world needs a value")?.clone()),
            "port" => {
                let v: i32 = it.next().ok_or("--port needs a value")?.parse()?;
                port = u16::try_from(v).ok();
            }
            "serverId" | "pidFile" => {
                let value = it.next().ok_or("missing value")?;
                if name == "pidFile" {
                    std::fs::write(value, std::process::id().to_string())?;
                }
            }
            _ => return Err(format!("{arg} is not a recognized option").into()),
        }
    }
    let started = Instant::now();
    let settings = PathBuf::from("server.properties");
    let props = ServerProperties::from_file(&settings, &mut SystemEntropy::default())?;
    for w in &props.warnings {
        log("WARN", w);
    }
    // A dedicated server's tree: /op, /ban, /whitelist... (single player's
    // server thread is an integrated one and never gets here).
    horizon_client::command::vanilla::set_dedicated_commands(true);
    // Horizon's own commands are the owner's choice, off as on vanilla.
    if props
        .raw
        .get(horizon_client::command::vanilla::PREGEN_PROPERTY)
        .is_some_and(|v| v.trim().eq_ignore_ascii_case("true"))
    {
        horizon_client::command::vanilla::set_horizon_commands(true);
    }
    props.store(&settings)?;
    // `RegionFileVersion.configure`: the compression every region file this
    // server writes uses, from `region-file-compression`. An unknown name is
    // logged with the ones there are, and the default (deflate) stays.
    if !horizon_world::compression::Compression::configure(&props.region_file_compression) {
        log(
            "ERROR",
            &format!(
                "Invalid `region-file-compression` value `{}` in server.properties. Please use one of: {}",
                props.region_file_compression,
                horizon_world::compression::REGION_FILE_NAMES.join(",")
            ),
        );
    }
    let eula_file = PathBuf::from("eula.txt");
    let agreed = match eula::agreed(&eula_file) {
        Ok(a) => a,
        Err(w) => {
            log("WARN", &w);
            false
        }
    };
    if init_settings {
        let abs = |p: &PathBuf| std::env::current_dir().map_or(p.clone(), |d| d.join(p));
        log(
            "INFO",
            &format!(
                "Initialized '{}' and '{}'",
                abs(&settings).display(),
                abs(&eula_file).display()
            ),
        );
        return Ok(false);
    }
    if !agreed {
        log(
            "INFO",
            "You need to agree to the EULA in order to run the server. Go to eula.txt for more info.",
        );
        return Ok(false);
    }
    let level_name = world.unwrap_or_else(|| props.level_name.clone());
    SETUP
        .get_or_init(|| Mutex::new(None))
        .lock()
        .unwrap()
        .replace(Setup {
            props,
            universe,
            level_name,
            port,
            started,
        });
    Ok(true)
}

/// The event a change of a list is (`operators_added`, `bans_removed`...), and the entry it is about.
fn listed<E>(list: &str, change: Change<E>) -> (String, E) {
    match change {
        Change::Added(e) => (format!("{list}_added"), e),
        Change::Removed(e) => (format!("{list}_removed"), e),
    }
}

/// What a ban says besides who it is for: the reason and the source, and when it ends (milliseconds, or none).
fn ban_fields<T>(ban: &BanEntry<T>) -> serde_json::Value {
    serde_json::json!({ "reason": ban.reason, "source": ban.source, "expires": ban.expires })
}

/// The operator, whitelist and ban lists (DedicatedPlayerList), shared with
/// the connection threads that check logins, and the server's own switches
/// that an operator's command changes.
pub(super) struct Lists {
    pub ops: OpList,
    pub white: WhiteList,
    pub bans: BanList,
    pub ip_bans: IpBanList,
    pub use_whitelist: bool,
    pub enforce_whitelist: bool,
    /// `op-permission-level`: what `/op` grants (operatorUserPermissions).
    pub op_level: i32,
    /// `MinecraftServer.playerIdleTimeout`: the minutes of idleness after
    /// which a player is kicked, `player-idle-timeout` at the start and
    /// `/setidletimeout` after it.
    pub player_idle_timeout: i32,
    /// `/stop` (MinecraftServer.halt): the server loop ends after this tick.
    pub stop: bool,
    /// `MinecraftServer.isAutoSave`: all of Horizon's server levels share this save flag.
    pub autosave: bool,
    /// UUID prefixes (lower case, with dashes) that pass the whitelist: `whitelist-bypass.txt`.
    pub whitelist_bypass: Vec<String>,
}

/// The lines of `whitelist-bypass.txt`: one UUID prefix each, e.g. `00000000-0000-0000-0009-` for Floodgate's
/// Bedrock players. `#` starts a comment. A prefix has to be a dashed UUID start of at least 8 characters, so
/// a typo can't open the whitelist to everybody.
fn parse_whitelist_bypass(text: &str) -> std::result::Result<Vec<String>, String> {
    let mut out = Vec::new();
    for (n, line) in text.lines().enumerate() {
        let line = line
            .split('#')
            .next()
            .unwrap_or("")
            .trim()
            .to_ascii_lowercase();
        if line.is_empty() {
            continue;
        }
        if line.len() < 8
            || line.len() > 36
            || !line.chars().all(|c| c.is_ascii_hexdigit() || c == '-')
        {
            return Err(format!(
                "whitelist-bypass.txt line {}: {line:?} is not a UUID prefix",
                n + 1
            ));
        }
        out.push(line);
    }
    Ok(out)
}
impl Lists {
    /// The console's `/ban` of one player (`BanPlayerCommands.banPlayers`): whether they are banned now.
    /// One banned already (`isBanned`) is left as they are, their first reason kept.
    fn ban(&mut self, user: &NameAndId, reason: Option<String>) -> bool {
        !self.bans.contains(user)
            && self.bans.add(BanEntry::new(
                user.clone(),
                Some("Server".into()),
                None,
                reason,
            ))
    }

    /// The console's `/ban-ip` (`BanIpCommands.banIp`): whether the address is banned now. One banned
    /// already (`isBanned`) is left as it is.
    fn ban_ip(&mut self, ip: &str, reason: Option<String>) -> bool {
        let ip = ip.to_owned();
        !self.ip_bans.contains(&ip)
            && self
                .ip_bans
                .add(BanEntry::new(ip, Some("Server".into()), None, reason))
    }

    fn load() -> Self {
        let mut l = Self {
            ops: OpList::new("ops.json"),
            white: WhiteList::new("whitelist.json"),
            bans: BanList::new("banned-players.json"),
            ip_bans: IpBanList::new("banned-ips.json"),
            use_whitelist: false,
            enforce_whitelist: false,
            op_level: 4,
            player_idle_timeout: 0,
            stop: false,
            autosave: true,
            whitelist_bypass: Vec::new(),
        };
        // Horizon only: players from a proxy's Bedrock bridge (Floodgate) are never on whitelist.json.
        if let Ok(text) = std::fs::read_to_string("whitelist-bypass.txt") {
            match parse_whitelist_bypass(&text) {
                Ok(prefixes) => {
                    log(
                        "INFO",
                        &format!(
                            "whitelist-bypass.txt: {} UUID prefix(es) skip the whitelist",
                            prefixes.len()
                        ),
                    );
                    l.whitelist_bypass = prefixes;
                }
                Err(e) => log("ERROR", &format!("{e}; the file is ignored")),
            }
        }
        // Each list tells the event stream what changes in it, as vanilla's tell their `NotificationService`.
        l.ops.watch(|change| {
            let (kind, e) = listed("operators", change);
            events::record(
                &kind,
                &e.user.name,
                e.user.id,
                serde_json::json!({ "level": e.level, "bypassesPlayerLimit": e.bypasses_player_limit }),
            );
        });
        l.white.watch(|change| {
            let (kind, e) = listed("allowlist", change);
            events::record(&kind, &e.user.name, e.user.id, serde_json::json!({}));
        });
        l.bans.watch(|change| {
            let (kind, e) = listed("bans", change);
            events::record(&kind, &e.user.name, e.user.id, ban_fields(&e));
        });
        l.ip_bans.watch(|change| {
            let (kind, e) = listed("ip_bans", change);
            let mut fields = ban_fields(&e);
            fields["ip"] = e.user.clone().into();
            events::record_server(&kind, fields);
        });
        // DedicatedPlayerList's constructor order and its LOGGER.warn lines.
        let warn = |what: &str, r: std::result::Result<(), String>| {
            if let Err(e) = r {
                log("WARN", &format!("Failed to {what}: {e}"));
            }
        };
        let saved = |r: std::io::Result<()>| r.map_err(|e| e.to_string());
        warn("load user banlist", l.bans.load());
        warn("save user banlist", saved(l.bans.save()));
        warn("load ip banlist", l.ip_bans.load());
        warn("save ip banlist", saved(l.ip_bans.save()));
        warn("load operators list", l.ops.load());
        warn("load white-list", l.white.load());
        warn("save operators list", saved(l.ops.save()));
        if !l.white.file.exists() {
            warn("save white-list", saved(l.white.save()));
        }
        l
    }
    /// PlayerList.isWhiteListed.
    fn whitelisted(&self, user: &NameAndId) -> bool {
        !self.use_whitelist
            || self.ops.contains(user)
            || self.white.contains(user)
            || self.bypasses_whitelist(user.id)
    }
    fn bypasses_whitelist(&self, id: u128) -> bool {
        let id = horizon_protocol::crypto::uuid_string(id);
        self.whitelist_bypass
            .iter()
            .any(|p| id.starts_with(p.as_str()))
    }
    /// PlayerList.canPlayerLogin before the player count.
    fn can_login(&mut self, address: std::net::SocketAddr, user: &NameAndId) -> Option<Tag> {
        if self.bans.contains(user)
            && let Some(ban) = self.bans.get(user).cloned()
        {
            return Some(ban_message(&ban));
        }
        if !self.whitelisted(user) {
            return Some(translatable("multiplayer.disconnect.not_whitelisted", &[]));
        }
        let ip = address.ip().to_string();
        if self.ip_bans.contains(&ip)
            && let Some(ban) = self.ip_bans.get(&ip).cloned()
        {
            let mut reason = translatable_tag(
                "multiplayer.disconnect.banned_ip.reason",
                vec![ban_reason(&ban.reason)],
            );
            if let Some(expires) = ban.expires {
                append(
                    &mut reason,
                    translatable_tag(
                        "multiplayer.disconnect.banned_ip.expiration",
                        vec![Tag::String(JavaString::from(ban_date(expires).as_str()))],
                    ),
                );
            }
            return Some(reason);
        }
        None
    }
}

/// DedicatedServerProperties.LEGACY_PRESET_NAMES: the old `level-type`
/// names, before the presets had their own ids.
const LEGACY_PRESET_NAMES: [(&str, horizon_client::save::WorldPreset); 2] = [
    ("default", horizon_client::save::WorldPreset::Normal),
    (
        "largebiomes",
        horizon_client::save::WorldPreset::LargeBiomes,
    ),
];

/// server.properties' line for `server.toml`'s `max_view_distance` (horizon-server writes it).
const FAR_PROPERTY: &str = "horizon-max-view-distance";
/// A tick slower than this, in milliseconds, enters the slow ring (five ticks' worth, a stall players feel) unless `HORIZON_SPIKES` names another.
pub(super) const SLOW_TICK_MS: f32 = 250.0;
/// `MinecraftServer.OVERLOADED_WARNING_INTERVAL_NANOS` plus 100 ticks: the
/// "Can't keep up!" warning comes at most this often.
const OVERLOAD_WARNING_INTERVAL: Duration = Duration::from_secs(15);
/// server.properties' line for `server.toml`'s `admin_feedback_to_ops` (horizon-server writes it).
const ADMIN_FEEDBACK_PROPERTY: &str = "horizon-admin-feedback-to-ops";

/// Identifier.tryParse: `namespace:path`, or a path in `minecraft`.
fn parse_identifier(text: &str) -> Option<String> {
    let (namespace, path) = text.split_once(':').unwrap_or(("minecraft", text));
    let valid = |s: &str, extra: &[char]| {
        s.chars()
            .all(|c| matches!(c, 'a'..='z' | '0'..='9' | '_' | '.' | '-') || extra.contains(&c))
    };
    (valid(namespace, &[]) && valid(path, &['/'])).then(|| format!("{namespace}:{path}"))
}

/// The world's packs failed to load: the start ends before Ready, as vanilla's `Main` does.
#[derive(Debug)]
struct DatapacksRefused;
impl std::fmt::Display for DatapacksRefused {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Failed to load datapacks, can't proceed with server load")
    }
}
impl std::error::Error for DatapacksRefused {}

impl Game<'_> {
    /// DedicatedServerProperties.createDimensions for a world that doesn't
    /// exist yet: `level-type`'s preset, a flat world's `generator-settings`
    /// and `generate-structures`, written before the world opens so that
    /// streaming reads them.
    fn write_world_gen(&self, dir: &std::path::Path, props: &ServerProperties) -> Result<()> {
        let level_type = &props.level_type;
        let preset = parse_identifier(level_type)
            .as_deref()
            .and_then(horizon_client::save::WorldPreset::of_id)
            .or_else(|| {
                LEGACY_PRESET_NAMES
                    .iter()
                    .find(|(name, _)| *name == level_type)
                    .map(|(_, preset)| *preset)
            })
            .unwrap_or_else(|| {
                log_from(
                    "Worker-Main-1",
                    "WARN",
                    &format!(
                        "Failed to parse level-type {level_type}, defaulting to minecraft:normal"
                    ),
                );
                horizon_client::save::WorldPreset::Normal
            });
        let flat = preset == horizon_client::save::WorldPreset::Flat;
        let settings = if flat {
            let biomes = world_biomes!(self);
            let (settings, errors) = horizon_client::flatgen::settings_from_json(
                &props.generator_settings,
                |b| self.pack.assets.registry.default_state(b).is_some(),
                |b| biomes.get(biomes.id(b)).name == b,
            );
            for e in errors {
                log_from("Worker-Main-1", "ERROR", &e);
            }
            settings
        } else {
            None
        };
        let options = horizon_client::save::WorldGen {
            preset,
            structures: props.generate_structures,
            bonus_chest: false,
        };
        horizon_client::save::write_world_gen_settings_with(
            dir, props.seed, options, settings, None,
        )
    }
}

/// PlayerList.BAN_DATE_FORMAT ("yyyy-MM-dd 'at' HH:mm:ss z"), in UTC.
fn ban_date(millis: i64) -> String {
    let s = format_date(millis);
    format!("{} at {} UTC", &s[..10], &s[11..19])
}
/// What a banned player is told: `multiplayer.disconnect.banned.reason` and, for a ban that ends,
/// `multiplayer.disconnect.banned.expiration` (PlayerList.canPlayerLogin).
pub(super) fn ban_message(ban: &BanEntry<NameAndId>) -> Tag {
    let mut reason = translatable_tag(
        "multiplayer.disconnect.banned.reason",
        vec![ban_reason(&ban.reason)],
    );
    if let Some(expires) = ban.expires {
        append(
            &mut reason,
            translatable_tag(
                "multiplayer.disconnect.banned.expiration",
                vec![Tag::String(JavaString::from(ban_date(expires).as_str()))],
            ),
        );
    }
    reason
}
/// BanListEntry.getReasonMessage.
fn ban_reason(reason: &Option<String>) -> Tag {
    match reason {
        Some(r) => Tag::String(JavaString::from(r.as_str())),
        None => translatable("multiplayer.disconnect.banned.reason.default", &[]),
    }
}
fn translatable_tag(key: &str, args: Vec<Tag>) -> Tag {
    Tag::compound([
        ("translate", Tag::String(JavaString::from(key))),
        ("with", Tag::List(args)),
    ])
}
/// MutableComponent.append.
fn append(to: &mut Tag, sibling: Tag) {
    if let Tag::Compound(map) = to {
        let extra = map
            .entry(JavaString::from("extra"))
            .or_insert_with(|| Tag::List(Vec::new()));
        if let Tag::List(items) = extra {
            items.push(sibling);
        }
    }
}

/// What the server loop keeps between ticks.
struct ServerState {
    lists: Arc<Mutex<Lists>>,
    console: mpsc::Receiver<String>,
    empty_ticks: i32,
    /// The mutable `DedicatedServer.pauseWhenEmptySeconds` setting.
    pause_when_empty_seconds: i32,
    /// When the last passes of the loop ended, for the tick rate horizon-server shows.
    ticks: std::collections::VecDeque<Instant>,
    paused: bool,
    /// `broadcast-console-to-ops`.
    broadcast_console: bool,
    /// `broadcast-rcon-to-ops` (`MinecraftServer.shouldRconBroadcast`).
    broadcast_rcon: bool,
    /// `op-permission-level`: what `/op` grants (operatorUserPermissions).
    op_level: i32,
    /// `horizon-report`: the ticks being recorded.
    report: Option<report::Recording>,
    /// When the running capture takes its next memory snapshot, and how many it has taken.
    memory_due: Option<(f64, u32)>,
    /// The always-on health history and slow ring, and the `.hzperf` a report writes from them.
    perf: horizon_client::server_perf::ServerPerf,
    /// The perf clock's zero: the tick loop's start.
    perf_epoch: Instant,
    /// The Horizon switches a capture records.
    horizon: horizon_perf_format::v1::HorizonOptions,
    /// View and simulation distance, and the player limit, for the report.
    view: (u32, u32),
    max_players: usize,
    /// `network-compression-threshold`, for the capture's settings.
    compression: i32,
    /// The mutable `gamemode` server property (`DedicatedServer.gameMode`).
    game_mode: i32,
    /// The mutable `force-gamemode` server property (`DedicatedServer.forceGameMode`).
    force_game_mode: bool,
}

/// `SaveAllCommand.saveAll`'s reply to its source: `commands.save.success` when
/// the save went through, `commands.save.failed` (the `ERROR_FAILED` it throws)
/// when it did not.
fn save_all_reply(saved: bool) -> Text {
    Text::translate(
        if saved {
            "commands.save.success"
        } else {
            "commands.save.failed"
        },
        &[],
    )
}

/// `BanIpCommands.banIp`'s `commands.banip.info`: the count of affected players and
/// `EntitySelector.joinNames` of them (a gray ", " between names). None when no one is affected,
/// as vanilla sends no line then.
fn ban_ip_info(names: &[&str]) -> Option<Text> {
    if names.is_empty() {
        return None;
    }
    Some(Text::translate(
        "commands.banip.info",
        &[
            Text::literal(names.len().to_string()),
            horizon_client::scoreboard_cmd::format_list(
                names
                    .iter()
                    .map(|n| Text::literal((*n).to_owned()))
                    .collect(),
            ),
        ],
    ))
}

/// `MinecraftServer.isAutoSave`: all of Horizon's server levels share this save flag.
fn auto_save(state: &ServerState) -> bool {
    state.lists.lock().unwrap().autosave
}

/// `MinecraftServer.tickServer`'s pause-when-empty count. `pause_after` is its
/// `pauseWhenEmptySeconds() * 20`; while that is above 0, a tick with no player and no
/// `/tick sprint` running (`ServerTickRateManager.isSprinting`) adds one to `empty_ticks`, and any
/// other tick sets it back to 0. A `/pregen` task keeps the server busy as a player would: paused,
/// nothing would post-process its chunks. Returns whether the server is paused this tick.
fn count_empty_tick(
    empty_ticks: &mut i32,
    pause_after: i32,
    players: usize,
    pregen: bool,
    sprinting: bool,
) -> bool {
    if pause_after > 0 {
        if players == 0 && !pregen && !sprinting {
            *empty_ticks += 1;
        } else {
            *empty_ticks = 0;
        }
    }
    pause_after > 0 && *empty_ticks >= pause_after
}

/// `MinecraftServer.setAutoSave`: enable or disable periodic saves and report whether it changed.
pub(super) fn set_auto_save(lists: &Mutex<Lists>, enabled: bool) -> bool {
    let mut l = lists.lock().unwrap();
    let changed = l.autosave != enabled;
    l.autosave = enabled;
    changed
}

/// The dedicated-only commands' replies vanilla sends with `broadcast`
/// (`sendSuccess(..., true)`): the operators hear of them.
const BROADCAST: &[&str] = &[
    "commands.ban.success",
    "commands.banip.info",
    "commands.banip.success",
    "commands.deop.success",
    "commands.kick.success",
    "commands.op.success",
    "commands.pardon.success",
    "commands.pardonip.success",
    "commands.save.disabled",
    "commands.save.enabled",
    "commands.save.success",
    "commands.stop.stopping",
    "commands.whitelist.add.success",
    "commands.whitelist.disabled",
    "commands.whitelist.enabled",
    "commands.whitelist.reloaded",
    "commands.whitelist.remove.success",
];

impl Game<'_> {
    /// DedicatedServer.initServer and MinecraftServer.runServer.
    // The epoch starts at world open; failures before that send no lifecycle event.
    pub(super) fn run_dedicated(&mut self) -> Result<()> {
        let result = self.run_dedicated_inner();
        if let Err(error) = &result {
            self.native_players_leaving();
            self.native_lifecycle_world_failed(&error.to_string());
            self.native_lifecycle_close_failed(&error.to_string());
            // Main: a world the packs can't load ends the start, and the process, normally.
            if error.downcast_ref::<DatapacksRefused>().is_some() {
                return Ok(());
            }
        }
        result
    }

    fn run_dedicated_inner(&mut self) -> Result<()> {
        // This thread ticks the server (MinecraftServer.spin's priority).
        horizon_threads::favour_current();
        self.join_world_rest()?;
        let Setup {
            props,
            universe,
            level_name,
            port,
            started,
        } = SETUP
            .get()
            .and_then(|m| m.lock().unwrap().take())
            .ok_or("dedicated server not prepared")?;
        // Main's WorldLoader: a new world's dimensions come from
        // server.properties before the server starts.
        let world_dir = std::env::current_dir()?.join(&universe).join(&level_name);
        let new_world = !world_dir.join("level.dat").exists();
        if new_world {
            self.write_world_gen(&world_dir, &props)?;
        }
        // The console thread starts first, as in initServer.
        let (tx, console) = mpsc::channel();
        std::thread::Builder::new()
            .name("Server console handler".into())
            .spawn(move || {
                let stdin = std::io::stdin();
                let mut line = String::new();
                while stdin.read_line(&mut line).is_ok_and(|n| n > 0) {
                    if tx
                        .send(line.trim_end_matches(['\r', '\n']).to_owned())
                        .is_err()
                    {
                        break;
                    }
                    line.clear();
                }
            })?;
        // Main: Services.create loads the universe's usercache.json.
        let (mut cache, warnings) = UserCache::load(universe.join("usercache.json"));
        for warning in warnings {
            log_from("main", "WARN", &warning);
        }
        // DedicatedServer.initServer: names nobody has resolve offline only without authentication.
        cache.resolve_offline_users = !props.online_mode;
        *USER_CACHE.lock().unwrap() = Some(cache);
        // Services.create: the services' public keys, fetched in the
        // background (they check players' chat keys).
        let secure_chat = Arc::new(horizon_client::lan::SecureChat::new(
            props.enforce_secure_profile && props.online_mode,
            || {
                let discovery = profiles::discovery_url();
                profiles::fetch_profile_key_keys(&discovery).unwrap_or_else(|e| {
                    ::log::error!("{e}");
                    Vec::new()
                })
            },
        ));
        log(
            "INFO",
            &format!(
                "Starting minecraft server version {}",
                horizon_core::VANILLA_VERSION
            ),
        );
        log("INFO", "Loading properties");
        let game_mode = props.game_mode;
        log(
            "INFO",
            &format!(
                "Default game type: {}",
                GAME_MODES[game_mode as usize].to_uppercase()
            ),
        );
        let port = port.unwrap_or(props.server_port as u16);
        // MinecraftServer.initializeKeyPair (only online mode uses it).
        log("INFO", "Generating keypair");
        let online = if props.online_mode {
            Some(Arc::new(OnlineMode::generate(
                props.prevent_proxy_connections,
            )?))
        } else {
            None
        };
        log(
            "INFO",
            &format!(
                "Starting Minecraft server on {}:{port}",
                if props.server_ip.is_empty() {
                    "*"
                } else {
                    &props.server_ip
                }
            ),
        );
        if online.is_none() {
            log("WARN", "**** SERVER IS RUNNING IN OFFLINE/INSECURE MODE!");
            log(
                "WARN",
                "The server will make no attempt to authenticate usernames. Beware.",
            );
            log(
                "WARN",
                "While this makes the game possible to play without internet access, it also opens up the ability for hackers to connect with any username they choose.",
            );
            log(
                "WARN",
                "To change this, set \"online-mode\" to \"true\" in the server.properties file.",
            );
        }
        let mut lists = Lists::load();
        lists.use_whitelist = props.white_list;
        lists.enforce_whitelist = props.enforce_whitelist;
        lists.op_level = props.op_permission_level;
        lists.player_idle_timeout = props.player_idle_timeout;
        let lists = Arc::new(Mutex::new(lists));
        self.server_lists = Some(lists.clone());
        log("INFO", &format!("Preparing level \"{level_name}\""));
        let folder = world_dir.to_string_lossy().into_owned();
        // The mods' common and server configs, read before the server starts.
        self.native_configs_server_start(&world_dir, true);
        // MinecraftServer.loadLevel's start: nothing is loaded yet.
        self.native_server_about_to_start(true);
        self.native_lifecycle_open_started();
        // The registries the server sends are read while the world prepares.
        let sync = super::lan::preload_sync_data(&self.options.resources);
        self.load_world(WorldRequest::new(
            &folder,
            Some(&level_name),
            Some(props.seed),
            game_mode == 1,
            None,
        )?)?;
        // WorldLoader: the world's packs must load before the server starts. The data store is read
        // now rather than at the first tick (reading parses functions; it runs none), and a broken
        // predicate graph stops the start before anything listens (a partial check: predicate_graph.rs).
        self.ensure_datapacks();
        let store = &self.fns.store;
        let tag = |id: &str| {
            let (ns, path) = id.split_once(':').unwrap_or(("minecraft", id));
            store
                .files
                .contains_key(&format!("tags/{ns}:predicate/{path}"))
        };
        if let Err(error) = predicate_graph::check(&store.predicates, tag) {
            let level = match error {
                predicate_graph::GraphError::Unbound(_)
                | predicate_graph::GraphError::UnboundTags(_) => "ERROR",
                predicate_graph::GraphError::Recursive(_) => "WARN",
            };
            for line in error.lines() {
                log(level, &line);
            }
            log(
                "WARN",
                "Failed to load datapacks, can't proceed with server load. You can either fix your datapacks or reset to vanilla with --safeMode",
            );
            return Err(Box::new(DatapacksRefused));
        }
        if new_world {
            self.level.hardcore = props.hardcore;
        }
        // The single-player host's state is not used: players have their own files.
        self.level.position = None;
        // DedicatedServer.initServer: worldData.setGameType; forceDifficulty.
        // `load_world` restored difficulty from level.dat; server.properties wins
        // (vanilla's forceDifficulty), including health_rules used for despawn (#4694).
        self.set_default_game_mode(game_mode);
        // MinecraftServer.setDifficulty: a hardcore world is always hard.
        self.ui.difficulty = if self.level.hardcore {
            3
        } else {
            props.difficulty as u8
        };
        self.level.set_difficulty(self.ui.difficulty);
        self.sync_rules();
        // DedicatedServer.initServer: a legacy `announce-player-achievements`
        // sets the show_advancement_messages rule once, as the file is read.
        if let Some(announce) = props.announce_player_achievements {
            self.ui.rules.set(
                "show_advancement_messages",
                horizon_client::gamerules::Value::Bool(announce),
            );
        }
        self.settings.render_distance = props.view_distance.clamp(2, 32);
        self.settings.simulation_distance = props.simulation_distance.clamp(2, 32);
        // Nothing is kept around the spawn while nobody is on.
        self.streaming.radius = -1;
        self.settle_spawn()?;
        self.prepare_levels()?;
        let gate_lists = lists.clone();
        let gate: LoginGate = Arc::new(move |address, uuid, name| {
            // `ServerActivityMonitor.reportLoginActivity`: a login attempt, however it ends. The management
            // protocol's `server/activity` notification is rate limited from these.
            events::record_server("login_activity", serde_json::json!({}));
            let user = NameAndId {
                id: uuid,
                name: name.to_owned(),
            };
            gate_lists.lock().unwrap().can_login(address, &user)
        });
        let bypass_lists = lists.clone();
        // DedicatedServer's constructor: `enable-code-of-conduct` reads the
        // `codeofconduct` folder, and a folder it can't read stops the start.
        let code_of_conducts = if props.code_of_conduct {
            horizon_client::lan::code_of_conduct::read(std::path::Path::new("codeofconduct"))?
        } else {
            Vec::new()
        };
        let favicon = std::fs::read("server-icon.png")
            .ok()
            .filter(|b| png_size(b) == Some((64, 64)));
        // Behind a Velocity proxy: `forwarding.secret` in the server folder, like the proxy's own file.
        let forwarding_secret = forwarding_secret(online.is_some())?;
        // `[transfer]` on: a player's only way in must be the proxy, or one who joins this server
        // directly finds the older copy of itself that a hand-over left here, and items double.
        let transfers = self
            .options
            .transfers
            .clone()
            .map(horizon_client::lan::arrivals::Transfers::new);
        if transfers.is_some() && forwarding_secret.is_none() {
            return Err("server.toml's [transfer] is on, but players can join this server without the proxy: \
                 turn on Velocity forwarding (forwarding.secret, docs/velocity-forwarding.md) or turn [transfer] off"
                .into());
        }
        let net = NetConfig {
            bind: (!props.server_ip.is_empty())
                .then(|| props.server_ip.parse().ok())
                .flatten(),
            port,
            motd: props.motd.clone(),
            max_players: props.max_players.max(0) as usize,
            compression_threshold: props.network_compression_threshold,
            rate_limit: props.rate_limit,
            enable_status: props.enable_status,
            hide_online_players: props.hide_online_players,
            favicon,
            secure_chat: Some(secure_chat),
            accepts_transfers: props.accepts_transfers,
            announce: false,
            listen: true,
            bypasses_limit: Some(Arc::new(move |uuid| {
                bypass_lists
                    .lock()
                    .unwrap()
                    .ops
                    .entries()
                    .iter()
                    .any(|e| e.user.id == uuid && e.bypasses_player_limit)
            })),
            gate: Some(gate),
            online,
            forwarding_secret,
            arrivals: transfers.as_ref().map(|t| t.expected.clone()),
            log: Some(NetLog {
                write: Arc::new(log_from),
                lang: Arc::new(horizon_client::net::load_language(&self.options.resources)),
                log_ips: props.log_ips,
            }),
            resource_pack: props.resource_pack.clone(),
            code_of_conducts,
            // DedicatedServer.serverLinks: `bug-report-link` as the only link
            // (ServerLinks.KnownLinkType.BUG_REPORT is id 0).
            levels: self.level_shapes,
            horizon_clients_only: props
                .raw
                .get(horizon_client::lan::HORIZON_CLIENTS_ONLY)
                .is_some_and(|v| v.trim().eq_ignore_ascii_case("true")),
            accept_older_clients: props
                .raw
                .get(horizon_client::lan::ACCEPT_OLDER_CLIENTS)
                .is_some_and(|v| v.trim().eq_ignore_ascii_case("true")),
            older_clients_play: false,
            lod_distance: horizon_client::lod_net::distance_property(
                props.raw.get(horizon_client::lod_net::PROPERTY),
            ),
            server_links: if props.bug_report_link.is_empty() {
                Vec::new()
            } else if super::server_links::valid_untrusted_uri(&props.bug_report_link) {
                vec![horizon_protocol::packets::configuration::ServerLink {
                    kind: horizon_protocol::packets::configuration::ServerLinkKind::Known(0),
                    link: props.bug_report_link.clone(),
                }]
            } else {
                log(
                    "WARN",
                    &format!("Failed to parse bug link {}", props.bug_report_link),
                );
                Vec::new()
            },
            owner_profile: None,
            singleplayer_profile: None,
        };
        let config = HubConfig {
            allow_flight: props.allow_flight,
            default_game_mode: game_mode,
            guest_commands: true,
            force_game_mode: props.force_game_mode,
            hardcore: self.level.hardcore,
            view_distance: props.view_distance.clamp(2, 32),
            simulation_distance: props.simulation_distance.clamp(2, 32),
            dimension: self.dim.id().to_owned(),
            levels: self.level_shapes,
            seed: self.level.seed,
            max_players: props.max_players.max(0) as usize,
            integrated: false,
        };
        let settings = LanSettings {
            port,
            guest_commands: true,
            force_game_mode: props.force_game_mode,
        };
        if let Some(sync) = sync {
            sync.adopt(&self.pack_files());
        }
        if let Err(e) = self.lan_host(settings, net, config) {
            log("WARN", "**** FAILED TO BIND TO PORT!");
            log("WARN", &format!("The exception was: {e}"));
            log("WARN", "Perhaps a server is already running on that port?");
            return Ok(());
        }
        if let Some(transfers) = transfers
            && let Some(host) = self.lan.as_mut()
        {
            let s = &transfers.settings;
            log(
                "INFO",
                &format!(
                    "Transfers on (server.toml [transfer]): players expected for {} s ({} s at most, {} at once), frozen for {} ticks and held for {} ticks at most",
                    s.expect.as_secs(),
                    s.max_expect.as_secs(),
                    s.max_expected,
                    s.max_freeze_ticks,
                    s.max_hold_ticks
                ),
            );
            host.hub.transfers = Some(transfers);
        }
        self.sync_ops(&lists);
        let anticheat = load_anticheat();
        let anticheat_on = anticheat.enabled;
        let chat_filter = load_chat_filter();
        self.set_pvp_legacy_rules(load_combat());
        load_entities();
        // The anarchy extras and the Tab list's header and footer
        // (game/anarchy.rs, game/tablist.rs), read like load_combat's.
        self.load_anarchy();
        self.tablist = super::tablist::Tablist::load();
        if self.tablist.is_some() {
            log("INFO", "Tab list header and footer on (server.toml [tablist])");
        }
        // Horizon's far ring (docs/hosting.md): server.toml's `max_view_distance`.
        let far = props
            .raw
            .get(FAR_PROPERTY)
            .and_then(|v| v.trim().parse::<i32>().ok())
            .unwrap_or(0)
            .clamp(0, 32);
        let (registry, biomes) = (self.pack.assets.registry, self.res.biomes().clone());
        if let Some(host) = self.lan.as_mut() {
            if far > host.hub.config.view_distance {
                host.hub.far = Some(horizon_client::lan::far::Far::new(far, registry, biomes));
                log(
                    "INFO",
                    &format!("Sending saved chunks up to {far} chunks away (max_view_distance)"),
                );
            }
            host.hub.set_anticheat(anticheat);
            host.hub.set_chat_filter(chat_filter);
            host.hub.spawn_protection = props.spawn_protection;
            host.hub.chat_spam_threshold = props.chat_spam_threshold_seconds.wrapping_mul(20);
            host.hub.command_spam_threshold = props.command_spam_threshold_seconds.wrapping_mul(20);
            // Off: an operator's commands reach no other player, only the log.
            host.hub.admin_feedback_to_ops = props
                .raw
                .get(ADMIN_FEEDBACK_PROPERTY)
                .is_none_or(|v| v.trim() != "false");
        }
        log(
            "INFO",
            &format!(
                "Done ({:.3}s)! For help, type \"help\"",
                started.elapsed().as_secs_f64()
            ),
        );
        // DedicatedServer.initServer ends with saveEverything(false, true, true).
        self.save_game()?;
        self.log_saved_levels();
        if let Some(host) = self.lan.as_mut() {
            host.hub.entity_range_percent = props.entity_broadcast_range_percentage;
        }
        // The dedicated server's open is complete before its first tick.
        self.native_lifecycle_world_ready();
        let mut state = ServerState {
            lists,
            console,
            empty_ticks: 0,
            pause_when_empty_seconds: props.pause_when_empty_seconds,
            ticks: Default::default(),
            paused: false,
            broadcast_console: props.broadcast_console_to_ops,
            broadcast_rcon: props.broadcast_rcon_to_ops,
            op_level: props.op_permission_level,
            game_mode: props.game_mode,
            force_game_mode: props.force_game_mode,
            report: None,
            memory_due: None,
            perf: horizon_client::server_perf::ServerPerf::new(
                0.0,
                self.options.spikes.unwrap_or(SLOW_TICK_MS),
            ),
            perf_epoch: Instant::now(),
            horizon: horizon_client::server_perf::horizon_options(
                if self.lan.as_ref().is_some_and(|h| h.hub.far.is_some()) {
                    far as u32
                } else {
                    0
                },
                horizon_client::lod_net::distance_property(
                    props.raw.get(horizon_client::lod_net::PROPERTY),
                ),
                anticheat_on,
            ),
            compression: props.network_compression_threshold,
            view: (
                props.view_distance.clamp(2, 32) as u32,
                props.simulation_distance.clamp(2, 32) as u32,
            ),
            max_players: props.max_players.max(0) as usize,
        };
        horizon_client::server_perf::warm_hardware();
        if let Some(file) = std::env::var_os("HORIZON_TRACE").filter(|f| !f.is_empty()) {
            self.record_report(
                &mut state,
                &report::Plan {
                    seconds: report::MAX_SECONDS,
                    samples: false,
                    timeline: true,
                    file: Some(file.into()),
                    trigger: Trigger::Env,
                    sampler: Default::default(),
                },
            );
        }
        let mut next = Instant::now();
        // The panic that ended the tick loop, when one did.
        let mut crashed: Option<String> = None;
        self.fns.permission = Some(props.function_permission_level.clamp(0, 4) as u8);
        let watchdog = Watchdog::start(props.max_tick_time);
        let mut braked = Instant::now();
        let mut overload_warned: Option<Instant> = None;
        // `/stop`, or a stop signal (the shutdown hook's `halt`): either way the players and levels are
        // saved below, after the wait `[transfer]` may make (transfer.rs).
        while !self.stop_now(&state) {
            self.server_tick_deadline = Some(next + self.clock.tick_duration());
            let tick_start = Instant::now();
            if let Some(watchdog) = &watchdog {
                watchdog.tick_due(next, self.clock.tick_duration());
            }
            // The console's lines and the control socket run in the tick too
            // (`handleConsoleInputs`): a panic there is the same crash.
            let prelude = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                while let Ok(line) = state.console.try_recv() {
                    self.console_line(&mut state, &line);
                }
                self.poll_server_control(&mut state);
            }));
            if let Err(payload) = prelude {
                crashed = Some(panic_message(payload.as_ref()));
                break;
            }
            let players = self.lan.as_ref().map_or(0, |h| h.hub.guests.len());
            // Vanilla reads pauseWhenEmptySeconds on every tick, so management changes take effect
            // without restarting the server.
            let pause_after = state.pause_when_empty_seconds.wrapping_mul(20);
            let paused = count_empty_tick(
                &mut state.empty_ticks,
                pause_after,
                players,
                self.pregen_level().is_some(),
                self.clock.sprinting(),
            );
            state.paused = paused;
            if paused && state.empty_ticks == pause_after {
                log(
                    "INFO",
                    &format!(
                        "Server empty for {} seconds, pausing",
                        state.pause_when_empty_seconds
                    ),
                );
                self.save_game()?;
            }
            if !paused && !auto_save(&state) {
                // `MinecraftServer.autoSave` keeps its schedule while every level's
                // `noSave` flag is set, but writes nothing. The tick below counts down
                // once, so reset one tick early when this save would have been due.
                if self.ticks_until_autosave <= 1 {
                    self.ticks_until_autosave = self.next_autosave_interval() + 1;
                }
            }
            // MinecraftServer.tickServer: while paused only the connections run.
            // `MinecraftServer.runServer` catches what the tick throws, writes the crash
            // report and still stops the server (saves). A panic here does the same.
            let slow_ms = state.perf.slow_threshold_ms();
            let capturing = state.perf.capturing();
            let mut tick_detail = None;
            let ticked = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                let mut detail = |timing: super::levels::TickTiming| {
                    if capturing || timing.wall_ms > slow_ms {
                        tick_detail = Some(horizon_client::server_perf::TickDetail {
                            cpu_ms: timing.cpu_ms,
                            spans: timing.raw,
                        });
                    }
                };
                match &mut state.report {
                    Some(recording) => {
                        let sampled = recording.sample_next();
                        super::tick_profile::set_sampling(sampled);
                        let ticked = self.tick_server_spans(paused, |timing| {
                            recording.add(sampled);
                            detail(timing)
                        });
                        super::tick_profile::set_sampling(false);
                        ticked
                    }
                    None => self.tick_server_spans(paused, detail),
                }
            }));
            match ticked {
                Ok(result) => result?,
                Err(payload) => {
                    crashed = Some(panic_message(payload.as_ref()));
                    break;
                }
            }
            if state.report.as_ref().is_some_and(report::Recording::done) {
                self.finish_perf_capture(&mut state, StopReason::Normal);
            }
            self.serve_perf_requests(&mut state);
            let done = report::log_saved(&mut state.perf, false);
            self.perf_captures_done(done);
            // DedicatedServer.sendLowDiskSpaceWarning: the operators hear of it
            // (no window drains the toasts here).
            if horizon_client::chunk_io::take().low_disk_space
                && let Some(host) = self.lan.as_ref()
            {
                host.hub.send_low_disk_space_warning();
            }
            // `PlayerList.tick` reads `MinecraftServer.playerIdleTimeout`
            // every tick, so `/setidletimeout` changes it while the server runs.
            let idle_timeout = state.lists.lock().unwrap().player_idle_timeout;
            if idle_timeout > 0 {
                self.kick_idle(idle_timeout);
            }
            // MinecraftServer.tickServer records each tick's time, for /tick query (and the status).
            self.clock.record(tick_start.elapsed());
            state.perf.tick(
                state.perf_epoch.elapsed().as_secs_f64(),
                tick_start.elapsed().as_secs_f32() * 1000.0,
                tick_detail.take(),
                || self.perf_world_counts(),
                || self.wire_bytes(),
            );
            self.poll_server_memory_snapshot(&mut state);
            // The far ring's brake, once a second on the average tick.
            if braked.elapsed() >= Duration::from_secs(1)
                && let Some(host) = self.lan.as_mut()
                && let Some(far) = host.hub.far.as_mut()
            {
                braked = Instant::now();
                let mspt = self.clock.average_nanos() as f64 / 1e6;
                far.brake(mspt, host.hub.config.view_distance);
            }
            state.ticked(Instant::now());
            // MinecraftServer.runServer: a server more than a second's ticks
            // behind skips them and says so, at most every 15 seconds.
            if let Some(behind) = self.wait_for_next_server_tick(&mut next, paused)
                && overload_warned.is_none_or(|at| at.elapsed() >= OVERLOAD_WARNING_INTERVAL)
            {
                overload_warned = Some(Instant::now());
                log(
                    "WARN",
                    &overload_warning(behind, self.clock.tick_duration()),
                );
            }
        }
        if let Some(watchdog) = &watchdog {
            watchdog.running.store(false, Ordering::Relaxed);
        }
        self.finish_perf_capture(&mut state, StopReason::Shutdown);
        let done = report::log_saved(&mut state.perf, true);
        self.perf_captures_done(done);
        match crashed {
            Some(message) => self.stop_after_crash(&message),
            None => self.stop_dedicated(),
        }
    }

    /// A dedicated server of its own, not single player's server thread
    /// (which runs with `options.dedicated` too).
    pub(super) fn standalone_server(&self) -> bool {
        self.options.dedicated.is_some() && self.serving.is_none()
    }
    /// Load the spawn area and find the world spawn as single player does,
    /// without keeping a player there. A dedicated server only finds the world
    /// spawn (MinecraftServer.setInitialSpawn): a player's spawn is found as
    /// one joins.
    pub(super) fn settle_spawn(&mut self) -> Result<()> {
        let deadline = Instant::now() + Duration::from_secs(600);
        if self.standalone_server() {
            if self.level.spawn.is_none() {
                let [x, y, z] = loop {
                    self.update_world();
                    if let Some(pos) = self.find_world_spawn()? {
                        break pos;
                    }
                    if Instant::now() > deadline {
                        return Err("the spawn area did not load".into());
                    }
                    std::thread::sleep(Duration::from_millis(2));
                };
                self.level.spawn = Some([f64::from(x), f64::from(y), f64::from(z)]);
                self.level.world_spawn.get_or_insert([x, y, z]);
                self.streaming.extra.clear();
            }
            self.spawn = self
                .level
                .spawn
                .map(|s| horizon_core::geometry::Vec3::new(s[0] + 0.5, s[1], s[2] + 0.5));
            return Ok(());
        }
        while self.player.is_none() {
            self.update_world();
            self.spawn_player()?;
            if Instant::now() > deadline {
                return Err("the spawn area did not load".into());
            }
            std::thread::sleep(Duration::from_millis(2));
        }
        self.player = None;
        Ok(())
    }

    /// The chunks to keep loaded: the players' (lan_update_streaming). While
    /// nobody is online a dedicated server keeps none (vanilla has no spawn
    /// ticket), an integrated one the spawn chunk's.
    pub(super) fn update_dedicated_streaming(&mut self) {
        let rule = self.ui.rules.bool("spectators_generate_chunks");
        let guest = self.lan.as_ref().and_then(|h| {
            // A held player (arriving from another server) is sent the level too, so it
            // holds the world loaded around it as a placed player does.
            h.hub
                .loading_chunks(|g| super::game_mode::loads_chunks(rule, g.spectator()))
                .first()
                .copied()
        });
        if self.standalone_server() {
            self.streaming.radius = if guest.is_some() {
                self.settings.render_distance
            } else {
                -1
            };
        }
        let spawn = self
            .spawn
            .map(|s| ((s.x.floor() as i32) >> 4, (s.z.floor() as i32) >> 4));
        if let Some(c) = guest.or(spawn) {
            self.streaming.center = c;
        }
    }

    /// ServerGamePacketListenerImpl.tick: players idle longer than the
    /// timeout are kicked.
    fn kick_idle(&mut self, minutes: i32) {
        let Some(host) = self.lan.as_mut() else {
            return;
        };
        let idle: Vec<u32> = host
            .hub
            .guests
            .iter()
            .filter(|g| {
                let idle_ticks = host.hub.ticks.saturating_sub(g.last_action_tick);
                let won_game = host.play.get(&g.conn).is_some_and(|play| play.won_game);
                idles_out(idle_ticks, minutes, won_game)
            })
            .map(|g| g.conn)
            .collect();
        for conn in idle {
            host.hub
                .kick(conn, translatable("multiplayer.disconnect.idling", &[]));
        }
    }

    /// Ops' permission levels for the hub (PlayerList.getProfilePermissions).
    pub(super) fn sync_ops(&mut self, lists: &Arc<Mutex<Lists>>) {
        let Some(host) = self.lan.as_mut() else {
            return;
        };
        host.hub.ops = lists
            .lock()
            .unwrap()
            .ops
            .entries()
            .iter()
            .map(|e| (e.user.id, e.level as u8))
            .collect();
        self.resend_commands_filtered();
    }

    /// A player on the server, by name.
    pub(super) fn online_player(&self, name: &str) -> Option<NameAndId> {
        let hub = &self.lan.as_ref()?.hub;
        let g = hub
            .guests
            .iter()
            .find(|g| g.name.eq_ignore_ascii_case(name))?;
        Some(NameAndId {
            id: g.uuid,
            name: g.name.clone(),
        })
    }

    /// GameProfileArgument for a name: the user cache, else the profile
    /// service, else (offline) the offline player. None, told to the console:
    /// no such player.
    fn resolve(&self, name: &str) -> Option<NameAndId> {
        let found = self.resolve_name(name);
        if found.is_none() {
            let unknown = Text::translate("argument.player.unknown", &[]);
            log("INFO", &format!("System chat: {}", unknown.plain()));
        }
        found
    }

    /// `Services.nameToIdCache().get(name)`: the user cache, else the profile
    /// service, else (offline) the offline player.
    pub(super) fn resolve_name(&self, name: &str) -> Option<NameAndId> {
        USER_CACHE.lock().unwrap().as_mut().and_then(|cache| {
            cache.get_by_name(name, |lower| {
                let found = profiles::find_by_name(&profiles::discovery_url(), lower);
                if found.is_none() {
                    log("WARN", &format!("Couldn't find profile with name: {lower}"));
                }
                found
            })
        })
    }

    /// MinecraftServer.sendSystemMessage: what the console is told; while
    /// the console runs a command, the replies vanilla broadcasts go to the
    /// operators too.
    fn console_reply(&mut self, text: Text) {
        log("INFO", &format!("System chat: {}", text.plain()));
        if self.console_broadcast.is_some()
            && text
                .translation_key()
                .is_some_and(|k| BROADCAST.contains(&k))
        {
            self.broadcast_to_admins(text);
        }
    }

    /// One console line, then the operators' share of its feedback.
    fn console_line(&mut self, state: &mut ServerState, line: &str) {
        self.console_line_telling(state, line, state.broadcast_console);
    }

    /// One console line run as `RconConsoleSource` runs an RCON command: the same console at level 4,
    /// its source named `Rcon`, and the operators told when `broadcast-rcon-to-ops` is on.
    fn rcon_line(&mut self, state: &mut ServerState, line: &str) {
        self.rcon_source = true;
        self.console_line_telling(state, line, state.broadcast_rcon);
        self.rcon_source = false;
    }

    /// `console_line` with `inform` as `CommandSource.shouldInformAdmins`.
    fn console_line_telling(&mut self, state: &mut ServerState, line: &str, inform: bool) {
        self.console_broadcast = Some(inform);
        self.console_command(state, line);
        self.console_broadcast = None;
        if let Some(mut host) = self.lan.take() {
            crash_fixture("hub", || host.hub.guests.iter().any(|g| g.placed));
            self.run_level_teleports(&mut host);
            self.send_admin_feedback(&mut host, None);
            self.lan = Some(host);
        }
        self.admin_feedback.clear();
    }

    /// `MinecraftServer.createCommandSourceStack`: the console's source is
    /// bound to the overworld, whichever level the last server tick left in
    /// place (the last one ticked, often the nether). Its commands run there
    /// and the level in place is put back afterwards.
    /// The source is the server's own: no entity, at the world spawn, its feedback heard
    /// (the console's and an RCON client's always is).
    fn as_console_in_overworld<T>(&mut self, f: impl FnOnce(&mut Self) -> T) -> T {
        let back = console_level(self.dim).and_then(|dim| self.enter_command_level(dim));
        let source = super::commands::execute::Source {
            silent: false,
            ..self.server_source()
        };
        let outer = self.command_source.replace(source);
        let out = self.as_console(f);
        self.command_source = outer;
        if let Some(back) = back {
            self.enter_command_level(back);
        }
        out
    }

    /// DedicatedServer.handleConsoleInputs: one console line, run as the
    /// server (permission level 4). The dedicated-only commands are here;
    /// everything else goes to the game's dispatcher.
    fn console_command(&mut self, state: &mut ServerState, line: &str) {
        let (mut cancel, mut replies) = (false, Vec::new());
        let source = if self.rcon_source { "rcon" } else { "console" };
        self.native_console_line(source, line, &mut cancel, &mut replies);
        for reply in replies {
            self.console_reply(reply);
        }
        if cancel {
            return;
        }
        let line = line.strip_prefix('/').unwrap_or(line);
        let mut words = line.split_whitespace();
        let Some(command) = words.next() else {
            return;
        };
        let rest: Vec<&str> = words.collect();
        let lit = |s: &str| Text::literal(s.to_owned());
        match command {
            "stop" => {
                self.console_reply(Text::translate("commands.stop.stopping", &[]));
                state.lists.lock().unwrap().stop = true;
            }
            // Horizon's own, on the console only: a performance report (report.rs).
            "horizon-report" | "horizon-trace" => {
                let trace = command == "horizon-trace";
                let parsed = if trace {
                    report::parse_trace(&rest)
                } else {
                    report::parse(&rest)
                };
                match parsed {
                    Err(()) if trace => log(
                        "INFO",
                        &format!(
                            "horizon-trace [SECONDS | stop]: 1 to {} seconds, 30 by default",
                            report::MAX_SECONDS
                        ),
                    ),
                    Err(()) => log(
                        "INFO",
                        &format!(
                            "horizon-report [SECONDS | stop | status] [--no-samples] [--timeline]: 1 to {} seconds, 60 by default",
                            report::MAX_SECONDS
                        ),
                    ),
                    Ok(report::Command::Stop) if state.report.is_some() => {
                        log("INFO", "Stopping the performance report: writing it now");
                        self.finish_perf_capture(state, StopReason::Normal);
                    }
                    Ok(report::Command::Stop) => {
                        log("INFO", "No performance report is being recorded")
                    }
                    Ok(report::Command::Status) => match &state.report {
                        Some(recording) => log("INFO", &recording.status()),
                        None => log("INFO", "No performance report is being recorded"),
                    },
                    Ok(report::Command::Record {
                        seconds,
                        samples,
                        timeline,
                    }) if state.report.is_none() => {
                        self.record_report(
                            state,
                            &report::Plan {
                                seconds,
                                samples,
                                timeline,
                                file: None,
                                trigger: Trigger::Console,
                                sampler: Default::default(),
                            },
                        );
                        log(
                            "INFO",
                            &format!("Recording a performance report for {seconds} s (reports/)"),
                        );
                    }
                    Ok(report::Command::Record { .. }) => {
                        log("INFO", "A performance report is already being recorded")
                    }
                }
            }
            "save-all" => {
                self.console_reply(Text::translate("commands.save.saving", &[]));
                let saved = self.save_game();
                if let Err(e) = &saved {
                    // The reason the save did not go through is Horizon's own
                    // detail, so it stays in the log; the source hears what
                    // SaveAllCommand tells it (ERROR_FAILED).
                    log("ERROR", &format!("{e}"));
                }
                self.console_reply(save_all_reply(saved.is_ok()));
            }
            "save-off" => {
                if set_auto_save(&state.lists, false) {
                    self.console_reply(Text::translate("commands.save.disabled", &[]));
                } else {
                    self.console_reply(Text::translate("commands.save.alreadyOff", &[]));
                }
            }
            "save-on" => {
                if set_auto_save(&state.lists, true) {
                    self.console_reply(Text::translate("commands.save.enabled", &[]));
                } else {
                    self.console_reply(Text::translate("commands.save.alreadyOn", &[]));
                }
            }
            "list" => {
                let guests: Vec<(String, u128)> = self
                    .lan
                    .as_ref()
                    .map(|h| {
                        h.hub
                            .guests
                            .iter()
                            .map(|g| (g.name.clone(), g.uuid))
                            .collect()
                    })
                    .unwrap_or_default();
                let max = self
                    .lan
                    .as_ref()
                    .map_or(0, |h| h.hub.lan.shared.max_players());
                let names: Vec<String> = if rest.first() == Some(&"uuids") {
                    guests
                        .iter()
                        .map(|(n, u)| {
                            format!("{n} ({})", horizon_protocol::crypto::uuid_string(*u))
                        })
                        .collect()
                } else {
                    guests.iter().map(|(n, _)| n.clone()).collect()
                };
                self.console_reply(Text::translate(
                    "commands.list.players",
                    &[
                        lit(&guests.len().to_string()),
                        lit(&max.to_string()),
                        lit(&names.join(", ")),
                    ],
                ));
            }
            "op" | "deop" if !rest.is_empty() => {
                let Some(user) = self.resolve(rest[0]) else {
                    return;
                };
                let level = state.op_level;
                let changed = {
                    let mut l = state.lists.lock().unwrap();
                    if command == "op" {
                        if l.ops.contains(&user) {
                            false
                        } else {
                            l.ops.add(OpEntry {
                                user: user.clone(),
                                level,
                                bypasses_player_limit: false,
                            })
                        }
                    } else {
                        l.ops.remove(&user)
                    }
                };
                let key = match (command, changed) {
                    ("op", true) => "commands.op.success",
                    ("op", false) => "commands.op.failed",
                    (_, true) => "commands.deop.success",
                    _ => "commands.deop.failed",
                };
                self.console_reply(Text::translate(key, &[lit(&user.name)]));
                let lists = state.lists.clone();
                self.sync_ops(&lists);
                // DeOpCommands.deopPlayers.
                if command == "deop" && changed {
                    self.kick_unlisted_players(&lists);
                }
            }
            "whitelist" => self.console_whitelist(state, &rest),
            // The chat filter's (game/chat_filter.rs), on servers that filter.
            command
                if super::chat_filter::MUTE_COMMANDS.contains(&command)
                    && self.lan.as_ref().is_some_and(|h| h.hub.chat_filter_on()) =>
            {
                if let Some(mut host) = self.lan.take() {
                    let words: Vec<&str> = [command].into_iter().chain(rest).collect();
                    let replies = self.mute_command(&mut host, &words, "Server");
                    self.lan = Some(host);
                    for reply in replies {
                        self.console_reply(reply.text());
                    }
                }
            }
            // Horizon's temporary ban (game/tempban.rs), as an operator's `/tempban`.
            command if super::tempban::TEMPBAN_COMMANDS.contains(&command) => {
                if let Some(mut host) = self.lan.take() {
                    let words: Vec<&str> = [command].into_iter().chain(rest).collect();
                    let replies = self.tempban_command(&mut host, &words, "Server");
                    self.lan = Some(host);
                    for reply in replies {
                        self.console_reply(reply.text());
                    }
                }
            }
            "ban" if !rest.is_empty() => {
                let Some(user) = self.resolve(rest[0]) else {
                    return;
                };
                let reason = (rest.len() > 1).then(|| rest[1..].join(" "));
                let added = state.lists.lock().unwrap().ban(&user, reason.clone());
                if added {
                    self.console_reply(Text::translate(
                        "commands.ban.success",
                        &[
                            lit(&user.name),
                            reason.as_deref().map_or_else(
                                || {
                                    Text::translate(
                                        "multiplayer.disconnect.banned.reason.default",
                                        &[],
                                    )
                                },
                                lit,
                            ),
                        ],
                    ));
                    self.kick_uuid(user.id, translatable("multiplayer.disconnect.banned", &[]));
                } else {
                    self.console_reply(Text::translate("commands.ban.failed", &[]));
                }
            }
            "ban-ip" if !rest.is_empty() => {
                let target = rest[0];
                let ip = if target.parse::<std::net::IpAddr>().is_ok() {
                    Some(target.to_owned())
                } else {
                    self.lan.as_ref().and_then(|h| {
                        h.hub
                            .guests
                            .iter()
                            .find(|g| g.name.eq_ignore_ascii_case(target))
                            .map(|g| g.address.ip().to_string())
                    })
                };
                let Some(ip) = ip else {
                    self.console_reply(Text::translate("commands.banip.invalid", &[]));
                    return;
                };
                let reason = (rest.len() > 1).then(|| rest[1..].join(" "));
                let added = state.lists.lock().unwrap().ban_ip(&ip, reason.clone());
                if !added {
                    self.console_reply(Text::translate("commands.banip.failed", &[]));
                    return;
                }
                self.console_reply(Text::translate(
                    "commands.banip.success",
                    &[
                        lit(&ip),
                        reason.as_deref().map_or_else(
                            || Text::translate("multiplayer.disconnect.banned.reason.default", &[]),
                            lit,
                        ),
                    ],
                ));
                let banned: Vec<(u128, String)> = self
                    .lan
                    .as_ref()
                    .map(|h| {
                        h.hub
                            .guests
                            .iter()
                            .filter(|g| g.address.ip().to_string() == ip)
                            .map(|g| (g.uuid, g.name.clone()))
                            .collect()
                    })
                    .unwrap_or_default();
                let names: Vec<&str> = banned.iter().map(|(_, n)| n.as_str()).collect();
                if let Some(info) = ban_ip_info(&names) {
                    self.console_reply(info);
                }
                for (uuid, _) in banned {
                    self.kick_uuid(uuid, translatable("multiplayer.disconnect.ip_banned", &[]));
                }
            }
            "pardon" if !rest.is_empty() => {
                let Some(user) = self.resolve(rest[0]) else {
                    return;
                };
                let removed = state.lists.lock().unwrap().bans.remove(&user);
                let key = if removed {
                    "commands.pardon.success"
                } else {
                    "commands.pardon.failed"
                };
                self.console_reply(Text::translate(key, &[lit(&user.name)]));
            }
            "pardon-ip" if !rest.is_empty() => {
                let ip = rest[0].to_owned();
                if ip.parse::<std::net::IpAddr>().is_err() {
                    self.console_reply(Text::translate("commands.pardonip.invalid", &[]));
                    return;
                }
                let removed = state.lists.lock().unwrap().ip_bans.remove(&ip);
                let key = if removed {
                    "commands.pardonip.success"
                } else {
                    "commands.pardonip.failed"
                };
                self.console_reply(Text::translate(key, &[lit(&ip)]));
            }
            "banlist" => {
                let l = state.lists.lock().unwrap();
                let mut lines = Vec::new();
                let which = rest.first().copied().unwrap_or("");
                if which != "ips" {
                    for b in l.bans.entries() {
                        lines.push((b.user.name.clone(), b.source.clone(), b.reason.clone()));
                    }
                }
                if which != "players" {
                    for b in l.ip_bans.entries() {
                        lines.push((b.user.clone(), b.source.clone(), b.reason.clone()));
                    }
                }
                drop(l);
                if lines.is_empty() {
                    self.console_reply(Text::translate("commands.banlist.none", &[]));
                } else {
                    self.console_reply(Text::translate(
                        "commands.banlist.list",
                        &[lit(&lines.len().to_string())],
                    ));
                    for (name, source, reason) in lines {
                        self.console_reply(Text::translate(
                            "commands.banlist.entry",
                            &[
                                lit(&name),
                                lit(&source),
                                reason.as_deref().map_or_else(
                                    || {
                                        Text::translate(
                                            "multiplayer.disconnect.banned.reason.default",
                                            &[],
                                        )
                                    },
                                    lit,
                                ),
                            ],
                        ));
                    }
                }
            }
            "kick" if !rest.is_empty() => {
                let Some(user) = self.online_player(rest[0]) else {
                    self.console_reply(Text::translate("argument.entity.notfound.player", &[]));
                    return;
                };
                let reason = if rest.len() > 1 {
                    Tag::String(JavaString::from(rest[1..].join(" ").as_str()))
                } else {
                    translatable("multiplayer.disconnect.kicked", &[])
                };
                self.kick_uuid(user.id, reason);
                self.console_reply(Text::translate(
                    "commands.kick.success",
                    &[
                        lit(&user.name),
                        if rest.len() > 1 {
                            lit(&rest[1..].join(" "))
                        } else {
                            Text::translate("multiplayer.disconnect.kicked", &[])
                        },
                    ],
                ));
            }
            "say" if !rest.is_empty() => {
                // SayCommand from the console: an unsigned system chat
                // message of type say_command, logged as not secure.
                let message = rest.join(" ");
                // An RCON client's `say` is `[Rcon] message`, and its reply stays empty: the line is
                // the console's own log, not a message to the source.
                let name = if self.rcon_source { "Rcon" } else { "Server" };
                let held = self.rcon_source.then(|| CAPTURE.take());
                log("INFO", &format!("[Not Secure] [{name}] {message}"));
                if let Some(held) = held {
                    CAPTURE.set(held);
                }
                if let Some(h) = &self.lan {
                    h.hub.say(name, &message);
                }
            }
            _ => {
                // The game's dispatcher, captured for the console.
                self.chat_capture = Some(Vec::new());
                // A command a native mod registered goes to the mods first,
                // looked up by the same first word the match above read.
                if !self.perform_native_console_command(line.trim()) {
                    self.as_console_in_overworld(|g| g.run_command(line));
                }
                for text in self.chat_capture.take().unwrap_or_default() {
                    self.console_reply(text);
                }
                // ServerPlayer.onEffectAdded and onEffectUpdated send an effect
                // the command gave as it was given: vanilla's console runs after
                // the players' tick (`DedicatedServer.tickConnection`), so the
                // next tick is the first to count it down. A player's own
                // commands sync theirs the same way (`run_guest_command`).
                if let Some(h) = self.lan.as_mut() {
                    h.hub.sync_all_effects();
                }
            }
        }
    }

    fn console_whitelist(&mut self, state: &mut ServerState, rest: &[&str]) {
        let lit = |s: &str| Text::literal(s.to_owned());
        match rest {
            ["on"] | ["off"] => {
                let on = rest[0] == "on";
                let l = state.lists.lock().unwrap();
                let turned_on = on && !l.use_whitelist;
                let key = match (on, l.use_whitelist) {
                    (true, true) => "commands.whitelist.alreadyOn",
                    (true, false) => "commands.whitelist.enabled",
                    (false, false) => "commands.whitelist.alreadyOff",
                    (false, true) => "commands.whitelist.disabled",
                };
                drop(l);
                self.set_using_whitelist(&state.lists, on);
                self.console_reply(Text::translate(key, &[]));
                if turned_on {
                    let lists = state.lists.clone();
                    self.kick_unlisted_players(&lists);
                }
            }
            ["list"] => {
                let names: Vec<String> = state
                    .lists
                    .lock()
                    .unwrap()
                    .white
                    .entries()
                    .iter()
                    .map(|e| e.user.name.clone())
                    .collect();
                if names.is_empty() {
                    self.console_reply(Text::translate("commands.whitelist.none", &[]));
                } else {
                    self.console_reply(Text::translate(
                        "commands.whitelist.list",
                        &[lit(&names.len().to_string()), lit(&names.join(", "))],
                    ));
                }
            }
            ["reload"] => {
                let _ = state.lists.lock().unwrap().white.load();
                self.console_reply(Text::translate("commands.whitelist.reloaded", &[]));
                let lists = state.lists.clone();
                self.kick_unlisted_players(&lists);
            }
            ["add", name] | ["remove", name] => {
                let Some(user) = self.resolve(name) else {
                    return;
                };
                let mut l = state.lists.lock().unwrap();
                let (ok, key) = if rest[0] == "add" {
                    if l.white.contains(&user) {
                        (false, "commands.whitelist.add.failed")
                    } else {
                        l.white.add(WhiteEntry { user: user.clone() });
                        (true, "commands.whitelist.add.success")
                    }
                } else if l.white.remove(&user) {
                    (true, "commands.whitelist.remove.success")
                } else {
                    (false, "commands.whitelist.remove.failed")
                };
                drop(l);
                let args = if ok {
                    vec![lit(&user.name)]
                } else {
                    Vec::new()
                };
                self.console_reply(Text::translate(key, &args));
                if ok && rest[0] == "remove" {
                    let lists = state.lists.clone();
                    self.kick_unlisted_players(&lists);
                }
            }
            _ => self.console_reply(Text::translate("command.unknown.argument", &[])),
        }
    }

    /// `DedicatedServer.setUsingWhitelist`: the flag, and `white-list` in
    /// server.properties.
    pub(super) fn set_using_whitelist(&mut self, lists: &Arc<Mutex<Lists>>, on: bool) {
        let changed = {
            let mut lists = lists.lock().unwrap();
            let changed = lists.use_whitelist != on;
            lists.use_whitelist = on;
            changed
        };
        self.store_property("white-list", on.to_string());
        if changed {
            self.native_whitelist_state_update(on);
        }
    }

    /// `DedicatedServer.setPlayerIdleTimeout`: update the live idle sweep and persist its minutes.
    pub(super) fn set_player_idle_timeout(&mut self, lists: &Arc<Mutex<Lists>>, minutes: i32) {
        lists.lock().unwrap().player_idle_timeout = minutes;
        self.store_property("player-idle-timeout", minutes.to_string());
    }

    /// `DedicatedServer.setMaxPlayers`: the live login limit, and `max-players` in
    /// server.properties.
    fn set_max_players(&mut self, state: &mut ServerState, max_players: usize) {
        state.max_players = max_players;
        if let Some(lan) = &self.lan {
            lan.hub.lan.shared.set_max_players(max_players);
        }
        self.store_property("max-players", max_players.to_string());
    }

    /// `DedicatedServer.setAcceptsTransfers`: whether a transfer's handshake is accepted from
    /// now on, and `accepts-transfers` in server.properties.
    fn set_accepts_transfers(&mut self, accept: bool) {
        if let Some(lan) = &self.lan {
            lan.hub.lan.shared.set_accepts_transfers(accept);
        }
        self.store_property("accepts-transfers", accept.to_string());
    }

    /// `DedicatedServer.setEnforceWhitelist`: the flag, and `enforce-whitelist` in
    /// server.properties.
    pub(super) fn set_enforce_whitelist(&mut self, lists: &Arc<Mutex<Lists>>, on: bool) {
        lists.lock().unwrap().enforce_whitelist = on;
        self.store_property("enforce-whitelist", on.to_string());
    }

    /// `DedicatedServer.setPauseWhenEmptySeconds`: the live pause timer, and
    /// `pause-when-empty-seconds` in server.properties.
    fn set_pause_when_empty_seconds(&mut self, state: &mut ServerState, seconds: i32) {
        state.pause_when_empty_seconds = seconds;
        self.store_property("pause-when-empty-seconds", seconds.to_string());
    }

    /// DedicatedServerSettings.update: change one key and store the file.
    pub(super) fn store_property(&mut self, key: &str, value: String) {
        let path = PathBuf::from("server.properties");
        if let Ok(p) = ServerProperties::from_file(&path, &mut SystemEntropy::default())
            && let Ok(p) = p.update(key, value)
        {
            let _ = p.store(&path);
        }
    }

    /// MinecraftServer.kickUnlistedPlayers: with `enforce-whitelist` and the
    /// whitelist on, whoever is online and not on the whitelist file is
    /// disconnected (operators are not spared here).
    pub(super) fn kick_unlisted_players(&mut self, lists: &Arc<Mutex<Lists>>) {
        let unlisted: Vec<u128> = {
            let l = lists.lock().unwrap();
            let Some(host) = self.lan.as_ref() else {
                return;
            };
            if !(l.enforce_whitelist && l.use_whitelist) {
                return;
            }
            host.hub
                .guests
                .iter()
                .filter(|g| {
                    !l.white.contains(&NameAndId {
                        id: g.uuid,
                        name: g.name.clone(),
                    })
                })
                .map(|g| g.uuid)
                .collect()
        };
        for uuid in unlisted {
            self.kick_uuid(
                uuid,
                translatable("multiplayer.disconnect.not_whitelisted", &[]),
            );
        }
    }

    /// The anticheat bans a player (`HostEvent::Ban`): `banned-players.json` gets it as `/ban` adds it,
    /// with the anticheat as its source, and the player is sent away with the ban's message.
    pub(super) fn anticheat_ban(
        &mut self,
        hub: &mut horizon_client::lan::hub::Hub,
        uuid: u128,
        name: &str,
        reason: &str,
    ) {
        let Some(lists) = &self.server_lists else {
            // No ban list to add to: the anticheat's kick, so a flagged cheater still doesn't stay.
            log(
                "WARN",
                &format!("Can't ban {name} ({reason}): no ban list; kicked"),
            );
            let conns: Vec<u32> = hub
                .guests
                .iter()
                .filter(|g| g.uuid == uuid)
                .map(|g| g.conn)
                .collect();
            for conn in conns {
                hub.anticheat_kick(conn);
            }
            return;
        };
        let user = NameAndId {
            id: uuid,
            name: name.to_owned(),
        };
        lists.lock().unwrap().bans.add(BanEntry::new(
            user,
            Some("Horizon anticheat".into()),
            None,
            Some(reason.to_owned()),
        ));
        log("INFO", &format!("Banned {name}: {reason}"));
        let conns: Vec<u32> = hub
            .guests
            .iter()
            .filter(|g| g.uuid == uuid)
            .map(|g| g.conn)
            .collect();
        for conn in conns {
            hub.kick(conn, translatable("multiplayer.disconnect.banned", &[]));
        }
        events::record("ban", name, uuid, serde_json::json!({ "reason": reason }));
    }

    pub(super) fn kick_uuid(&mut self, uuid: u128, reason: Tag) {
        if let Some(h) = self.lan.as_mut() {
            let conns: Vec<u32> = h
                .hub
                .guests
                .iter()
                .filter(|g| g.uuid == uuid)
                .map(|g| g.conn)
                .collect();
            for conn in conns {
                h.hub.kick(conn, reason.clone());
                if let Some(g) = h.hub.guest(conn) {
                    events::record(
                        "kick",
                        &g.name,
                        uuid,
                        serde_json::json!({ "reason": g.left_reason }),
                    );
                }
            }
        }
    }

    /// MinecraftServer.stopServer: players saved and sent away, worlds saved.
    /// MinecraftServer.saveAllChunks, not silent: one line per level, in
    /// the server's level order.
    fn log_saved_levels(&self) {
        for dimension in [
            "minecraft:overworld",
            "minecraft:the_nether",
            "minecraft:the_end",
        ] {
            log(
                "INFO",
                &format!(
                    "Saving chunks for level 'ServerLevel[{}]'/{dimension}",
                    self.level.name
                ),
            );
        }
    }

    /// `MinecraftServer.runServer`'s `finally`: a tick that panicked still saves. What the panic
    /// interrupted is not trusted: a guest's turn (`as_guest`) holds the game's player state
    /// swapped in, so its record is older than what the game holds, and writing it would put
    /// back older data than the last autosave; that guest keeps the file it has. A hub that the
    /// panic took with it (`self.lan.take()` was in progress) saves no players at all. The
    /// levels, the scoreboard and the other state are saved as in a normal stop. Single
    /// player's server thread ends here too, after a tick that panicked or failed
    /// (`integrated_tick_loop`), and then stops as `stop_integrated` does.
    pub(super) fn stop_after_crash(&mut self, message: &str) -> Result<()> {
        // Single player's server thread (`integrated.rs`) has no console: it logs to the game's log.
        let integrated = self.serving.is_some();
        let warn = |message: &str| {
            if integrated {
                log::warn!("Horizon: {message}");
            } else {
                log("WARN", message);
            }
        };
        if integrated {
            // `message` already says whether the tick panicked or failed.
            log::error!("Horizon: {message}");
        } else {
            log("ERROR", &format!("The server thread panicked: {message}"));
        }
        let acting = self.lan_acting;
        let hub_lost = self.lan.is_none();
        if let (Some(conn), Some(host)) = (acting, self.lan.as_mut())
            && let Some(guest) = host.hub.guests.iter_mut().find(|g| g.conn == conn)
        {
            guest.placed = false;
        }
        if hub_lost {
            warn("The panic interrupted the network tick: players are not saved, only the world");
        } else if acting.is_some() {
            warn("The panic interrupted a player's turn: that player keeps the last saved file");
        }
        if integrated {
            // `IntegratedServer.stopServer`'s steps; `save_guest` skips the guest unplaced above.
            return self.stop_integrated();
        }
        self.native_lifecycle.begin_close();
        log("INFO", "Saving worlds");
        self.save_game()?;
        self.log_saved_levels();
        self.native_lifecycle_world_closed();
        self.lan_close(false);
        Err(format!("the server thread panicked: {message}").into())
    }

    fn stop_dedicated(&mut self) -> Result<()> {
        // The close request starts before player and world saves.
        self.native_lifecycle.begin_close();
        // MinecraftServer.stopServer's start: everyone is still here.
        self.native_server_stopping(true);
        self.native_configs_server_stop();
        log("INFO", "Stopping server");
        self.native_players_leaving();
        log("INFO", "Saving players");
        if let Some(mut host) = self.lan.take() {
            self.flush_native_net(&mut host);
            // PlayerList.removeAll: each player's file, with the vehicle it
            // alone rides, then its records.
            self.save_leaving_guests(&mut host);
            self.lan = Some(host);
        }
        if let Some(h) = self.lan.as_mut() {
            let conns: Vec<u32> = h.hub.guests.iter().map(|g| g.conn).collect();
            for conn in conns {
                h.hub.kick(
                    conn,
                    translatable("multiplayer.disconnect.server_shutdown", &[]),
                );
            }
        }
        std::thread::sleep(Duration::from_millis(100));
        log("INFO", "Saving worlds");
        // ServerPlayer.disconnect: nobody is left in a bed.
        self.free_player_beds()?;
        self.save_game()?;
        self.log_saved_levels();
        // Only a successful final save closes the epoch; storage is still held.
        self.native_lifecycle_world_closed();
        self.lan_close(false);
        self.native_server_stopped(true);
        Ok(())
    }
}

/// `tools/test_dedicated_crash_save.py`'s fixture: with `HORIZON_CRASH_FIXTURE` naming `point`
/// (`guest`: during a placed guest's turn, `hub`: while a console line has the hub out and a
/// player is in), the tick panics there, to see what `stop_after_crash` keeps.
/// `armed` is asked only when the variable names `point`, so the tick pays one
/// load of a `OnceLock` without it.
pub(super) fn crash_fixture(point: &str, armed: impl FnOnce() -> bool) {
    static FIXTURE: std::sync::OnceLock<Option<String>> = std::sync::OnceLock::new();
    let fixture = FIXTURE.get_or_init(|| std::env::var("HORIZON_CRASH_FIXTURE").ok());
    if fixture.as_deref() == Some(point) && armed() {
        panic!("crash fixture at {point}");
    }
}

/// The text of a panic payload (`panic!("..")` is a `&str`, a formatted one a `String`).
pub(super) fn panic_message(payload: &(dyn std::any::Any + Send)) -> String {
    payload
        .downcast_ref::<&str>()
        .map(|s| (*s).to_owned())
        .or_else(|| payload.downcast_ref::<String>().cloned())
        .unwrap_or_else(|| "unknown panic".to_owned())
}

/// The width and height of a PNG (its IHDR chunk).
fn png_size(bytes: &[u8]) -> Option<(u32, u32)> {
    if bytes.len() < 24 || &bytes[..8] != b"\x89PNG\r\n\x1a\n" || &bytes[12..16] != b"IHDR" {
        return None;
    }
    let w = u32::from_be_bytes(bytes[16..20].try_into().ok()?);
    let h = u32::from_be_bytes(bytes[20..24].try_into().ok()?);
    Some((w, h))
}

/// The level a console command runs in when `active` is in place: always
/// the overworld (`MinecraftServer.createCommandSourceStack` uses
/// `overworld()`), so None when it already is.
fn console_level(active: super::Dim) -> Option<super::Dim> {
    (active != super::Dim::Overworld).then_some(super::Dim::Overworld)
}

#[cfg(test)]
mod tests {
    use super::{
        capture_log, log, log_from, overload_warning, panic_message, parse_whitelist_bypass,
    };
    use std::{
        fs,
        io::{self, BufRead, BufReader, Read, Write},
        process::{Command, Stdio},
        time::{SystemTime, UNIX_EPOCH},
    };

    /// A console line runs in the overworld even after a server tick left the nether in place.
    #[test]
    fn console_commands_run_in_the_overworld() {
        use super::super::Dim;
        assert_eq!(super::console_level(Dim::Nether), Some(Dim::Overworld));
        assert_eq!(super::console_level(Dim::End), Some(Dim::Overworld));
        assert_eq!(super::console_level(Dim::Overworld), None);
    }

    /// `BanIpCommands.banIp`: the info line names the affected players, one or several, and is
    /// absent when no one is affected.
    #[test]
    fn ban_ip_info_names_the_affected_players() {
        let args = |t: &super::Text| {
            let c = t.component();
            c["with"]
                .as_array()
                .unwrap()
                .iter()
                .map(|a| a.to_string())
                .collect::<Vec<_>>()
        };
        assert!(super::ban_ip_info(&[]).is_none());
        let one = super::ban_ip_info(&["Alex"]).unwrap();
        assert_eq!(one.translation_key(), Some("commands.banip.info"));
        let a = args(&one);
        assert!(a[0].contains('1') && a[1].contains("Alex"), "{a:?}");
        let two = super::ban_ip_info(&["Alex", "Steve"]).unwrap();
        let a = args(&two);
        assert!(a[0].contains('2'), "{a:?}");
        assert!(
            a[1].contains("Alex") && a[1].contains(", ") && a[1].contains("Steve"),
            "{a:?}"
        );
    }

    #[test]
    fn entities_section_is_off_by_default_and_keeps_the_other_settings_keys() {
        use super::parse_entities;
        assert_eq!(parse_entities(""), Ok((false, 100)));
        assert_eq!(
            parse_entities(
                "[entities]\nvillager_lobotomize = true\nvillager_lobotomize_check_interval = 40\n"
            ),
            Ok((true, 40))
        );
        assert_eq!(
            parse_entities(
                "[entities]\ndab = true\nmax_collisions = 8\nvillager_lobotomize = true\n"
            ),
            Ok((true, 100))
        );
        assert!(parse_entities("[entities]\nvillager_lobotomize_check_interval = 0\n").is_err());
    }

    #[test]
    fn whitelist_bypass_file_takes_uuid_prefixes_and_refuses_junk() {
        let ok =
            parse_whitelist_bypass("# Bedrock\n00000000-0000-0000-0009-  # floodgate\n\n").unwrap();
        assert_eq!(ok, vec!["00000000-0000-0000-0009-".to_owned()]);
        assert!(
            parse_whitelist_bypass("0-").is_err(),
            "a short prefix would match nearly everyone"
        );
        assert!(parse_whitelist_bypass("not-a-uuid-at-all").is_err());
    }

    /// ServerGamePacketListenerImpl.tick: a player idle past `player-idle-timeout` minutes is kicked,
    /// unless the End poem is showing (`ServerPlayer.wonGame`), which sends no action.
    #[test]
    fn a_player_watching_the_end_credits_is_not_kicked_for_idling() {
        use super::idles_out;
        // 5 minutes: 6000 ticks. One more is over the limit.
        assert!(!idles_out(6000, 5, false));
        assert!(idles_out(6001, 5, false));
        assert!(!idles_out(6001, 5, true));
        assert!(!idles_out(1_000_000, 5, true));
        // The credits are over (won_game false again): the same idle time kicks.
        assert!(idles_out(1_000_000, 5, false));
        // 0 or less: no timeout.
        assert!(!idles_out(1_000_000, 0, false));
        assert!(!idles_out(1_000_000, -3, false));
    }

    /// `SaveAllCommand.saveAll`: a save that throws is the `ERROR_FAILED` the
    /// source is told about, not a log line the caller never sees.
    #[test]
    fn a_failed_save_tells_the_source_that_it_failed() {
        assert_eq!(
            super::save_all_reply(true).translation_key(),
            Some("commands.save.success")
        );
        assert_eq!(
            super::save_all_reply(false).translation_key(),
            Some("commands.save.failed")
        );
    }

    /// Vanilla's words, with how far behind the server is in milliseconds and in whole ticks.
    #[test]
    fn the_overload_warning_reads_as_vanilla_s() {
        let tick = std::time::Duration::from_millis(50);
        assert_eq!(
            overload_warning(std::time::Duration::from_millis(13_027), tick),
            "Can't keep up! Is the server overloaded? Running 13027ms or 260 ticks behind"
        );
    }

    /// MinecraftServer.tickServer: a tick only counts toward pause-when-empty with no player and
    /// no `/tick sprint` running (`ServerTickRateManager.isSprinting`); a sprint on an empty server
    /// keeps the count at 0, so it is never paused, and the count starts again after it.
    #[test]
    fn a_sprint_on_an_empty_server_does_not_count_toward_the_pause() {
        let pause_after = 60 * 20;
        let mut empty_ticks = 0;
        // One server tick: (players, a `/pregen` task, a `/tick sprint`) -> paused.
        let tick = |empty_ticks: &mut i32, players, pregen, sprinting| {
            super::count_empty_tick(empty_ticks, pause_after, players, pregen, sprinting)
        };
        for _ in 0..2000 {
            assert!(!tick(&mut empty_ticks, 0, false, true));
        }
        assert_eq!(empty_ticks, 0);
        // The sprint ended: 1200 empty ticks later the server pauses, not before.
        for n in 1..=pause_after {
            assert_eq!(
                tick(&mut empty_ticks, 0, false, false),
                n == pause_after,
                "tick {n}"
            );
        }
        // A sprint that starts while paused resumes the server at once.
        assert!(!tick(&mut empty_ticks, 0, false, true));
        assert_eq!(empty_ticks, 0);
        // A player, or a `/pregen` task, resets the count too.
        empty_ticks = 5;
        assert!(!tick(&mut empty_ticks, 1, false, false));
        assert_eq!(empty_ticks, 0);
        empty_ticks = 5;
        assert!(!tick(&mut empty_ticks, 0, true, false));
        assert_eq!(empty_ticks, 0);
        // pause-when-empty-seconds=0 never pauses and leaves the count alone.
        empty_ticks = 5;
        assert!(!super::count_empty_tick(
            &mut empty_ticks,
            0,
            0,
            false,
            false
        ));
        assert_eq!(empty_ticks, 5);
    }

    /// A `panic!("literal")` carries a `&str`, a formatted one a `String`; anything else is
    /// named as unknown, so the crash line is never empty.
    #[test]
    fn a_panic_payload_is_read_as_text() {
        let literal = std::panic::catch_unwind(|| panic!("a literal")).unwrap_err();
        assert_eq!(panic_message(literal.as_ref()), "a literal");
        let n = 3;
        let formatted = std::panic::catch_unwind(|| panic!("tick {n}")).unwrap_err();
        assert_eq!(panic_message(formatted.as_ref()), "tick 3");
        let other = std::panic::catch_unwind(|| std::panic::panic_any(7_u8)).unwrap_err();
        assert_eq!(panic_message(other.as_ref()), "unknown panic");
    }

    const LOGIN: &str = "Player[/127.0.0.1:0] logged in with entity id 2 at (0.5, 115.0, 0.5)";
    const WARNING: &str = "Authentication warning";
    const READY: &str = "horizon-console-log-ready\n";
    const CHILD_HOME: &str = "HORIZON_TEST_CONSOLE_LOG_HOME";

    fn assert_log_lines(text: &str) {
        let expected = [
            format!("] [Server thread/INFO]: {LOGIN}"),
            format!("] [User Authenticator #1/WARN]: {WARNING}"),
        ];
        assert_eq!(text.lines().count(), expected.len());
        for (line, suffix) in text.lines().zip(expected) {
            assert!(line.starts_with('['));
            assert!(chrono::NaiveTime::parse_from_str(&line[1..9], "%H:%M:%S").is_ok());
            assert_eq!(&line[9..], suffix);
        }
    }

    #[test]
    fn console_logging_survives_closed_stdout() {
        if let Some(home) = std::env::var_os(CHILD_HOME) {
            horizon_client::logging::init(std::path::Path::new(&home), "Server thread");
            // Let the parent close the real stdout pipe only after libtest's startup output.
            io::stdout().write_all(READY.as_bytes()).unwrap();
            io::stdout().flush().unwrap();
            io::stdin().read_exact(&mut [0]).unwrap();
            std::thread::Builder::new()
                .name("Server thread".into())
                .spawn(|| {
                    let captured = capture_log(|| {
                        log("INFO", LOGIN);
                        log_from("User Authenticator #1", "WARN", WARNING);
                    });
                    assert_eq!(captured, [LOGIN, WARNING]);
                    horizon_client::logging::flush();
                })
                .unwrap()
                .join()
                .unwrap();
            // Libtest's final status also writes to stdout; only the game logger is under test.
            std::process::exit(0);
        }

        for closed_stdout in [false, true] {
            let unique = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos();
            let home = std::env::temp_dir().join(format!(
                "horizon-console-log-test-{}-{unique}",
                std::process::id()
            ));
            fs::create_dir(&home).unwrap();
            let mut child = Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "game::dedicated::tests::console_logging_survives_closed_stdout",
                    "--nocapture",
                ])
                .env(CHILD_HOME, &home)
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::piped())
                .spawn()
                .unwrap();
            let mut stdout = BufReader::new(child.stdout.take().unwrap());
            loop {
                let mut line = String::new();
                assert!(
                    stdout.read_line(&mut line).unwrap() > 0,
                    "child was not ready"
                );
                if line.ends_with(READY) {
                    break;
                }
            }
            if closed_stdout {
                drop(stdout); // No reader remains: the next console write gets EPIPE.
            } else {
                child.stdout = Some(stdout.into_inner());
            }
            child.stdin.take().unwrap().write_all(&[1]).unwrap();
            let output = child.wait_with_output().unwrap();
            assert!(
                output.status.success(),
                "closed_stdout={closed_stdout}: {}",
                String::from_utf8_lossy(&output.stderr)
            );
            if !closed_stdout {
                assert_log_lines(std::str::from_utf8(&output.stdout).unwrap());
            }
            assert_log_lines(&fs::read_to_string(home.join("logs/latest.log")).unwrap());
            fs::remove_dir_all(home).unwrap();
        }
    }

    /// `BanPlayerCommands.banPlayers` skips a player who `isBanned`, and `BanIpCommands.banIp` refuses an
    /// address that is: the console's `/ban` and `/ban-ip` of one banned already change nothing (the first
    /// reason stays, and the console hears "Nothing changed"), whatever reason they give.
    #[test]
    fn the_console_does_not_ban_again_who_is_banned_already() {
        use super::{BanList, Lists, NameAndId};
        let dir = std::env::temp_dir().join(format!("horizon-console-ban-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let mut lists = Lists {
            ops: super::OpList::new(dir.join("ops.json")),
            white: super::WhiteList::new(dir.join("whitelist.json")),
            bans: BanList::new(dir.join("banned-players.json")),
            ip_bans: super::IpBanList::new(dir.join("banned-ips.json")),
            use_whitelist: false,
            enforce_whitelist: false,
            op_level: 4,
            player_idle_timeout: 0,
            stop: false,
            autosave: true,
            whitelist_bypass: Vec::new(),
        };
        let alpha = NameAndId {
            id: 0x5ca1ab1e,
            name: "Alpha".into(),
        };
        assert!(lists.ban(&alpha, Some("cheating".into())));
        assert!(!lists.ban(&alpha, Some("again".into())));
        assert!(!lists.ban(&alpha, None));
        let reason = lists.bans.get(&alpha).and_then(|b| b.reason.clone());
        assert_eq!(reason.as_deref(), Some("cheating"));
        assert!(lists.ban_ip("1.2.3.4", Some("spam".into())));
        assert!(!lists.ban_ip("1.2.3.4", Some("more spam".into())));
        let reason = lists
            .ip_bans
            .get(&"1.2.3.4".to_owned())
            .and_then(|b| b.reason.clone());
        assert_eq!(reason.as_deref(), Some("spam"));
        let _ = fs::remove_dir_all(&dir);
    }

    /// A temporary ban (`/tempban`, the chat filter's) keeps the player out and says when it ends;
    /// once it has ended, or after `/pardon`, they come in.
    #[test]
    fn a_temporarily_banned_player_is_refused_with_the_end_until_it_has_passed() {
        use super::{BanEntry, BanList, Lists, NameAndId};
        use horizon_server_files::duration::now_millis;
        let dir = std::env::temp_dir().join(format!("horizon-can-login-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let mut lists = Lists {
            ops: super::OpList::new(dir.join("ops.json")),
            white: super::WhiteList::new(dir.join("whitelist.json")),
            bans: BanList::new(dir.join("banned-players.json")),
            ip_bans: super::IpBanList::new(dir.join("banned-ips.json")),
            use_whitelist: false,
            enforce_whitelist: false,
            op_level: 4,
            player_idle_timeout: 0,
            stop: false,
            autosave: true,
            whitelist_bypass: Vec::new(),
        };
        // Every translation key and string in a message, in the order they come.
        fn words(tag: &super::Tag, out: &mut Vec<String>) {
            match tag {
                super::Tag::String(s) => out.push(s.to_string_lossy()),
                super::Tag::List(items) => items.iter().for_each(|t| words(t, out)),
                super::Tag::Compound(_) => {
                    for key in ["translate", "with", "extra"] {
                        if let Some(t) = tag.get(key) {
                            words(t, out);
                        }
                    }
                }
                _ => {}
            }
        }
        let message = |tag: Option<super::Tag>| {
            let mut out = Vec::new();
            words(&tag.expect("a refusal"), &mut out);
            out.join(" | ")
        };
        let address: std::net::SocketAddr = "127.0.0.1:25565".parse().unwrap();
        let user = |id: u128, name: &str| NameAndId {
            id,
            name: name.into(),
        };
        let ban = |user: &NameAndId, expires: Option<i64>| {
            BanEntry::new(
                user.clone(),
                Some("Op".into()),
                expires,
                Some("griefing".into()),
            )
        };
        let (steve, alex, dee) = (user(1, "Steve"), user(2, "Alex"), user(3, "Dee"));
        // Free until banned.
        assert!(lists.can_login(address, &steve).is_none());
        // A ban for an hour: refused, with the reason and when it ends.
        lists.bans.add(ban(&steve, Some(now_millis() + 3_600_000)));
        let refused = message(lists.can_login(address, &steve));
        assert!(
            refused.contains("multiplayer.disconnect.banned.reason"),
            "{refused}"
        );
        assert!(
            refused.contains("multiplayer.disconnect.banned.expiration"),
            "{refused}"
        );
        assert!(refused.contains("griefing"), "{refused}");
        // A permanent ban is refused with no end.
        lists.bans.add(ban(&alex, None));
        let refused = message(lists.can_login(address, &alex));
        assert!(!refused.contains("expiration"), "{refused}");
        // A ban that has ended lets the player in, and the list drops it.
        lists.bans.add(ban(&dee, Some(now_millis() - 1_000)));
        assert!(lists.can_login(address, &dee).is_none());
        assert!(!lists.bans.contains(&dee));
        // `/pardon` lifts the hour's ban.
        assert!(lists.bans.remove(&steve));
        assert!(lists.can_login(address, &steve).is_none());
        fs::remove_dir_all(dir).unwrap();
    }
}

#[cfg(test)]
mod console_source_tests {
    use crate::game::{Audio, Game, Options, Progress, Settings, load_resources};
    use horizon_client::chunk::Chunk;
    use horizon_core::position::ChunkPos;
    use std::sync::Arc;

    /// Runs `command` as the console does and returns whether it worked and every message it printed.
    fn console(game: &mut Game<'_>, command: &str) -> (bool, String) {
        game.chat_capture = Some(Vec::new());
        let ok = game.as_console_in_overworld(|g| g.run_command(command));
        let said = game.chat_capture.take().unwrap_or_default();
        let said = said
            .iter()
            .map(|t| t.component().to_string())
            .collect::<Vec<_>>()
            .join("\n");
        (ok, said)
    }

    /// `MinecraftServer.createCommandSourceStack`: the console's source has no entity and is named "Server"
    /// (an RCON client's, `RconConsoleSource`, "Rcon"): `/me` says so, and `teammsg`, which needs an entity,
    /// refuses it (`permissions.requires.entity`) instead of running as the player in place.
    #[test]
    #[ignore = "needs prepared resources in HORIZON_TEST_RESOURCES and scratch homes/cwd"]
    fn the_console_runs_as_the_server_not_the_player_in_place() {
        let root = std::path::PathBuf::from(
            std::env::var_os("HORIZON_TEST_RESOURCES").expect("prepared resources required"),
        );
        let settings = Settings::default();
        let loaded = load_resources(
            root.clone(),
            None,
            &root,
            &settings,
            std::time::Instant::now(),
            false,
            true,
            &Progress::new(),
            &mut |_, _| unreachable!(),
        )
        .unwrap();
        let mut options = Options::parse(std::iter::empty()).unwrap().unwrap();
        options.resources = root.clone();
        options.execution_role = crate::game::execution_role::ExecutionRole::IntegratedServer;
        let mut game = Game::new(
            &loaded.resources,
            loaded.pack,
            loaded.gui.unwrap(),
            options,
            settings,
            Audio::silent(&root),
            None,
        )
        .unwrap();
        game.build_registries();
        game.set_allow_commands(true);
        game.world
            .chunks
            .insert((0, 0), Arc::new(Chunk::empty(0, 0)));
        game.block_ticks
            .add_empty_chunk(ChunkPos::new(0, 0))
            .unwrap();
        let (ok, said) = console(&mut game, "me waves");
        assert!(
            ok && said.contains("chat.type.emote") && said.contains("\"Server\""),
            "{said}"
        );
        game.rcon_source = true;
        let (ok, said) = console(&mut game, "me waves");
        assert!(ok && said.contains("\"Rcon\""), "{said}");
        game.rcon_source = false;
        let (ok, said) = console(&mut game, "teammsg hi");
        assert!(
            !ok && said.contains("permissions.requires.entity"),
            "{said}"
        );
        // The console's source is put back after each line.
        assert!(game.command_source.is_none());
    }
}
